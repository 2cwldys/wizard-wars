//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

#ifndef INC_NOWIN_H
#define INC_NOWIN_H
#ifndef _WIN32

#include <unistd.h>

#endif //!_WIN32
#endif //INC_NOWIN_H