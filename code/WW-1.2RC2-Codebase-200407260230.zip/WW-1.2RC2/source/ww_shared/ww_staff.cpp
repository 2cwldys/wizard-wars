#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

#include "ww_shared/ww_defs.h"
#include "ww_shared/ww_weapons.h"

#include "ww_shared/ww_staff.h"

#ifndef CLIENT_DLL
#include "ww_thornbush.h"
#include "ww_wizards.h"
#include "ww_icewizard.h"	
#endif


LINK_ENTITY_TO_CLASS( ww_staff, WWStaff );


void WWStaff::Spawn( void )
{
	Precache();

	m_iId = WEAPON_STAFF;
	m_iSwingCount = 0;

	FallInit();
}


void WWStaff::Precache( void )
{
	PRECACHE_SOUND( "spells/staff_hitbod1.wav"	);
	PRECACHE_SOUND( "spells/staff_hitbod2.wav"	);
	PRECACHE_SOUND( "spells/staff_hitbod3.wav"	);
	PRECACHE_SOUND( "spells/staff_miss1.wav"	);

	m_usEvent = PRECACHE_EVENT( 1, "events/spells/staff.sc" );
}


int WWStaff::iItemSlot( void )
{
	return SLOT_STAFF + 1;
}


int WWStaff::GetItemInfo( ItemInfo * pInfo )
{
	pInfo->iId = m_iId	= WEAPON_STAFF;
	pInfo->iSlot		= SLOT_STAFF;
	pInfo->iPosition	= POS_STAFF;
	pInfo->iWeight		= WEIGHT_STAFF;
	pInfo->pszName		= STRING( pev->classname );
	pInfo->pszAmmo1		= "mana";
	pInfo->iMaxAmmo1	= MAX_MANA;
	pInfo->pszAmmo2		= "satchels";
	pInfo->iMaxAmmo2	= MAX_SATCHELS;
	pInfo->iMaxClip		= WEAPON_NOCLIP;
	pInfo->iFlags		= 0;

	return 1;
}


BOOL WWStaff::Deploy( void )
{
	if( m_pPlayer->m_pClass != NULL )
	{
		return DefaultDeploy(
			(char *)m_pPlayer->m_pClass->GetWizardHands(),
			(char *)m_pPlayer->m_pClass->GetWizardStaff(),
			HANDS_IDLE, "staff" );
	}
	else
		return DefaultDeploy( "", "", HANDS_IDLE, "staff" );
}


void WWStaff::PrimaryAttack( void )
{
	if( m_flNextPrimaryAttack > UTIL_WeaponTimeBase() )
		return;

	Attack();

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + STAFF_DELAY;
	m_flTimeWeaponIdle	  = m_flNextPrimaryAttack;
}


void WWStaff::WeaponIdle( void )
{
	if( m_flTimeWeaponIdle > UTIL_WeaponTimeBase() )
		return;

	m_iSwingCount = 0;

	PLAYBACK_EVENT_FULL( FEV_HOSTONLY | FEV_CLIENT, m_pPlayer->edict(), m_usEvent, 0,
		m_pPlayer->pev->origin, m_pPlayer->pev->angles,	0, 0, 0, 0, 0, 1 );

	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + UTIL_SharedRandomFloat( m_pPlayer->random_seed, 10, 15 );
}


bool WWStaff::Attack( void )
{
	int bHit = 0;

	Vector vOrigin = m_pPlayer->GetGunPosition();
	Vector vAngles = m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle;

	UTIL_MakeVectors( vAngles );

	Vector vEndPos = vOrigin + gpGlobals->v_forward * STAFF_RANGE;

	TraceResult tr;
	UTIL_TraceLine( vOrigin, vEndPos, dont_ignore_monsters, m_pPlayer->edict(), &tr );

	if( tr.flFraction == 1.0f )
		UTIL_TraceHull( vOrigin, vEndPos, dont_ignore_monsters, head_hull, m_pPlayer->edict(), &tr );

	if( tr.flFraction != 1.0f )
	{
		bHit = 1;

#ifndef CLIENT_DLL
		CBaseEntity * pHit = CBaseEntity::Instance( tr.pHit );

		if( pHit != NULL )
		{
			AttackPlayer( pHit, &tr );
			bHit = 2;
		}
#endif
	}

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	PLAYBACK_EVENT_FULL( SC( FEV_NOTHOST, 0 ), m_pPlayer->edict(), m_usEvent, 0,
		m_pPlayer->pev->origin, m_pPlayer->pev->angles,
		0, 0, m_pPlayer->pev->playerclass, m_iSwingCount, bHit, 0 );

	m_iSwingCount++;
	return ( bHit ? true : false );
}


void WWStaff::AttackPlayer( CBaseEntity * pVictim, TraceResult * pTrace )
{
#ifndef CLIENT_DLL
	if( !pVictim )
		return;

	float flDamage = STAFF_DAMAGE;
	int bitsDamage = DMG_GENERIC;

	// enchant thornbushes
	if( FClassnameIs( pVictim->pev, "thornbush" ) && m_pPlayer->IRelationship( pVictim ) < R_NO )
	{
		if( m_pPlayer->pev->playerclass == WWCLASS_NATURE )
		{
			pVictim->TakeHealth( STAFF_DAMAGE, DMG_GENERIC );
			return;
		}

		WWThornBush * pBush = (WWThornBush *)pVictim;

		if( pBush != NULL && pBush->Enchant( m_pPlayer->pev->playerclass ) )
			return;
	}

	switch( m_pPlayer->pev->playerclass )
	{
	default:
		break;

	case WWCLASS_LIFE:

		if( pVictim->IsPlayer() && m_pPlayer->IRelationship( pVictim ) < R_NO )
		{
			CBasePlayer * pPlayer = GetClassPtr( (CBasePlayer *)pVictim->pev );

			pPlayer->TakeHealth( flDamage, bitsDamage );
			pPlayer->m_bitsDamageType = 0;
			return;
		}

		break;

	case WWCLASS_ICE:

		flDamage *= 1.5f;
		bitsDamage = DMG_FREEZE | DMG_SLOWFREEZE;

		if( pVictim->IsPlayer() && m_pPlayer->IRelationship( pVictim ) >= R_NO )
		{
			pVictim->pev->punchangle.x = RANDOM_FLOAT( -30, 30 );
			pVictim->pev->punchangle.y = RANDOM_FLOAT( -30, 30 );
			pVictim->pev->punchangle.z = RANDOM_FLOAT( -30, 30 );
		}

		break;

	case WWCLASS_LIGHTNING:
		bitsDamage = DMG_SHOCK;
		break;

	case WWCLASS_DEATH:
		bitsDamage = DMG_POISON | DMG_BLAST;
		break;

	case WWCLASS_EARTH:

		flDamage *= 2.0f;

		if( pVictim->IsPlayer() && m_pPlayer->IRelationship( pVictim ) >= R_NO )
		{
			extern int gmsgShake;
			MESSAGE_BEGIN( MSG_ONE, gmsgShake, NULL, pVictim->edict() );
				WRITE_SHORT( UTIL_FixedUnsigned16( 100.0f, 1 << 12 ) );
				WRITE_SHORT( UTIL_FixedUnsigned16(   1.0f, 1 << 12 ) );
				WRITE_SHORT( UTIL_FixedUnsigned16( 100.0f, 1 << 8  ) );
			MESSAGE_END();
		}

		break;

	case WWCLASS_WIND:

		flDamage *= 0.9f;

		if( pVictim->IsPlayer() && m_pPlayer->IRelationship( pVictim ) >= R_NO )
		{
			Vector vDiff = ( pVictim->pev->origin - m_pPlayer->pev->origin ).Normalize();
			pVictim->pev->velocity = vDiff * 500.0f + Vector( 0, 0, 300.0f );
		}

		break;
	}

	if( m_iSwingCount )
		flDamage *= 0.5f;

	ClearMultiDamage();
	pVictim->TraceAttack( m_pPlayer->pev, flDamage, gpGlobals->v_forward, pTrace, DMG_CLUB | bitsDamage );
	ApplyMultiDamage( pev, m_pPlayer->pev );
#endif
}
