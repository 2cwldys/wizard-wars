#include <windows.h>
#include "../hud.h"
#include "../cl_util.h"
#include "cl_entity.h"
#include "r_efx.h"
#include "triangleapi.h"
#include "pm_shared.h"
#include "pm_defs.h"
#include "pmtrace.h"
#include "entity_types.h"
#include "com_model.h"
#include "../studio_util.h"
#include "fmod_interface.h"



HMODULE	g_hModule;


char * SafeFile( const char * pszFile )
{
	if( !pszFile )
		return NULL;

	static char szFilename[1024];
	memset( &szFilename, 0, 1024 );

//	if( pszFile[1] != ':' )
//		strcpy( szFilename, "..\\..\\" );

	int iLen = 0; //strlen( szFilename );

	for( int i = 0; i < (int)strlen( pszFile ); i++ )
	{
		if( pszFile[i] < ' ' )
			continue;

		if( ( pszFile[i] == '/' || pszFile[i] == '\\' ) && ( pszFile[i+1] == '/' || pszFile[i+1] == '\\' ) )
			continue;

		if( pszFile[i] == '/' )
		{
			szFilename[iLen] = '\\';
			iLen++;
			continue;
		}

		szFilename[iLen] = pszFile[i];
		iLen++;
	}

	return szFilename;
}



CMusicManager::CMusicManager()
{
	m_bInit = false;

}

CMusicManager::~CMusicManager()
{
	if( g_hModule != NULL )
		FreeLibrary( g_hModule );
}


void CMusicManager::LibraryInit( void )
{
	if( m_bInit )
		return;

	gEngfuncs.Con_Printf( "Loaded cl_dlls/fmod.dll\n" );

	char	szFile[MAX_PATH];
	_snprintf( szFile, MAX_PATH, "%s/cl_dlls/fmod.dll", gEngfuncs.pfnGetGameDirectory() );

	if( g_hModule != NULL )
		FreeLibrary( g_hModule );

	g_hModule = LoadLibrary( szFile );

	if( g_hModule == NULL )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnInit )				= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Init@12" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnClose )			= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Close@0" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnSetDriver )		= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_SetDriver@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnSetOutput )		= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_SetOutput@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnSetBufferSize )	= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_SetBufferSize@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnSetVolume )		= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_SetVolume@8" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnStreamOpenFile )	= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Stream_OpenFile@12" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnStreamPlay )		= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Stream_Play@8" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnStreamStop )		= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Stream_Stop@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnStreamClose )		= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Stream_Close@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnStreamGetLengthMs ) = (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Stream_GetLengthMs@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnStreamGetTime )	= (unsigned int)GetProcAddress( g_hModule, "_FSOUND_Stream_GetTime@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnMusicLoadSong )	= (unsigned int)GetProcAddress( g_hModule, "_FMUSIC_LoadSong@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnMusicPlaySong )	= (unsigned int)GetProcAddress( g_hModule, "_FMUSIC_PlaySong@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnMusicStopSong )	= (unsigned int)GetProcAddress( g_hModule, "_FMUSIC_StopSong@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnMusicFreeSong )	= (unsigned int)GetProcAddress( g_hModule, "_FMUSIC_FreeSong@4" ) ) )
		goto error;

	if( !( *((unsigned int *)&m_Funcs.pfnMusicSetVolume )	= (unsigned int)GetProcAddress( g_hModule, "_FMUSIC_SetMasterVolume@8" ) ) )
		goto error;

	m_bInit = true;

	gEngfuncs.Con_Printf( "Sucessfully loaded cl_dlls/fmod.dll\n" );
	return;

error:
	gEngfuncs.Con_Printf( "Error loading cl_dlls/fmod.dll\n" );

	if( g_hModule != NULL )
		FreeLibrary( g_hModule );
}


void CMusicManager::Init( int iMinRate, int iMaxChannels, unsigned int iFlags )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "Init: %i\n", (int)m_Funcs.pfnInit( iMinRate, iMaxChannels, iFlags ) );
}


void CMusicManager::Close( void )
{
	if( !m_bInit )
		return;

	m_Funcs.pfnClose();
}


void CMusicManager::SetDriver( int iDriver )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "SetDriver: %i\n", (int)m_Funcs.pfnSetDriver( iDriver ) );
}


void CMusicManager::SetOutput( int iOutputType )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "SetOutput: %i\n", (int)m_Funcs.pfnSetOutput( iOutputType ) );
}


void CMusicManager::SetBufferSize( int iLengthMs )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "SetBufferSize: %i\n", (int)m_Funcs.pfnSetBufferSize( iLengthMs ) );
}


void CMusicManager::SetVolume( int iChannel, int iVolume )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "SetVolume: %i\n", (int)m_Funcs.pfnSetVolume( iChannel, iVolume ) );
}


FSOUND_STREAM * CMusicManager::StreamOpenFile( const char * pszFile, unsigned int iMode, int iMemLength )
{
	if( !m_bInit )
		return NULL;

	char * pszFilename = SafeFile( pszFile );
	FSOUND_STREAM * pReturn = m_Funcs.pfnStreamOpenFile( pszFilename, iMode, iMemLength );

	if( !pReturn )
		gEngfuncs.Con_Printf( "Failed to load '%s'.\n", pszFilename );
	else
		gEngfuncs.Con_Printf( "Loaded '%s'.\n", pszFilename );

	return pReturn;
//	return m_Funcs.pfnStreamOpenFile( SafeFile( pszFile ), iMode, iMemLength );
}


void CMusicManager::StreamPlay( int iChannel, FSOUND_STREAM * pStream )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "StreamPlay: %i\n", (int)m_Funcs.pfnStreamPlay( iChannel, pStream ) );
}


void CMusicManager::StreamStop( FSOUND_STREAM * pStream )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "StreamStop: %i\n", (int)m_Funcs.pfnStreamStop( pStream ) );
}


void CMusicManager::StreamClose( FSOUND_STREAM * pStream )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "StreamClose: %i\n", (int)m_Funcs.pfnStreamClose( pStream ) );
}


int CMusicManager::StreamGetLengthMs( FSOUND_STREAM * pStream )
{
	if( !m_bInit )
		return 0;

	return m_Funcs.pfnStreamGetLengthMs( pStream );
}


int CMusicManager::StreamGetTime( FSOUND_STREAM * pStream )
{
	if( !m_bInit )
		return 0;

	return m_Funcs.pfnStreamGetTime( pStream );
}



FMUSIC_MODULE * CMusicManager::MusicLoadSong( const char * pszFile )
{
	if( !m_bInit )
		return NULL;

	char * pszFilename = SafeFile( pszFile );
	FMUSIC_MODULE * pReturn = m_Funcs.pfnMusicLoadSong( pszFilename );

	if( !pReturn )
		gEngfuncs.Con_Printf( "Failed to load '%s'.\n", pszFilename );
	else
		gEngfuncs.Con_Printf( "Loaded '%s'.\n", pszFilename );

	return pReturn;
}


void CMusicManager::MusicPlaySong( FMUSIC_MODULE * pModule )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "MusicPlaySong: %i\n", (int)m_Funcs.pfnMusicPlaySong( pModule ) );
}


void CMusicManager::MusicStopSong( FMUSIC_MODULE * pModule )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "MusicStopSong: %i\n", (int)m_Funcs.pfnMusicStopSong( pModule ) );
}


void CMusicManager::MusicFreeSong( FMUSIC_MODULE * pModule )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "MusicFreeSong: %i\n", (int)m_Funcs.pfnMusicFreeSong( pModule ) );
}


void CMusicManager::MusicSetVolume( FMUSIC_MODULE * pModule, int iVolume )
{
	if( !m_bInit )
		return;

	gEngfuncs.Con_DPrintf( "MusicSetVolume: %i\n", (int)m_Funcs.pfnMusicSetVolume( pModule, iVolume ) );
}


