#ifndef __FMOD_INTERFACE_H__
#define __FMOD_INTERFACE_H__


typedef struct FSOUND_STREAM FSOUND_STREAM;
typedef struct FMUSIC_MODULE FMUSIC_MODULE;

#define F_API _stdcall

typedef struct fmodfuncs_s
{
	signed char		( F_API * pfnInit )					( int iMixRate, int iMaxChannels, unsigned int iFlags );
	void			( F_API * pfnClose )				( void );

	signed char		( F_API * pfnSetDriver )			( int iDriver );
	signed char		( F_API * pfnSetOutput )			( int iOutputType );
	signed char		( F_API * pfnSetBufferSize	)		( int iLengthMs );
	signed char		( F_API * pfnSetVolume )			( int iChannel, int iVolume );


	FSOUND_STREAM *	( F_API * pfnStreamOpenFile )		( const char * pszFile, unsigned int iMode, int iMemLength );
	int				( F_API * pfnStreamPlay )			( int iChannel, FSOUND_STREAM * pStream );
	signed char		( F_API * pfnStreamStop )			( FSOUND_STREAM * pStream );
	signed char		( F_API * pfnStreamClose )			( FSOUND_STREAM * pStream );
	int				( F_API * pfnStreamGetLengthMs )	( FSOUND_STREAM * pStream );
	int				( F_API * pfnStreamGetTime )		( FSOUND_STREAM * pStream );

	FMUSIC_MODULE *	( F_API * pfnMusicLoadSong )		( const char * pszFile );
	signed char		( F_API * pfnMusicPlaySong )		( FMUSIC_MODULE * pModule );
	signed char		( F_API * pfnMusicStopSong )		( FMUSIC_MODULE * pModule );
	signed char		( F_API * pfnMusicFreeSong )		( FMUSIC_MODULE * pModule );
	signed char		( F_API * pfnMusicSetVolume )		( FMUSIC_MODULE * pModule, int iVolume );

} fmodfuncs_t;


class CMusicManager
{
public:
	CMusicManager();
	~CMusicManager();

	void						LibraryInit			( void );

	void						Init				( int iMixRate, int iMaxChannels, unsigned int iFlags );
	void						Close				( void );

	void						SetDriver			( int iDriver );
	void						SetOutput			( int iOutputType );
	void						SetBufferSize		( int iLengthMs );
	void						SetVolume			( int iChannel, int iVolume );

	FSOUND_STREAM *				StreamOpenFile		( const char * pszFile, unsigned int iMode, int iMemLength );
	void						StreamPlay			( int iChannel, FSOUND_STREAM * pStream );
	void						StreamStop			( FSOUND_STREAM * pStream );
	void						StreamClose			( FSOUND_STREAM * pStream );
	int							StreamGetLengthMs	( FSOUND_STREAM * pStream );
	int							StreamGetTime		( FSOUND_STREAM * pStream );

	FMUSIC_MODULE *				MusicLoadSong		( const char * pszFile );
	void						MusicPlaySong		( FMUSIC_MODULE * pModule );
	void						MusicStopSong		( FMUSIC_MODULE * pModule );
	void						MusicFreeSong		( FMUSIC_MODULE * pModule );
	void						MusicSetVolume		( FMUSIC_MODULE * pModule, int iVolume );

private:
	fmodfuncs_t					m_Funcs;
	bool						m_bInit;
};


#endif // __FMOD_INTERFACE_H__