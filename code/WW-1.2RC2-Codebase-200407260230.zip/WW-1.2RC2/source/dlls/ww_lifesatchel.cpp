#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "soundent.h"
#include "gamerules.h"
#include "effects.h"

#include "ww_satchels.h"


class LifeSatchel : public WWSatchel
{
public:
	virtual void	Spawn			( void );
	virtual void	Precache		( void );

	virtual void	SatchelExplode	( void );
};


LINK_ENTITY_TO_CLASS( ww_satchel_life, LifeSatchel );


void LifeSatchel::Spawn( void )
{
	WWSatchel::Spawn();

	SET_MODEL( edict(), "models/satchels/life.mdl" );

	m_iExplodeCount		= 1;
}


void LifeSatchel::Precache( void )
{
	PRECACHE_MODEL( "models/satchels/life.mdl"	);
	PRECACHE_MODEL( "sprites/b-tele1.spr"		);
	PRECACHE_SOUND( "satchels/life.wav"			);
	m_usEvent = PRECACHE_EVENT( 1, "events/satchels/life.sc" );
}


void LifeSatchel::SatchelExplode( void )
{
	CBasePlayer * pPlayer = (CBasePlayer *)CBaseEntity::Instance( pev->owner );
	
	if( !pPlayer )
	{
		UTIL_Remove( this );
		return;
	}

	CBaseEntity * pVictim = NULL;
	while( ( pVictim = UTIL_FindEntityInSphere( pVictim, pev->origin, 175.0f ) ) != NULL )
	{
		if( pPlayer->IRelationship( pVictim ) < R_NO )
			pVictim->TakeHealth( 220, DMG_GENERIC );
		else
			pVictim->TakeDamage( pev, VARS(pev->owner), 220, DMG_GENERIC );
	}
	
	PLAYBACK_EVENT( 0, edict(), m_usEvent );
}