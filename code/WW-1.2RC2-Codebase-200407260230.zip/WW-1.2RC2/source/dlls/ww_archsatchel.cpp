#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "soundent.h"
#include "gamerules.h"
#include "effects.h"

#include "ww_satchels.h"


class ArchMageSatchel : public WWSatchel
{
public:
	virtual void	Spawn			( void );
	virtual void	SatchelExplode	( void );
};


LINK_ENTITY_TO_CLASS( ww_satchel_archmage, ArchMageSatchel );


void ArchMageSatchel::Spawn( void )
{
	WWSatchel::Spawn();
}


void ArchMageSatchel::SatchelExplode( void )
{
	CBasePlayer * pPlayer = (CBasePlayer *)CBaseEntity::Instance( pev->owner );

	if( !pPlayer )
		return;

	pPlayer->TakeHealth( 30, DMG_GENERIC );

	pPlayer->pev->armorvalue += 30;
	if( pPlayer->pev->armorvalue > pPlayer->pev->armortype )
		pPlayer->pev->armorvalue = pPlayer->pev->armortype;
}
