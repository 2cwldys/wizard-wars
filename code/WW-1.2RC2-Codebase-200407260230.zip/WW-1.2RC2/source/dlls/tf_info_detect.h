#ifndef __TF_INFO_DETECT_H__
#define __TF_INFO_DETECT_H__

class TFInfoDetect : public CPointEntity
{
public:
	TFInfoDetect();
	~TFInfoDetect();

public:
	virtual void	Spawn		( void );
	virtual void	Precache	( void );

	virtual void	KeyValue	( KeyValueData * pkvd );

	virtual int		Classify	( void ) { return TF_ENT_INFO_DETECT; };

};

#endif // __TF_INFO_TFDETECT_H__