//=========== (C) Copyright 1999 Valve, L.L.C. All rights reserved. ===========
//
// The copyright to the contents herein is the property of Valve, L.L.C.
// The contents may be used and/or copied only with the written permission of
// Valve, L.L.C., or in accordance with the terms and conditions stipulated in
// the agreement/contract under which the contents have been supplied.
//
// Purpose: TFC Class Menu 
//
// $Workfile:     $
// $Date:         $
//
//-----------------------------------------------------------------------------
// $Log: $
//
// $NoKeywords: $
//=============================================================================

#include "VGUI_Font.h"
#include <VGUI_TextImage.h>

#include "hud.h"
#include "cl_util.h"
#include "camera.h"
#include "kbutton.h"
#include "cvardef.h"
#include "usercmd.h"
#include "const.h"
#include "camera.h"
#include "in_defs.h"
#include "parsemsg.h"

#include "vgui_int.h"
#include "vgui_TeamFortressViewport.h"
#include "vgui_ServerBrowser.h"

#include "../dlls/wizardwarsdefs.h"

// Class Menu Dimensions
#define CLASSMENU_TITLE_X				XRES(40)
#define CLASSMENU_TITLE_Y				YRES(32)
#define CLASSMENU_TOPLEFT_BUTTON_X		XRES(40)
#define CLASSMENU_TOPLEFT_BUTTON_Y		YRES(80)
#define CLASSMENU_BUTTON_SIZE_X			XRES(124)
#define CLASSMENU_BUTTON_SIZE_Y			YRES(24)
#define CLASSMENU_BUTTON_SPACER_Y		YRES(8)
#define CLASSMENU_WINDOW_X				XRES(176)
#define CLASSMENU_WINDOW_Y				YRES(80)
#define CLASSMENU_WINDOW_SIZE_X			XRES(424)
#define CLASSMENU_WINDOW_SIZE_Y			YRES(312)
#define CLASSMENU_WINDOW_TEXT_X			XRES(150)
#define CLASSMENU_WINDOW_TEXT_Y			YRES(80)
#define CLASSMENU_WINDOW_NAME_X			XRES(150)
#define CLASSMENU_WINDOW_NAME_Y			YRES(8)
#define CLASSMENU_WINDOW_PLAYERS_Y		YRES(42)

extern int g_iMenuTeamNumber;

class CConclaveHandler:public ActionSignal{
public:
	CConclaveHandler(CClassMenuPanel *panel,int iConclave){
		m_iConclave=iConclave;
		m_pPanel=panel;
	}

	virtual void actionPerformed(Panel* panel){
		m_pPanel->m_iConclaveMenu=m_iConclave;
		m_pPanel->Update();
	}
private:
	int m_iConclave;
	CClassMenuPanel *m_pPanel;
};

// Creation
CClassMenuPanel::CClassMenuPanel(int iTrans, int iRemoveMe, int x,int y,int wide,int tall) : CMenuPanel(iTrans, iRemoveMe, x,y,wide,tall)
{
	// don't show class graphics at below 640x480 resolution
	bool bShowClassGraphic = true;
	if ( ScreenWidth < 640 )
	{
		bShowClassGraphic = false;
	}

	memset( m_pClassImages, 0, sizeof(m_pClassImages) );

	// Get the scheme used for the Titles
	CSchemeManager *pSchemes = gViewPort->GetSchemeManager();

	// schemes
	SchemeHandle_t hTitleScheme = pSchemes->getSchemeHandle( "Title Font" );
	SchemeHandle_t hClassWindowText = pSchemes->getSchemeHandle( "Briefing Text" );

	// color schemes
	int r, g, b, a;

	m_iConclaveMenu=0;

	// Create the title
	m_pLabel = new Label( "", CLASSMENU_TITLE_X, CLASSMENU_TITLE_Y );
	m_pLabel->setParent( this );
	m_pLabel->setFont( pSchemes->getFont(hTitleScheme) );
	pSchemes->getFgColor( hTitleScheme, r, g, b, a );
	m_pLabel->setFgColor( r, g, b, a );
	pSchemes->getBgColor( hTitleScheme, r, g, b, a );
	m_pLabel->setBgColor( r, g, b, a );
	m_pLabel->setContentAlignment( vgui::Label::a_west );

	// Create the Scroll panel
	m_pScrollPanel = new CTFScrollPanel( CLASSMENU_WINDOW_X, CLASSMENU_WINDOW_Y, CLASSMENU_WINDOW_SIZE_X, CLASSMENU_WINDOW_SIZE_Y );
	m_pScrollPanel->setParent(this);
	//force the scrollbars on, so after the validate clientClip will be smaller
	m_pScrollPanel->setScrollBarAutoVisible(false, false);
	m_pScrollPanel->setScrollBarVisible(true, true);
	m_pScrollPanel->setBorder( new LineBorder( Color(THEMECOLOR,0) ) );
	m_pScrollPanel->validate();

	int clientWide=m_pScrollPanel->getClient()->getWide();

	//turn scrollpanel back into auto show scrollbar mode and validate
	m_pScrollPanel->setScrollBarAutoVisible(false,true);
	m_pScrollPanel->setScrollBarVisible(false,false);
	m_pScrollPanel->validate();

	for(int i=0;i<MAX_CONCLAVES;i++){//Make Conclave buttons
		char sz[256];
		int iYPos=CLASSMENU_TOPLEFT_BUTTON_Y + ((CLASSMENU_BUTTON_SIZE_Y + CLASSMENU_BUTTON_SPACER_Y)*(i-1));

		ActionSignal *pASignal=new CConclaveHandler(this,i);

		sprintf(sz,"%s",CHudTextMessage::BufferedLocaliseTextString(ConclaveNames[i]));
		m_pConclaveButtons[i]=new ClassButton(i,sz,CLASSMENU_TOPLEFT_BUTTON_X,iYPos,CLASSMENU_BUTTON_SIZE_X,CLASSMENU_BUTTON_SIZE_Y,true);

		m_pConclaveButtons[i]->setBoundKey(48+i);
		m_pConclaveButtons[i]->setContentAlignment(vgui::Label::a_west);
		m_pConclaveButtons[i]->addActionSignal(pASignal);
		m_pConclaveButtons[i]->addInputSignal(new CHandler_MenuButtonOver(this,i));
		m_pConclaveButtons[i]->setParent(this);

		// don't show class pic in lower resolutions
		int textOffs = XRES(8);

		// Create the Conclave Info Window
		m_pConclaveInfoPanel[i]=new CTransparentPanel( 255, 0, 0, clientWide, CLASSMENU_WINDOW_SIZE_Y );
		m_pConclaveInfoPanel[i]->setParent(m_pScrollPanel->getClient());

		// Create the Conclave Name Label
		sprintf(sz,"%s",ConclaveNames[i]);
		char* localName=CHudTextMessage::BufferedLocaliseTextString(sz);
		Label *pNameLabel=new Label("",textOffs,CLASSMENU_WINDOW_NAME_Y);
		pNameLabel->setFont( pSchemes->getFont(hTitleScheme) ); 
		pNameLabel->setParent(m_pConclaveInfoPanel[i]);
		pSchemes->getFgColor( hTitleScheme, r, g, b, a );
		pNameLabel->setFgColor( r, g, b, a );
		pSchemes->getBgColor( hTitleScheme, r, g, b, a );
		pNameLabel->setBgColor( r, g, b, a );
		pNameLabel->setContentAlignment( vgui::Label::a_west );
		//pNameLabel->setBorder(new LineBorder());
		pNameLabel->setText(localName);

		// Open up the Conclave Briefing File
		sprintf(sz,"conclaves/%s.txt",ConclaveNames[i]);
		char *cText = "Conclave Description not available.";
		char *pfile = (char*)gEngfuncs.COM_LoadFile( sz, 5, NULL );
		if (pfile)
			cText = pfile;

		// Create the Text info window
		TextPanel *pTextWindow = new TextPanel(cText, textOffs, CLASSMENU_WINDOW_TEXT_Y, (CLASSMENU_WINDOW_SIZE_X - textOffs)-5, CLASSMENU_WINDOW_SIZE_Y - CLASSMENU_WINDOW_TEXT_Y);
		pTextWindow->setParent(m_pConclaveInfoPanel[i]);
		pTextWindow->setFont(pSchemes->getFont(hClassWindowText));
		pSchemes->getFgColor( hClassWindowText, r, g, b, a );
		pTextWindow->setFgColor( r, g, b, a );
		pSchemes->getBgColor( hClassWindowText, r, g, b, a );
		pTextWindow->setBgColor( r, g, b, a );

		// Resize the Info panel to fit it all
		int wide,tall;
		pTextWindow->getTextImage()->getTextSizeWrapped( wide,tall);
		pTextWindow->setSize(wide,tall);
		//pTextWindow->setBorder(new LineBorder());
		int xx,yy;
		pTextWindow->getPos(xx,yy);
		int maxX=xx+wide;
		int maxY=yy+tall;

		m_pConclaveInfoPanel[i]->setSize(maxX,maxY);
	}

	// Create the Class buttons
	int iCount[MAX_CONCLAVES];
	for(i=0;i<MAX_CONCLAVES;i++)
		iCount[i]=-1;

	for(i=0;i<MAX_CLASSES;i++){
		char sz[256];

		iCount[ClassConclave[i]]++;
		
		int iYPos=CLASSMENU_TOPLEFT_BUTTON_Y+((CLASSMENU_BUTTON_SIZE_Y+CLASSMENU_BUTTON_SPACER_Y)*iCount[ClassConclave[i]]);

		sprintf(sz,"changeclass %d",i);

		ActionSignal *pASignal=new CMenuHandler_StringCommandClassSelect(sz,true);

		// Class button
		sprintf(sz,"%s",CHudTextMessage::BufferedLocaliseTextString(ClassNames[i]));
		m_pClassButtons[i]=new ClassButton(i,sz,CLASSMENU_TOPLEFT_BUTTON_X,iYPos,CLASSMENU_BUTTON_SIZE_X,CLASSMENU_BUTTON_SIZE_Y,true);

		m_pClassButtons[i]->setBoundKey(49+iCount[ClassConclave[i]]);
		m_pClassButtons[i]->setContentAlignment(vgui::Label::a_west);
		m_pClassButtons[i]->addActionSignal(pASignal);
		m_pClassButtons[i]->addInputSignal(new CHandler_MenuButtonOver(this,i));
		m_pClassButtons[i]->setParent(this);
	
		// Create the Class Info Window
		m_pClassInfoPanel[i]=new CTransparentPanel( 255, 0, 0, clientWide, CLASSMENU_WINDOW_SIZE_Y );
		m_pClassInfoPanel[i]->setParent( m_pScrollPanel->getClient() );

		// don't show class pic in lower resolutions
		int textOffs = XRES(8);

		if ( bShowClassGraphic )
		{
			textOffs = CLASSMENU_WINDOW_NAME_X;
		}

		// Create the Class Name Label
		sprintf(sz,"%s",ClassNames[i]);
		char* localName=CHudTextMessage::BufferedLocaliseTextString(sz);
		Label *pNameLabel=new Label("",textOffs,CLASSMENU_WINDOW_NAME_Y);
		pNameLabel->setFont( pSchemes->getFont(hTitleScheme) ); 
		pNameLabel->setParent(m_pClassInfoPanel[i]);
		pSchemes->getFgColor( hTitleScheme, r, g, b, a );
		pNameLabel->setFgColor( r, g, b, a );
		pSchemes->getBgColor( hTitleScheme, r, g, b, a );
		pNameLabel->setBgColor( r, g, b, a );
		pNameLabel->setContentAlignment( vgui::Label::a_west );
		//pNameLabel->setBorder(new LineBorder());
		pNameLabel->setText(localName);

		// Create the Class Image
		if ( bShowClassGraphic ){
			sprintf(sz,"%s",ModelNames[i]);

			m_pClassImages[i] = new CImageLabel(sz,0,0,CLASSMENU_WINDOW_TEXT_X,CLASSMENU_WINDOW_TEXT_Y);

			CImageLabel *pLabel=m_pClassImages[i];
			pLabel->setParent(m_pClassInfoPanel[i]);
			//pLabel->setBorder(new LineBorder());

			// Reposition it based upon it's size
			int xOut, yOut;
			pNameLabel->getTextSize(xOut,yOut);
			pLabel->setPos((CLASSMENU_WINDOW_TEXT_X-pLabel->getWide())/2,yOut/2);
		}

		// Create the Player count string
		gHUD.m_TextMessage.LocaliseTextString( "#Title_CurrentlyOnYourTeam", m_sPlayersOnTeamString, STRLENMAX_PLAYERSONTEAM );
		m_pPlayers[i]=new Label("",textOffs,CLASSMENU_WINDOW_PLAYERS_Y);
		m_pPlayers[i]->setParent( m_pClassInfoPanel[i] );
		m_pPlayers[i]->setBgColor( 0, 0, 0, 255 );
		m_pPlayers[i]->setContentAlignment( vgui::Label::a_west );
		m_pPlayers[i]->setFont( pSchemes->getFont(hClassWindowText) );

		// Open up the Class Briefing File
		sprintf(sz,"class/%s.txt",ClassNames[i]);
		char *cText = "Class Description not available.";
		char *pfile = (char *)gEngfuncs.COM_LoadFile( sz, 5, NULL );
		if (pfile) //cjb: removed brackets from around cText = pfile; in 2.2.
			cText = pfile;

		// Create the Text info window
		TextPanel *pTextWindow = new TextPanel(cText, textOffs, CLASSMENU_WINDOW_TEXT_Y, (CLASSMENU_WINDOW_SIZE_X - textOffs)-5, CLASSMENU_WINDOW_SIZE_Y - CLASSMENU_WINDOW_TEXT_Y);
		pTextWindow->setParent(m_pClassInfoPanel[i]);
		pTextWindow->setFont(pSchemes->getFont(hClassWindowText));
		pSchemes->getFgColor( hClassWindowText, r, g, b, a );
		pTextWindow->setFgColor( r, g, b, a );
		pSchemes->getBgColor( hClassWindowText, r, g, b, a );
		pTextWindow->setBgColor( r, g, b, a );

		// Resize the Info panel to fit it all
		int wide,tall;
		pTextWindow->getTextImage()->getTextSizeWrapped( wide,tall);
		pTextWindow->setSize(wide,tall);

		int xx,yy;
		pTextWindow->getPos(xx,yy);
		int maxX=xx+wide;
		int maxY=yy+tall;

		//check to see if the image goes lower than the text
		//just use the red teams [0] images
		if(m_pClassImages[i]!=null){
			m_pClassImages[i]->getPos(xx,yy);
			if((yy+m_pClassImages[i]->getTall())>maxY){
				maxY=yy+m_pClassImages[i]->getTall();
			}
		}

		m_pClassInfoPanel[i]->setSize( maxX , maxY );
		//m_pClassInfoPanel[i]->setBorder(new LineBorder());
	}

	m_pBackButton=new CommandButton(gHUD.m_TextMessage.BufferedLocaliseTextString("Back"),CLASSMENU_TOPLEFT_BUTTON_X,0,CLASSMENU_BUTTON_SIZE_X,CLASSMENU_BUTTON_SIZE_Y);
	m_pBackButton->setParent(this);
	m_pBackButton->addActionSignal(new CConclaveHandler(this,0));

	// Create the Cancel button
	m_pCancelButton = new CommandButton( gHUD.m_TextMessage.BufferedLocaliseTextString( "Cancel" ), CLASSMENU_TOPLEFT_BUTTON_X, 0, CLASSMENU_BUTTON_SIZE_X, CLASSMENU_BUTTON_SIZE_Y);
	m_pCancelButton->setParent( this );
	m_pCancelButton->addActionSignal( new CMenuHandler_TextWindow(HIDE_TEXTWINDOW) );

	// Class button
	char sz[256];

	sprintf(sz,"changeclass %d",-1);
	ActionSignal *pASignal = new CMenuHandler_StringCommandClassSelect( sz, true );
	sprintf(sz,"%s",CHudTextMessage::BufferedLocaliseTextString("Random"));
	m_pRandomButton=new ClassButton(i,sz,CLASSMENU_TOPLEFT_BUTTON_X,CLASSMENU_TOPLEFT_BUTTON_Y+((CLASSMENU_BUTTON_SIZE_Y+CLASSMENU_BUTTON_SPACER_Y)*9),CLASSMENU_BUTTON_SIZE_X,CLASSMENU_BUTTON_SIZE_Y,true);
	m_pRandomButton->setBoundKey('R');
	m_pRandomButton->setContentAlignment(vgui::Label::a_west);
	m_pRandomButton->addActionSignal(pASignal);
	m_pRandomButton->addInputSignal(new CHandler_MenuButtonOver(this,-1));
	m_pRandomButton->setParent(this);

	m_iCurrentInfo = 0;
}


// Update
void CClassMenuPanel::Update(){
	int i=0;
	
	// Don't allow the player to join a team if they're not in a team
	int	 iYPos = CLASSMENU_TOPLEFT_BUTTON_Y;

	//Hide all initially
	m_pBackButton->setVisible(false);
	m_pCancelButton->setVisible(false);
	m_pRandomButton->setVisible(false);

	for(i=0;i<MAX_CONCLAVES;i++){
		m_pConclaveButtons[i]->setVisible(false);
		m_pConclaveInfoPanel[i]->setVisible(false);
	}

	for(i=0;i<MAX_CLASSES;i++){
		m_pClassButtons[i]->setVisible(false);
		m_pClassInfoPanel[i]->setVisible(false);
	}

	// Cycle through the rest of the buttons
	if(m_iConclaveMenu==0){
		for(i=1;i<MAX_CONCLAVES;i++){
			int b=0;

			for(int j=0;j<MAX_CLASSES;j++)
				if(gViewPort->IsValidClass(g_iMenuTeamNumber,j) && ClassConclave[j]==i)
					b=1;

			if(b)
				m_pConclaveButtons[i]->setVisible(true);
		}

		m_pCancelButton->setVisible(true);
		m_pRandomButton->setVisible(true);

		m_pLabel->setText(gHUD.m_TextMessage.BufferedLocaliseTextString("#Title_SelectYourConclave"));

		SetActiveInfo(1);
	}
	else{
		for(int i=1;i<MAX_CLASSES;i++){
			if(gViewPort->IsValidClass(g_iMenuTeamNumber,i) && ClassConclave[i]==m_iConclaveMenu){
				m_pClassButtons[i]->setVisible(true);

				// Now count the number of teammembers of this class
				int iTotal = 0;
				for ( int j = 1; j < MAX_PLAYERS; j++ ){
					if ( g_PlayerInfoList[j].name == NULL )
						continue; // empty player slot, skip
					if ( g_PlayerExtraInfo[j].teamname[0] == 0 )
						continue; // skip over players who are not in a team
					if ( g_PlayerInfoList[j].thisplayer )
						continue; // skip this player
					if ( g_PlayerExtraInfo[j].teamnumber != g_iMenuTeamNumber )
						continue; // skip over players in other teams

					if(g_PlayerExtraInfo[j].playerclass != i)
						continue;

					iTotal++;
				}

				char sz[256]; 
				sprintf(sz,m_sPlayersOnTeamString,iTotal);
				m_pPlayers[i]->setText( sz );

				m_pPlayers[i]->setFgColor( iTeamColors[g_iMenuTeamNumber][0], iTeamColors[g_iMenuTeamNumber][1], iTeamColors[g_iMenuTeamNumber][2], 0 );

/*				// set the graphic to be the team pick
				for ( int team = 0; team < MAX_TEAMS; team++ )
				{
					// unset all the other images
					if ( m_pClassImages[team][i] )
					{
						m_pClassImages[team][i]->setVisible( false );
					}

					// set the current team image
					if ( m_pClassImages[g_iMenuTeamNumber-1][i] != NULL )
					{
						m_pClassImages[g_iMenuTeamNumber-1][i]->setVisible( true );
					}
					else if ( m_pClassImages[0][i] )
					{
						m_pClassImages[0][i]->setVisible( true );
					}
				}*/
			}
		}

		m_pBackButton->setVisible(true);

		m_pLabel->setText(gHUD.m_TextMessage.BufferedLocaliseTextString("#Title_SelectYourClass"));

		SetActiveInfo(0);
	}
}

//======================================
// Key inputs for the Class Menu
bool CClassMenuPanel::SlotInput( int iSlot )
{
	if(iSlot==-1 && m_iConclaveMenu==0){
		if(m_pRandomButton->isVisible()){
			m_pRandomButton->fireActionSignal();
			return true;
		}
	}
	else if(iSlot>=0 && iSlot<=9 && m_iConclaveMenu==0){
		if(m_pConclaveButtons[iSlot]->isVisible()){
			m_pConclaveButtons[iSlot]->fireActionSignal();
			return true;
		}
	}	
	else if(iSlot>=0 && iSlot<=9 && m_iConclaveMenu>0){
		for(int i=0;i<MAX_CLASSES;i++){
			if(m_pClassButtons[i]->isVisible() && m_pClassButtons[i]->getBoundKey()==48+iSlot){
				m_pClassButtons[i]->fireActionSignal();
				return true;
			}
		}
	}

	return false;
}

//======================================
// Update the Class menu before opening it
void CClassMenuPanel::Open( void )
{
	m_iConclaveMenu=0;

	Update();

	CMenuPanel::Open();
	SetActiveInfo(1);
}

//-----------------------------------------------------------------------------
// Purpose: Called each time a new level is started.
//-----------------------------------------------------------------------------
void CClassMenuPanel::Initialize( void )
{
	setVisible( false );
	m_pScrollPanel->setScrollValue( 0, 0 );
}

//======================================
// Mouse is over a class button, bring up the class info
void CClassMenuPanel::SetActiveInfo( int iInput )
{
	m_pScrollPanel->setScrollValue(0,0);
	m_pScrollPanel->validate();

	m_pRandomButton->setArmed(false);
	
	for(int i=1;i<MAX_CONCLAVES;i++){
		m_pConclaveButtons[i]->setArmed(false);
		m_pConclaveInfoPanel[i]->setVisible(false);
	}

	for(int j=0;j<MAX_CLASSES;j++){
		m_pClassButtons[j]->setArmed(false);
		m_pClassInfoPanel[j]->setVisible(false);
	}

	if(iInput==-1)
		m_pRandomButton->setArmed(true);
	else if(m_iConclaveMenu==0){
		m_pConclaveButtons[iInput]->setArmed(true);
		m_pConclaveInfoPanel[iInput]->setVisible(true);
	}
	else{
		m_pClassButtons[iInput]->setArmed(true);
		m_pClassInfoPanel[iInput]->setVisible(true);
	}

	m_pScrollPanel->validate();
}
