/* ev_wizardwars.cpp : Wizard Wars effects
   Author:  Alan Fischer
*/

#include "hud.h"
#include "cl_util.h"
#include "const.h"
#include "entity_state.h"
#include "cl_entity.h"
#include "entity_types.h"
#include "usercmd.h"
#include "pm_defs.h"
#include "pm_materials.h"

#include "eventscripts.h"
#include "ev_hldm.h"

#include "r_efx.h"
#include "event_api.h"
#include "event_args.h"
#include "in_defs.h"

#include <string.h>
#include "ev_hldm.h"

#include "../dlls/wizardwarsdefs.h"

static int tracerCount[ 32 ];
extern void V_PunchAxis( int axis, float punch );

extern "C"{
	void EV_SpotboltSpellFire(struct event_args_s *args);
	void EV_SpotboltSpellCharge(struct event_args_s *args);
	void EV_LightningboltSpellFire(struct event_args_s *args);
	void EV_ThornblastSpellFire(struct event_args_s *args);
	void EV_FlamelickSpellFire(struct event_args_s *args);
	void EV_MagicMissleSpellFire(struct event_args_s *args);
	void EV_DoubleMagicMissleSpellFire(struct event_args_s *args);
	void EV_ForceSpellFire(struct event_args_s *args);
	void EV_FireballSpellFire(struct event_args_s *args);
	void EV_IcepokeSpellFire(struct event_args_s *args);
	void EV_SkullSpellFire(struct event_args_s *args);
	void EV_RollingStoneSpellFire(struct event_args_s *args);
	void EV_BirdSpellFire(struct event_args_s *args);
	void EV_MindMissleSpellFire(struct event_args_s *args);
	void EV_StaffSwing(struct event_args_s *args);
	void EV_BearBite(struct event_args_s *args);
	void EV_ShieldSpellFire(struct event_args_s *args);
	void EV_UpdraftSpellFire(struct event_args_s *args);
	void EV_DragonbreathSpellFire(struct event_args_s *args);
	void EV_WyvernSpellFire(struct event_args_s *args);

	void EV_LightningSatchelFire(struct event_args_s *args);
	void EV_PoisonSatchelFire(struct event_args_s *args);
	void EV_EarthquakeSatchelFire(struct event_args_s *args);
	void EV_SuctionSatchelFire(struct event_args_s *args);
	void EV_FireSatchelFire(struct event_args_s *args);
	void EV_BurSatchelFire(struct event_args_s *args);
	void EV_TCrystalFire(struct event_args_s *args);
	void EV_ToothSatchelFire(struct event_args_s *args);

	void EV_DragonFire(struct event_args_s *args);
	void EV_DragonFlap(struct event_args_s *args);

	void EV_FireballTrail(struct event_args_s *args);
	void EV_Gibs(struct event_args_s *args);
	void EV_DeathFlash(struct event_args_s *args);
	void EV_ThornbushUpgrade(struct event_args_s *args);
	void EV_SporePodFire(struct event_args_s *args);
	void EV_Burn(struct event_args_s *args);
	void EV_Spark(struct event_args_s *args);
	void EV_Taunt(struct event_args_s *args);
}

#define SPOTBOLTSPELL_SOUND_CHARGE		"spells/spotbolt.wav" 

void EV_SpotboltSpellFire(event_args_t *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;
	vec3_t temp;

	float flCharge=args->fparam1;

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );
	
	pmtrace_t tr;

	int m_iBeam,m_iFireball;

	VectorCopy( forward, vecAiming );

	VectorMA( vecSrc, 8192, forward, vecDest );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );
	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1, &tr );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	m_iBeam = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/smoke.spr");
	m_iFireball = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/zerogxplode.spr");

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_SPOTBOLTFIRE],2);
	}

	VectorCopy(tr.endpos,temp);
	temp.z=temp.z+1000;

	vec3_t med,t;

	VectorCopy(temp,med);

	for(int x=0;x<3;x++){
		med[0]=tr.endpos[0]+gEngfuncs.pfnRandomFloat(-100,100);
		med[1]=tr.endpos[1]+gEngfuncs.pfnRandomFloat(-100,100);
		med[2]=(temp[2]+tr.endpos[2])/2;

		t[0]=(med[0]+temp[0])/2;
		t[1]=(med[1]+temp[1])/2;
		t[2]=(med[2]+temp[2])/2;

		gEngfuncs.pEfxAPI->R_BeamPoints(temp,t,m_iBeam,.5,flCharge*4+1,1,1,0,0,0,1,.5,0);
		gEngfuncs.pEfxAPI->R_BeamPoints(t,med,m_iBeam,.5,flCharge*4+1,1,1,0,0,0,1,.5,0);

		VectorCopy(t,temp);
	}
	
	gEngfuncs.pEfxAPI->R_BeamPoints(tr.endpos,temp,m_iBeam,.5,flCharge*4+1,.4,1,0,0,0,1,.5,0);

	gEngfuncs.pEfxAPI->R_Explosion(tr.endpos,m_iFireball,flCharge*2+.25,15,0);

}

void EV_SpotboltSpellCharge(event_args_t *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;
	vec3_t temp;

	float flCharge=args->fparam1;

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	if(flCharge>0.5)
		flCharge=.5;

	if(EV_IsLocal(idx)){
		gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,SPOTBOLTSPELL_SOUND_CHARGE,.4,ATTN_NORM,0,PITCH_NORM-30+flCharge*60);
	}
}

void EV_LightningboltSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	pmtrace_t tr;

	int m_iBeam;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );

	VectorCopy( forward, vecAiming );

	VectorMA( vecSrc, 8192, forward, vecDest );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1 , &tr );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_LITBOLTFIRE],2);
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,SPOTBOLTSPELL_SOUND_CHARGE,.25,ATTN_NORM,0,150);

	m_iBeam = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/smoke.spr");

	vecSrc[2]-=5;

	gEngfuncs.pEfxAPI->R_BeamPoints(vecSrc,tr.endpos,m_iBeam,.3,2,.3,1,0,0,0,1,.8,0);
}

#define THORNBLASTSPELL_SOUND_SHOOT		"spells/thornblast.wav"
void EV_ThornblastSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );

	VectorCopy( forward, vecAiming );

	VectorMA( vecSrc, 8192, forward, vecDest );

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_THORNBLASTFIRE],2);
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,THORNBLASTSPELL_SOUND_SHOOT,1,ATTN_NORM,0,gEngfuncs.pfnRandomFloat(100,150));

	EV_HLDM_FireBullets(idx,forward,right,up,5,vecSrc,vecAiming,2048,BULLET_PLAYER_BUCKSHOT,0,&tracerCount[idx-1],.1,.1);
}

void EV_FlamelickSpellFire(event_args_t *args){
	int idx;

//	char strTest[256];

	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	float fRecoilX = args->fparam1; //args->fparam1 = vecDir.x from server DLL;
	float fRecoilY = args->fparam2; //args->fparam2 = vecDir.y from server DLL;

	pmtrace_t	tr;

	int m_iFlamelick;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );

	VectorCopy( forward, vecAiming );

	VectorMA( vecSrc, 8192, forward, vecDest );

	/****************************************
	1337 programming stuff, loops through each of the floats in the 3 float array of world up and world right
	and then multiplies it with the server random numbers, and lastly stored in the vecDest so that the line 
	will be angled towards the point in the server DLL, This is needed since Valve only allows 2 floats to 
	be transfered. *mad*
	*****************************************/
	for ( int i = 0 ; i < 3; i++ ) 
	{
		vecDest[i]+=(right[i]*fRecoilX+up[i]*fRecoilY);
	}

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1 , &tr ); //traces the line with the new vecDest

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_FLAMELICKFIRE],2);
	}
	m_iFlamelick=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/mushroom.spr");

	tr.endpos[2]+=32;

//	sprintf(strTest,"random: %f right %f up\n",fRecoilX,fRecoilY);

//	gEngfuncs.Con_Printf(strTest);

	gEngfuncs.pEfxAPI->R_Explosion(tr.endpos,m_iFlamelick,2,45,0);
}

void EV_LightningSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;
	vec3_t temp;

	pmtrace_t tr;

	int m_iBeam,m_iFireball;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	origin.x+=gEngfuncs.pfnRandomFloat(-30,30);
	origin.y+=gEngfuncs.pfnRandomFloat(-30,30);

	VectorCopy( origin,temp);
	temp.z=temp.z+1000;

	m_iBeam = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/smoke.spr");
	m_iFireball = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/zerogxplode.spr");

	float R=gEngfuncs.pfnRandomFloat(0,1);
	float G=gEngfuncs.pfnRandomFloat(0,1);
	float B=gEngfuncs.pfnRandomFloat(0,1);

	// Draw the Lightning
	gEngfuncs.pEfxAPI->R_BeamPoints(origin,temp,m_iBeam,.5,4,.5,1,0,0,0,R,G,B);

	origin.z+=16;

	// Draw the Explosion
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iFireball,1.5,15,TE_EXPLFLAG_NOSOUND);

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_VOICE,"garg/gar_stomp1.wav",1,ATTN_NORM,0,gEngfuncs.pfnRandomFloat(100,150));
}

void EV_MagicMissleSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	TEMPENTITY *te;

	int iMissle=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/flare6.spr");

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_MMFIRE],2);
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"spells/magicmissile.wav",1,ATTN_NORM,0,100);

	EV_GetGunPosition(args,vecSrc,origin);
	AngleVectors(angles,forward,right,up);

	VectorScale(right,-8,right);
	VectorScale(forward,16,forward);
	VectorScale(up,-8,up);
	VectorAdd(vecSrc,forward,vecSrc);
	VectorAdd(vecSrc,up,vecSrc);
	VectorAdd(vecSrc,right,vecSrc);

	AngleVectors(angles,forward,right,up);
	VectorScale(forward,1800,forward);

	te=gEngfuncs.pEfxAPI->R_TempSprite(vecSrc,forward,.8,iMissle,kRenderTransAdd,0,1,10,0);
	te->flags|=FTENT_SPRCYCLE;
	te->flags|=FTENT_COLLIDEALL;
	te->flags|=FTENT_COLLIDEKILL;
	te->clientIndex=idx;
}

void EV_DoubleMagicMissleSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward, offset;

	TEMPENTITY *te;

	int iMissle=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/flare6.spr");
	int bRight=args->bparam1;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_MMFIRE],2);
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"spells/magicmissile.wav",1,ATTN_NORM,0,100);

	EV_GetGunPosition(args,vecSrc,origin);
	AngleVectors(angles,forward,right,up);

	if(bRight)
		VectorScale(right,8,offset);
	else
		VectorScale(right,-8,offset);

	VectorScale(forward,16,forward);
	VectorScale(up,-8,up);
	VectorAdd(vecSrc,forward,vecSrc);
	VectorAdd(vecSrc,up,vecSrc);
	VectorAdd(vecSrc,offset,vecSrc);

	AngleVectors(angles,forward,right,up);
	VectorScale(forward,1800,forward);

	te=gEngfuncs.pEfxAPI->R_TempSprite(vecSrc,forward,.8,iMissle,kRenderTransAdd,0,1,10,0);
	te->flags|=FTENT_SPRCYCLE;
	te->flags|=FTENT_COLLIDEALL;
	te->flags|=FTENT_COLLIDEKILL;
	te->clientIndex=idx;
}

void EV_ForceSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int m_iForce;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_FORCEFIRE],2);
	}

	m_iForce=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/muz7.spr");

	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iForce,1,20,TE_EXPLFLAG_NOSOUND|TE_EXPLFLAG_NOPARTICLES);

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"houndeye/he_blast2.wav",.25,ATTN_NORM,0,100);
}

void EV_FireballSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_FIREBALLFIRE],2);
	}
}

void EV_IcepokeTrailStart(tempent_s *ent, float frametime, float currenttime){
	int iTrail=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/smoke.spr");
	vec3_t vecForward,vecRight,vecUp;

	ent->entity.angles.x*=-1;
	AngleVectors(ent->entity.angles,vecForward,vecRight,vecUp);
	ent->entity.angles.x*=-1;

	VectorScale(vecForward,-25,vecForward);
	VectorAdd(vecForward,ent->entity.origin,vecForward);

	gEngfuncs.pEfxAPI->R_BeamPoints(ent->entity.origin,vecForward,iTrail,.1,2,0,1,10,0,0,0,0,1);
}

void EV_IcepokeSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int iPoke=gEngfuncs.pEventAPI->EV_FindModelIndex("models/icepoke.mdl");

	TEMPENTITY *te;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx )){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_ICEPOKEFIRE],2);
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"spells/icepoke.wav",1,ATTN_NORM,0,gEngfuncs.pfnRandomFloat(100,150));

	for(int i=0;i<4;i++){
		EV_GetGunPosition(args,vecSrc,origin);
		VectorCopy(args->angles,angles);
		AngleVectors(angles,forward,right,up);
		VectorScale(forward,1000,forward);

		vecSrc.x+=gEngfuncs.pfnRandomFloat(-40,40);
		vecSrc.y+=gEngfuncs.pfnRandomFloat(-40,40);
		vecSrc.z+=gEngfuncs.pfnRandomFloat(-40,40);

		forward.x+=gEngfuncs.pfnRandomFloat(-40,40);
		forward.y+=gEngfuncs.pfnRandomFloat(-40,40);
		forward.z+=gEngfuncs.pfnRandomFloat(-40,40);

		angles.x*=-1;

		te=gEngfuncs.pEfxAPI->R_TempModel(vecSrc,forward,angles,10,iPoke,0);

		VectorCopy(forward,te->entity.baseline.velocity);
		te->entity.curstate.rendermode=kRenderTransColor;
		te->entity.curstate.renderamt=128;
		te->flags&=~FTENT_GRAVITY;
		te->flags|=FTENT_COLLIDEKILL;
		te->flags|=FTENT_CLIENTCUSTOM;
		te->flags|=FTENT_COLLIDEALL;
		te->clientIndex=idx;
		te->callback=EV_IcepokeTrailStart;
	}
}

void EV_SkullSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_SKULLFIRE],2);
		V_PunchAxis( 0, -10.0 );
	}
}

void EV_PoisonSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int m_iPoison;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	m_iPoison = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/stmbal1.spr");

	// Draw the Explosion
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iPoison,7,40,TE_EXPLFLAG_NOSOUND);

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_VOICE,"ambience/steamburst1.wav",1,ATTN_NORM,0,100);
}

void EV_EarthquakeSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_VOICE,"debris/bustconcrete2.wav",1,ATTN_NORM,0,100);
}

void EV_FireballTrail(struct event_args_s *args){
	int idx;

	idx = args->entindex;

	int m_iTrail=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/smoke.spr");
	
	gEngfuncs.pEfxAPI->R_BeamFollow(idx,m_iTrail,.5,20,1,1,0,1);
	gEngfuncs.pEfxAPI->R_BeamFollow(idx,m_iTrail,1,15,1,.7,.15,1);
	gEngfuncs.pEfxAPI->R_BeamFollow(idx,m_iTrail,1.5,10,.85,.55,.55,1);
}

void EV_RollingStoneSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_ROLLINGSTONEFIRE],2);
		V_PunchAxis( 0, -10.0 );
	}
}

void EV_BirdSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_BIRDFIRE],2);
		V_PunchAxis( 0, -10.0 );
	}
}

void EV_WyvernSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_WYVERNFIRE],2);
		V_PunchAxis( 0, -10.0 );
	}
}

void EV_MindMissleSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	TEMPENTITY *te;

	int iMissle=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/xspark1.spr");

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_MMFIRE],2);
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"spells/mindmissile.wav",1,ATTN_NORM,0,100);

	EV_GetGunPosition(args,vecSrc,origin);
	AngleVectors(angles,forward,right,up);

	VectorScale(right,-8,right);
	VectorScale(forward,16,forward);
	VectorScale(up,-8,up);
	VectorAdd(vecSrc,forward,vecSrc);
	VectorAdd(vecSrc,up,vecSrc);
	VectorAdd(vecSrc,right,vecSrc);

	AngleVectors(angles,forward,right,up);
	VectorScale(forward,1800,forward);

	te=gEngfuncs.pEfxAPI->R_TempSprite(vecSrc,forward,.8,iMissle,kRenderTransAdd,0,1,10,0);
	te->flags|=FTENT_SPRCYCLE;
	te->flags|=FTENT_COLLIDEALL;
	te->flags|=FTENT_COLLIDEKILL;
	te->clientIndex=idx;
}

enum{
	STAFF_IDLE = 0,
	STAFF_ATTACK1HIT,
	STAFF_ATTACK1MISS,
	STAFF_ATTACK2HIT,
	STAFF_ATTACK2MISS,
	STAFF_ATTACK3HIT,
	STAFF_ATTACK3MISS,
};

int g_iSwing=0;

void EV_StaffSwing(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	pmtrace_t tr;

	int stafftype=args->iparam1;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );

	VectorCopy( forward, vecAiming );

	VectorMA(vecSrc,50,forward,vecDest);

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1 , &tr );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	int iAnim=0;

	if ( EV_IsLocal( idx ) ){
		if(tr.fraction==1){
			switch(gEngfuncs.pfnRandomLong(0,2)){
				case(0):
					iAnim=STAFF_ATTACK1MISS;
					break;
				case(1):
					iAnim=STAFF_ATTACK2MISS;
					break;
				case(2):
					iAnim=STAFF_ATTACK3MISS;
					break;
			}
//			gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"weapons/cbar_miss1.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));		
		}
		else{
			switch(gEngfuncs.pfnRandomLong(0,2)){
				case(0):
					iAnim=STAFF_ATTACK1HIT;
					break;
				case(1):
					iAnim=STAFF_ATTACK2HIT;
					break;
				case(2):
					iAnim=STAFF_ATTACK3HIT;
					break;
			}

/*			physent_t *pe;

			pe=gEngfuncs.pEventAPI->EV_GetPhysent(tr.ent);

			if(pe && pe->solid==SOLID_BSP){
				if(stafftype==ICE_CLASS)
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"debris/glass2.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));
				else if(stafftype==LIGHTNING_CLASS || stafftype==DEATH_CLASS || stafftype==DRAGONWIZARD_CLASS)
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"weapons/cbar_hit1.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));
				else if(stafftype==EARTH_CLASS)
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"weapons/cbar_hit1.wav",1,ATTN_NORM,0,68+gEngfuncs.pfnRandomLong(0,6));
				else
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"debris/wood3.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));
			}
			else{
				switch(gEngfuncs.pfnRandomLong(0,3)){
				case(0):
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"weapons/cbar_hitbod1.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));
					break;
				case(1):
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"weapons/cbar_hitbod2.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));
					break;
				case(2):
					gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"weapons/cbar_hitbod3.wav",1,ATTN_NORM,0,98+gEngfuncs.pfnRandomLong(0,6));
					break;
				}
			}*/
		}

		gEngfuncs.pEventAPI->EV_WeaponAnimation(iAnim,2);
	}
}

void EV_BearBite(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	pmtrace_t tr;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );

	VectorCopy( forward, vecAiming );

	VectorMA(vecSrc,10,forward,vecDest);

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1 , &tr );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	int iAnim=0;

	if ( EV_IsLocal( idx ) ){
		iAnim=1;

		gEngfuncs.pEventAPI->EV_WeaponAnimation(iAnim,1);

		V_PunchAxis(0,25.0);
	}
}

void EV_SuctionSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int m_iSuction;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	m_iSuction = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/c-tele1.spr");

	origin[2]+=32;

	// Draw the Explosion
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iSuction,2,30,TE_EXPLFLAG_NONE);
}

void EV_FireSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int m_iFire;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	m_iFire = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/gexplo.spr");

	origin[2]+=32;

	// Draw the Explosion
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iFire,1,40,TE_EXPLFLAG_NONE);
	dlight_t *dl = gEngfuncs.pEfxAPI->CL_AllocDlight(0);
	VectorCopy (origin, dl->origin);
	dl->radius = 120;
	dl->color.r = 255;
	dl->color.g = 0;
	dl->color.b = 0;
	dl->die = gHUD.m_flTime + 3.0;
}

void EV_BurSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int m_iBur;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	m_iBur = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/blast.spr");

	origin[2]+=32;

	// Draw the Explosion
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iBur,1,20,TE_EXPLFLAG_NONE);
}

void EV_TCrystalFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int m_iCrystal;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	m_iCrystal = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/xspark2.spr");

	origin[2]+=32;

	// Draw the Explosion
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iCrystal,2,15,TE_EXPLFLAG_NOSOUND|TE_EXPLFLAG_NOPARTICLES);
	gEngfuncs.pEfxAPI->R_SparkShower(origin);
	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"debris/glass3.wav",1,ATTN_NORM,0,100);
}

void EV_ToothSatchelFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;

	int iTooth;
	TEMPENTITY *te;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	iTooth = gEngfuncs.pEventAPI->EV_FindModelIndex("models/dragontooth.mdl");

	for(int i=0;i<40;i++){
		forward[0]=gEngfuncs.pfnRandomFloat(-1,1);
		forward[1]=gEngfuncs.pfnRandomFloat(-1,1);
		forward[2]=gEngfuncs.pfnRandomFloat(-1,1);

		VectorNormalize(forward);
		VectorScale(forward,600,forward);

		te=gEngfuncs.pEfxAPI->R_TempModel(origin,forward,forward,2,iTooth,0);

		VectorCopy(forward,te->entity.baseline.velocity);
		te->flags&=~FTENT_GRAVITY;
		te->flags|=FTENT_COLLIDEKILL;
	}
	
	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,THORNBLASTSPELL_SOUND_SHOOT,1,ATTN_NORM,0,gEngfuncs.pfnRandomFloat(100,150));
}


void EV_GibHit(tempent_s *ent, pmtrace_s *pTrace){
	physent_t *pe;

	char decalName[20];

	if(ent->entity.curstate.iuser1)
		sprintf(decalName,"{blood%d",gEngfuncs.pfnRandomLong(1,8));
	else
		sprintf(decalName,"{yblood%d",gEngfuncs.pfnRandomLong(1,6));

	pe = gEngfuncs.pEventAPI->EV_GetPhysent( pTrace->ent );

	// Only decal brush models such as the world etc.
	if (  decalName && decalName[0] && pe && ( pe->solid == SOLID_BSP || pe->movetype == MOVETYPE_PUSHSTEP ) )
	{
		if ( CVAR_GET_FLOAT( "r_decals" ) )
		{
			gEngfuncs.pEfxAPI->R_DecalShoot( 
				gEngfuncs.pEfxAPI->Draw_DecalIndex( gEngfuncs.pEfxAPI->Draw_DecalIndexFromName( decalName ) ), 
				gEngfuncs.pEventAPI->EV_IndexFromTrace( pTrace ), 0, pTrace->endpos, 0 );
		}
	}
}

extern cvar_t *cl_gibcount;

void EV_Gibs(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;
	vec3_t forward,right,up;

	TEMPENTITY *te;

	int human=args->bparam1;

	vec3_t endpos;
	VectorClear(endpos);

	int iGibs;
	
	if(human)
		iGibs=gEngfuncs.pEventAPI->EV_FindModelIndex("models/hgibs.mdl");
	else
		iGibs=gEngfuncs.pEventAPI->EV_FindModelIndex("models/agibs.mdl");

	VectorCopy(args->origin,origin);
	VectorCopy(args->angles,angles);

	if(cl_gibcount->value>300)
		cl_gibcount->value=300;

	for(int x=0;x<cl_gibcount->value;x++){
		AngleVectors(angles,forward,right,up);

		forward[0]+=gEngfuncs.pfnRandomFloat(-.2,.2);
		forward[1]+=gEngfuncs.pfnRandomFloat(-.2,.2);
		forward[2]+=gEngfuncs.pfnRandomFloat(-.2,.2);

		VectorScale(forward,args->fparam1,forward);

		origin.x+=gEngfuncs.pfnRandomFloat(-20,20);
		origin.y+=gEngfuncs.pfnRandomFloat(-20,20);
		origin.z+=gEngfuncs.pfnRandomFloat(-20,20);

		endpos[0]=gEngfuncs.pfnRandomFloat(-200,200);
		endpos[1]=gEngfuncs.pfnRandomFloat(-200,200);
		endpos[2]=gEngfuncs.pfnRandomFloat(-200,200);

		te=gEngfuncs.pEfxAPI->R_TempModel(origin,forward,endpos,gEngfuncs.pfnRandomFloat(8,12),iGibs,0);
		
		if(te){
			te->flags|=FTENT_CLIENTCUSTOM;
			te->clientIndex=idx;
			te->hitcallback=EV_GibHit;
			te->entity.curstate.iuser1=human;		//For decals
		
			if(te->entity.curstate.body==0)
				te->entity.curstate.body=1;
		}
	}
}

void EV_DeathFlash(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;
	vec3_t forward,right,up;
	int m_iFlash;

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	m_iFlash=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/xspark1.spr");
	gEngfuncs.pEfxAPI->R_Explosion(origin,m_iFlash,10,10,TE_EXPLFLAG_NONE);
	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_WEAPON,"garg/gar_stomp1.wav",.25,ATTN_NORM,0,150);

//	te=gEngfuncs.pEfxAPI->R_TempSprite(vecSrc,forward,.8,iMissle,kRenderTransAdd,0,1,10,0);
}

void EV_DragonFireTrail(tempent_s *ent, float frametime, float currenttime){
	TEMPENTITY *te;
	vec3_t velocity;

	if((gEngfuncs.pfnRandomLong(0,10))%10==0){
		int iTrail=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/gargeye1.spr");
		int flags=FTENT_SPRCYCLE|FTENT_FADEOUT|FTENT_COLLIDEALL|FTENT_GRAVITY;
		float life=gEngfuncs.pfnRandomFloat(.2,.8);
		float size=gEngfuncs.pfnRandomFloat(.2,.5);

		velocity[0]+=gEngfuncs.pfnRandomFloat(-80,80);
		velocity[1]+=gEngfuncs.pfnRandomFloat(-80,80);
		velocity[2]+=gEngfuncs.pfnRandomFloat(-80,80);

		te=gEngfuncs.pEfxAPI->R_TempSprite(ent->entity.origin,velocity,size,iTrail,kRenderGlow,kRenderFxNoDissipation,1,life,flags);
	}
}

void EV_DragonFireHit(tempent_s *ent,pmtrace_s *pTrace){
	int iExplode=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/fexplo1.spr");

	VectorMA(ent->entity.origin,40,pTrace->plane.normal,ent->entity.origin);

	gEngfuncs.pEfxAPI->R_Explosion(ent->entity.origin,iExplode,1.5,40,TE_EXPLFLAG_NONE);
}

void EV_DragonFire(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;
	vec3_t forward,right,up;
	int iDragonFlame;
	TEMPENTITY *te;
	float size;
	float alpha;
	float flLife=args->fparam1;
	
	if(flLife==0)
		flLife=10;

	iDragonFlame=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/xspark4.spr");

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	angles[0]*=-1;
	AngleVectors(angles,forward,right,up);
	VectorScale(forward,1400,forward);

	size=gEngfuncs.pfnRandomFloat(1,1.5);
	alpha=gEngfuncs.pfnRandomFloat(.5,1);

	te=gEngfuncs.pEfxAPI->R_TempSprite(origin,forward,size,iDragonFlame,kRenderTransAdd,kRenderFxNone,alpha,flLife,0);

	if(te){
		te->flags|=FTENT_SPRCYCLE;
		te->flags|=FTENT_COLLIDEALL;
		te->flags|=FTENT_COLLIDEKILL;
		te->flags|=FTENT_CLIENTCUSTOM;
		te->clientIndex=idx;
		te->callback=EV_DragonFireTrail;
		te->hitcallback=EV_DragonFireHit;
	}	
}

void EV_DragonFlap(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;

	VectorCopy(args->origin,origin);

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_VOICE,"dragon/fly1.wav",1,ATTN_NORM,0,100);
}

void EV_SporePodFire(struct event_args_s *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;
	TEMPENTITY *te;
	int iPoison;

	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	iPoison = gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/stmbal1.spr");

	// Draw the Explosion
	te=gEngfuncs.pEfxAPI->R_TempSprite(origin,forward,7,iPoison,kRenderTransAdd,kRenderFxNone,.5,1,0);
	
	if(te){
		te->flags|=FTENT_SPRANIMATE;
		te->entity.curstate.framerate=40;
		te->entity.curstate.rendercolor.r=0;
		te->entity.curstate.rendercolor.g=255;
		te->entity.curstate.rendercolor.b=0;
	}

	gEngfuncs.pEventAPI->EV_PlaySound(idx,origin,CHAN_VOICE,"ambience/steamburst1.wav",1,ATTN_NORM,0,100);
}

void EV_ThornbushUpgrade(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;
	int	iSpark=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/xspark3.spr");
	float size=0;
	vec3_t temp,forward,start;
	TEMPENTITY *te;

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	for(int x=0;x<15;x++){
		size=gEngfuncs.pfnRandomFloat(.2,.5);
		VectorCopy(origin,start);

		temp.x=gEngfuncs.pfnRandomFloat(-1,1);
		temp.y=gEngfuncs.pfnRandomFloat(-1,1);
		temp.z=gEngfuncs.pfnRandomFloat(0,2);
		VectorNormalize(temp);
		VectorCopy(temp,forward);
		VectorMA(start,100,temp,start);

		forward.x*=-1;
		forward.y*=-1;
		forward.z*=-1;
		VectorScale(forward,100,forward);

		te=gEngfuncs.pEfxAPI->R_TempSprite(start,forward,size,iSpark,kRenderTransAdd,kRenderFxNone,.5,1,0);

		if(te){
			te->flags|=FTENT_SPRCYCLE;
			te->flags|=FTENT_SPIRAL;
			te->flags|=FTENT_SMOKETRAIL;
		}
	}
}

extern vec3_t v_origin;

extern "C" int CL_IsThirdPerson();

void EV_ShieldSpellTrail(tempent_s *ent, float frametime, float currenttime){
	float s, c;
	float fastFreq=currenttime*5.5;

	s = sin( ent->entity.baseline.origin[2] + fastFreq );
	c = cos( ent->entity.baseline.origin[2] + fastFreq );

	cl_entity_t *pClient;

	pClient = gEngfuncs.GetEntityByIndex(ent->clientIndex);
	
	if(gEngfuncs.pEventAPI->EV_IsLocal(ent->clientIndex-1) && !CL_IsThirdPerson()){
		VectorAdd( v_origin, ent->tentOffset, ent->entity.origin );
	}
	else if(pClient){
		VectorAdd( pClient->origin, ent->tentOffset, ent->entity.origin );
	}

	ent->entity.origin[0]+=ent->entity.baseline.origin[0] * frametime + 80 * sin(currenttime * 10+(int)ent*2);
	ent->entity.origin[1]+=ent->entity.baseline.origin[1] * frametime + 80 * cos(currenttime * 10+(int)ent*2);
	ent->entity.origin[2]+=ent->entity.baseline.origin[2] * frametime;
}

void EV_ShieldSpellFire(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;
	int	iSpark=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/armorspell.spr");
	float size=0;
	vec3_t temp,forward,start;
	TEMPENTITY *te;

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	temp.x=0;
	temp.y=0;
	temp.z=-40;

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_SHIELDFIRE],2);

		V_PunchAxis(0,25.0);
	}

	for(int y=0;y<4;y++){
		for(int x=0;x<4;x++){
			te=gEngfuncs.pEfxAPI->R_TempSprite(temp,temp,size,iSpark,kRenderTransAdd,kRenderFxNone,1,.3,0);

			if(te){
				te->flags|=FTENT_SPRCYCLE;
				te->flags|=FTENT_FADEOUT;
				te->flags|=FTENT_SMOKETRAIL;
				te->flags|=FTENT_CLIENTCUSTOM;
				te->clientIndex=idx;
				VectorCopy(temp,te->tentOffset);
				te->fadeSpeed=2;
				te->callback=EV_ShieldSpellTrail;
			}
		}

		temp.z+=20;
	}
}

void EV_MakeFlame(int idx);
void EV_FlameCallback(tempent_s *ent, float frametime, float currenttime){
	if(ent->die-currenttime<0 && !(ent->flags&FTENT_FLICKER)){
		ent->flags|=FTENT_FLICKER;

		if(gEngfuncs.pfnRandomLong(0,10)>3)
			EV_MakeFlame(ent->clientIndex);
	}
}

void EV_MakeFlame(int idx){
	vec3_t temp;
	int iFlame=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/fire.spr");
	float size=gEngfuncs.pfnRandomFloat(.4,.6);
	TEMPENTITY *te;

	temp.x=gEngfuncs.pfnRandomFloat(-10,10);
	temp.y=gEngfuncs.pfnRandomFloat(-10,10);
	VectorNormalize(temp);
	VectorScale(temp,40,temp);
	temp.z=gEngfuncs.pfnRandomFloat(-40,40);

	te=gEngfuncs.pEfxAPI->R_TempSprite(temp,temp,size,iFlame,kRenderTransAdd,kRenderFxNone,1,.2,0);
	
	if(te){
		te->flags|=FTENT_SPRCYCLE;
		te->flags|=FTENT_FADEOUT;
		te->flags|=FTENT_PLYRATTACHMENT;
		te->flags|=FTENT_CLIENTCUSTOM;
		te->clientIndex=idx;
		VectorCopy(temp,te->tentOffset);
		te->fadeSpeed=4;
		te->callback=EV_FlameCallback;
	}
}

void EV_Burn(struct event_args_s *args){
	int idx=args->entindex;

	if(gEngfuncs.pEventAPI->EV_IsLocal(idx-1)){
		gEngfuncs.pEventAPI->EV_PlaySound(idx,args->origin,CHAN_BODY,"ambience/burn.wav",1,ATTN_NORM,0,PITCH_NORM);
	}

	for(int x=0;x<15;x++){
		EV_MakeFlame(idx);
	}
}

void EV_SparkCallback(tempent_s *ent, float frametime, float currenttime){
	vec3_t origin,start,end;
	int iFlame=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/fire.spr");

	if(gEngfuncs.pEventAPI->EV_IsLocal(ent->clientIndex-1)){
		if(CL_IsThirdPerson()){
			VectorCopy(ent->entity.origin,origin);
		}
		else
			VectorCopy(v_origin,origin);

		if(gEngfuncs.pfnRandomLong(0,10)==2){
			V_PunchAxis(0,gEngfuncs.pfnRandomFloat(-5,5));
			gEngfuncs.pEventAPI->EV_PlaySound(-1,origin,0,"buttons/spark5.wav",0.6,ATTN_NORM,0,gEngfuncs.pfnRandomLong(80,120));
		}
	}
	else
		VectorCopy(ent->entity.origin,origin);

	VectorCopy(origin,start);
	VectorCopy(origin,end);

	start[0]+=gEngfuncs.pfnRandomFloat(-40,40);
	start[1]+=gEngfuncs.pfnRandomFloat(-40,40);
	start[2]+=gEngfuncs.pfnRandomFloat(-40,40);
	end[0]+=gEngfuncs.pfnRandomFloat(-40,40);
	end[1]+=gEngfuncs.pfnRandomFloat(-40,40);
	end[2]+=gEngfuncs.pfnRandomFloat(-40,40);

	gEngfuncs.pEfxAPI->R_BeamPoints(start,end,iFlame,.2,.5,1,1,0,0,0,1,1,0);

	VectorCopy(origin,start);

	start[0]+=gEngfuncs.pfnRandomFloat(-20,20);
	start[1]+=gEngfuncs.pfnRandomFloat(-20,20);
	start[2]+=gEngfuncs.pfnRandomFloat(-20,20);

	gEngfuncs.pEfxAPI->R_SparkEffect(start,3,-200,200);
}

void EV_MakeSpark(int idx){
	vec3_t temp;
	TEMPENTITY *te;
	int iFlame=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/fire.spr");

	te=gEngfuncs.pEfxAPI->R_TempSprite(temp,temp,1,iFlame,kRenderTransAdd,kRenderFxNone,0,gEngfuncs.pfnRandomFloat(1,2),0);
	
	if(te){
		te->flags|=FTENT_PLYRATTACHMENT;
		te->flags|=FTENT_CLIENTCUSTOM;
		te->flags|=FTENT_NOMODEL;
		te->clientIndex=idx;
		te->callback=EV_SparkCallback;
	}
}	

void EV_Spark(struct event_args_s *args){
	int idx=args->entindex;
	
	for(int x=0;x<3;x++){
		EV_MakeSpark(idx);
	}
}

void EV_Taunt(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;

	if(EV_IsLocal(idx)){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_TAUNT],2);
	}
	
	VectorCopy( args->origin, origin );

	switch((int)gEngfuncs.pfnRandomLong(0,5)){
		case(0):
			gEngfuncs.pEventAPI->EV_PlaySound(-1,origin,0,"player/taunt1.wav",0.6,ATTN_NORM,0,100);
			break;
		case(1):
			gEngfuncs.pEventAPI->EV_PlaySound(-1,origin,0,"player/taunt2.wav",0.6,ATTN_NORM,0,100);
			break;
		case(2):
			gEngfuncs.pEventAPI->EV_PlaySound(-1,origin,0,"player/taunt3.wav",0.6,ATTN_NORM,0,100);
			break;
		case(3):
			gEngfuncs.pEventAPI->EV_PlaySound(-1,origin,0,"player/taunt4.wav",0.6,ATTN_NORM,0,100);
			break;
		default:
			gEngfuncs.pEventAPI->EV_PlaySound(-1,origin,0,"player/taunt5.wav",0.6,ATTN_NORM,0,100);
			break;
	}
}

void EV_UpdraftSpellFire(event_args_t *args){
	int idx;
	vec3_t origin;
	vec3_t angles;

	vec3_t vecSrc, vecDest, vecAiming;
	vec3_t up, right, forward;
	vec3_t temp;

	pmtrace_t	tr;

	int m_iFlamelick;

	TEMPENTITY *te;

	temp[0]=0;
	temp[1]=0;
	temp[2]=0;
	
	idx = args->entindex;
	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors( angles, forward, right, up );

	EV_GetGunPosition( args, vecSrc, origin );

	VectorCopy( forward, vecAiming );

	VectorMA( vecSrc, 8192, forward, vecDest );

	gEngfuncs.pEventAPI->EV_SetUpPlayerPrediction( false, true );
	
	// Store off the old count
	gEngfuncs.pEventAPI->EV_PushPMStates();

	// Now add in all of the players.
	gEngfuncs.pEventAPI->EV_SetSolidPlayers ( idx - 1 );	

	gEngfuncs.pEventAPI->EV_SetTraceHull( 2 );

	gEngfuncs.pEventAPI->EV_PlayerTrace( vecSrc, vecDest, PM_STUDIO_BOX, -1 , &tr );

	gEngfuncs.pEventAPI->EV_PopPMStates();

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_FLAMELICKFIRE],2);
	}
	m_iFlamelick=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/updraft.spr");

	tr.endpos[2]+=32;

	te=gEngfuncs.pEfxAPI->R_TempSprite(tr.endpos,temp,.5,m_iFlamelick,kRenderTransAdd,kRenderFxNone,1,1,FTENT_SPRANIMATE);
	if(te){
		te->entity.curstate.framerate=20;
		te->entity.curstate.rendercolor.r=255;
		te->entity.curstate.rendercolor.g=255;
		te->entity.curstate.rendercolor.b=255;
	}

	gEngfuncs.pEfxAPI->R_Explosion(tr.endpos,m_iFlamelick,0,45,0);
}

void EV_DragonbreathSpellFire(struct event_args_s *args){
	int idx=args->entindex;
	vec3_t origin;
	vec3_t angles;
	vec3_t forward,right,up;
	int iDragonFlame;
	TEMPENTITY *te;
	float size;
	float alpha;
	float flLife=args->fparam1;
	
	if(flLife==0)
		flLife=.3;

	iDragonFlame=gEngfuncs.pEventAPI->EV_FindModelIndex("sprites/xspark4.spr");

	VectorCopy( args->origin, origin );
	VectorCopy( args->angles, angles );

	AngleVectors(angles,forward,right,up);
	VectorScale(forward,550,forward);

	forward[0]+=gEngfuncs.pfnRandomFloat(-100,100);
	forward[1]+=gEngfuncs.pfnRandomFloat(-100,100);
	forward[2]+=gEngfuncs.pfnRandomFloat(-100,100);

	size=gEngfuncs.pfnRandomFloat(1,1.5);
	alpha=gEngfuncs.pfnRandomFloat(.5,1);

	te=gEngfuncs.pEfxAPI->R_TempSprite(origin,forward,size,iDragonFlame,kRenderTransAdd,kRenderFxNone,alpha,flLife,0);

	if(te){
		te->flags|=FTENT_SPRCYCLE;
		te->flags|=FTENT_COLLIDEALL;
		te->flags|=FTENT_COLLIDEKILL;
		te->flags|=FTENT_CLIENTCUSTOM;
		te->clientIndex=idx;
		te->callback=EV_DragonFireTrail;
		te->hitcallback=EV_DragonFireHit;
	}	

	if ( EV_IsLocal( idx ) ){
		gEngfuncs.pEventAPI->EV_WeaponAnimation(FirstPersonAnims[FPANIMS_DRAGONBREATHFIRE],2);
	}
}