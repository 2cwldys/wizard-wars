/***
*
*	Copyright (c) 1999, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#include "../hud.h"
#include "../cl_util.h"
#include "event_api.h"

extern "C"
{
// HLDM
//void EV_FireGlock1( struct event_args_s *args  );
//void EV_FireGlock2( struct event_args_s *args  );
void EV_FireShotGunSingle( struct event_args_s *args  );
void EV_FireShotGunDouble( struct event_args_s *args  );
void EV_FireMP5( struct event_args_s *args  );
void EV_FirePython( struct event_args_s *args  );
void EV_FireGauss( struct event_args_s *args  );
void EV_SpinGauss( struct event_args_s *args  );
void EV_TrainPitchAdjust( struct event_args_s *args );

//WIZWARS
void EV_SpotboltSpellFire(struct event_args_s *args);
void EV_SpotboltSpellCharge(struct event_args_s *args);
void EV_LightningboltSpellFire(struct event_args_s *args);
void EV_ThornblastSpellFire(struct event_args_s *args);
void EV_FlamelickSpellFire(struct event_args_s *args);
void EV_MagicMissleSpellFire(struct event_args_s *args);
void EV_DoubleMagicMissleSpellFire(struct event_args_s *args);
void EV_ForceSpellFire(struct event_args_s *args);
void EV_FireballSpellFire(struct event_args_s *args);
void EV_IcepokeSpellFire(struct event_args_s *args);
void EV_SkullSpellFire(struct event_args_s *args);
void EV_RollingStoneSpellFire(struct event_args_s *args);
void EV_BirdSpellFire(struct event_args_s *args);
void EV_MindMissleSpellFire(struct event_args_s *args);
void EV_StaffSwing(struct event_args_s *args);
void EV_BearBite(struct event_args_s *args);
void EV_ShieldSpellFire(struct event_args_s *args);
void EV_UpdraftSpellFire(struct event_args_s *args);
void EV_DragonbreathSpellFire(struct event_args_s *args);
void EV_WyvernSpellFire(struct event_args_s *args);

void EV_LightningSatchelFire(struct event_args_s *args);
void EV_PoisonSatchelFire(struct event_args_s *args);
void EV_EarthquakeSatchelFire(struct event_args_s *args);
void EV_SuctionSatchelFire(struct event_args_s *args);
void EV_FireSatchelFire(struct event_args_s *args);
void EV_BurSatchelFire(struct event_args_s *args);
void EV_TCrystalFire(struct event_args_s *args);
void EV_ToothSatchelFire(struct event_args_s *args);

void EV_DragonFire(struct event_args_s *args);
void EV_DragonFlap(struct event_args_s *args);

void EV_FireballTrail(struct event_args_s *args);
void EV_Gibs(struct event_args_s *args);
void EV_DeathFlash(struct event_args_s *args);
void EV_ThornbushUpgrade(struct event_args_s *args);
void EV_SporePodFire(struct event_args_s *args);
void EV_Burn(struct event_args_s *args);
void EV_Spark(struct event_args_s *args);
void EV_Taunt(struct event_args_s *args);
}

/*
======================
Game_HookEvents

Associate script file name with callback functions.  Callback's must be extern "C" so
 the engine doesn't get confused about name mangling stuff.  Note that the format is
 always the same.  Of course, a clever mod team could actually embed parameters, behavior
 into the actual .sc files and create a .sc file parser and hook their functionality through
 that.. i.e., a scripting system.

That was what we were going to do, but we ran out of time...oh well.
======================
*/
void Game_HookEvents( void )
{
//	gEngfuncs.pfnHookEvent( "events/glock1.sc",					EV_FireGlock1 );
//	gEngfuncs.pfnHookEvent( "events/glock2.sc",					EV_FireGlock2 );
	gEngfuncs.pfnHookEvent( "events/shotgun1.sc",				EV_FireShotGunSingle );
	gEngfuncs.pfnHookEvent( "events/shotgun2.sc",				EV_FireShotGunDouble );
	gEngfuncs.pfnHookEvent( "events/mp5.sc",					EV_FireMP5 );
	gEngfuncs.pfnHookEvent( "events/python.sc",					EV_FirePython );
	gEngfuncs.pfnHookEvent( "events/gauss.sc",					EV_FireGauss );
	gEngfuncs.pfnHookEvent( "events/gaussspin.sc",				EV_SpinGauss );
	gEngfuncs.pfnHookEvent( "events/train.sc",					EV_TrainPitchAdjust );

//WIZWARS
	gEngfuncs.pfnHookEvent( "events/spells/spotboltspellfire.sc",		EV_SpotboltSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/spotboltspellcharge.sc",		EV_SpotboltSpellCharge);
	gEngfuncs.pfnHookEvent( "events/spells/lightningboltspellfire.sc",	EV_LightningboltSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/thornblastspellfire.sc",		EV_ThornblastSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/flamelickspellfire.sc",		EV_FlamelickSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/magicmisslespellfire.sc",	EV_MagicMissleSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/doublemagicmisslespellfire.sc",	EV_DoubleMagicMissleSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/forcespellfire.sc",			EV_ForceSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/fireballspellfire.sc",		EV_FireballSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/icepokespellfire.sc",		EV_IcepokeSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/skullspellfire.sc",			EV_SkullSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/rollingstonespellfire.sc",	EV_RollingStoneSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/birdspellfire.sc",			EV_BirdSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/mindmisslespellfire.sc",		EV_MindMissleSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/staffswing.sc",				EV_StaffSwing);
	gEngfuncs.pfnHookEvent( "events/spells/bearbite.sc",				EV_BearBite);
	gEngfuncs.pfnHookEvent( "events/spells/shieldspellfire.sc",			EV_ShieldSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/updraftspellfire.sc",		EV_UpdraftSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/dragonbreathspellfire.sc",	EV_DragonbreathSpellFire);
	gEngfuncs.pfnHookEvent( "events/spells/wyvernspellfire.sc",			EV_WyvernSpellFire);

	gEngfuncs.pfnHookEvent( "events/satchels/lightningsatchelfire.sc",	EV_LightningSatchelFire);
	gEngfuncs.pfnHookEvent( "events/satchels/poisonsatchelfire.sc",		EV_PoisonSatchelFire);
	gEngfuncs.pfnHookEvent( "events/satchels/earthquakesatchelfire.sc",	EV_EarthquakeSatchelFire);
	gEngfuncs.pfnHookEvent( "events/satchels/suctionsatchelfire.sc",	EV_SuctionSatchelFire);
	gEngfuncs.pfnHookEvent( "events/satchels/firesatchelfire.sc",		EV_FireSatchelFire);
	gEngfuncs.pfnHookEvent( "events/satchels/bursatchelfire.sc",		EV_BurSatchelFire);
	gEngfuncs.pfnHookEvent( "events/satchels/tcrystalfire.sc",			EV_TCrystalFire);
	gEngfuncs.pfnHookEvent( "events/satchels/toothsatchelfire.sc",		EV_ToothSatchelFire);

	gEngfuncs.pfnHookEvent( "events/monsters/dragon/dragonfire.sc",		EV_DragonFire);
	gEngfuncs.pfnHookEvent( "events/monsters/dragon/dragonflap.sc",		EV_DragonFlap);

	gEngfuncs.pfnHookEvent( "events/fireballtrail.sc",					EV_FireballTrail);
	gEngfuncs.pfnHookEvent( "events/gibs.sc",							EV_Gibs);
	gEngfuncs.pfnHookEvent( "events/deathflash.sc",						EV_DeathFlash);
	gEngfuncs.pfnHookEvent( "events/thornbushupgrade.sc",				EV_ThornbushUpgrade);
	gEngfuncs.pfnHookEvent( "events/sporepodfire.sc",					EV_SporePodFire);
	gEngfuncs.pfnHookEvent( "events/burn.sc",							EV_Burn);
	gEngfuncs.pfnHookEvent( "events/spark.sc",							EV_Spark);
	gEngfuncs.pfnHookEvent(	"events/taunt.sc",							EV_Taunt);
}