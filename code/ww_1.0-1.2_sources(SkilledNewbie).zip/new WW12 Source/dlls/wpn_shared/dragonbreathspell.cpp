#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

#define DRAGONBREATHSPELL_DELAY			.1
#define DRAGONBREATHSPELL_DAMAGE		20
#define DRAGONBREATHSPELL_COST			2

LINK_ENTITY_TO_CLASS( weapon_dragonbreathspell, CDragonbreathSpell);

void CDragonbreathSpell::Precache( void ){
	PRECACHE_SOUND("controller/con_attack3.wav");
	UTIL_PrecacheOther("proj_dragonfire");

	m_usDragonbreathSpellFire=PRECACHE_EVENT(1,"events/spells/dragonbreathspellfire.sc");

	m_iIdleAnim=FPANIMS_DRAGONBREATHIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CDragonbreathSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = DRAGONBREATHSPELL_SLOT;
	p->iPosition = DRAGONBREATHSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_DRAGONBREATHSPELL;
	p->iWeight = DRAGONBREATHSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CDragonbreathSpell::PrimaryAttack( void ){
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=DRAGONBREATHSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + DRAGONBREATHSPELL_DELAY; 
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + 30/14;

	Vector vecOrigin=m_pPlayer->GetGunPosition();
	Vector vecVelocity;
	Vector vecAngles;

	UTIL_MakeVectors(m_pPlayer->pev->angles);
	vecAngles=m_pPlayer->pev->angles;
	UTIL_MakeVectors(vecAngles);
	vecVelocity=gpGlobals->v_forward*1400;
	vecVelocity[0]+=RANDOM_FLOAT(-100,100);
	vecVelocity[1]+=RANDOM_FLOAT(-100,100);
	vecVelocity[2]+=RANDOM_FLOAT(-100,100);

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 

#ifndef CLIENT_DLL
	CBaseEntity *pEnt=Create("proj_dragonfire",vecOrigin,vecAngles,m_pPlayer->edict());
	pEnt->pev->velocity=vecVelocity;
	pEnt->pev->nextthink=gpGlobals->time+.3;
	pEnt->pev->dmg=20;
	pEnt->pev->team=m_pPlayer->pev->team;

	vecAngles=UTIL_VecToAngles(vecVelocity);
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usDragonbreathSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}
