/*
	FlamelickSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

/*
	8-10-02 FINALLY got the flamelick randomization working:

		Thought I'd comment in what I did so that you could learn how to successfully randomize shared
	numbers between the client and server since the engine is set up horribly for doing so.
	Basically you have to look at the PLAYBACK_EVEN_FULL macro and see that the last 6 parameters transfers
	numbers from the server DLL to the client DLL. As I found out this was REALLY restrictive. First of all,
	any variable with the gpGlobals->v_right, v_up, or v_forward automatically comes out 0. Don't ask me why,
	it's just some crazy thing Valve did. Next notice that you can't transfer Vectors, and also that you can
	only transfer 2 floats. This sucks because there are 3 floats in a vector, so you have to find another way
	to get the exact position you got on the server DLL.
		Now onto my rant about the shared random system. The RANDOM_FLOAT macro can't be used in this case since it
	is called for each DLL so you would get two completely different numbers for the two DLLs. Then there is a
	UTIL_RandomFloat which does keep the number generated the same number for both DLLs. The problem is that
	it needs an int to be seeded with. and there is only one m_pPlayer->random_seed value, and if you need to use that
	twice, you get the same random number for both X and Y. I tried to use the RANDOM_FLOAT macro as seeds, but it again had two
	different values for each DLL.
		I solved this problem by using gpGlobals->time to get the current time (and Valve was nice enough to have
	that not return 0) and the number would be slightly different for each seed. However, time remains constant in both
	DLLs so both numbers will be seeded the same way in both the server and the client, thereby returning the same randomly
	generated numbers for both DLLs. Finally, to get the same origin as the server has, I did some math stuff in the
	flamelick fire event in the ev_wizardwars.cpp file. Check it out and marvel at my 1337 programming. :)

	Other stuff done:
	-Upped flamelick cost by 1.
	-Gimped the updrafted spell damage from 15 to 5. (It's a tactical spell, not a cannon)

	~SkilledNewbie
	*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define FLAMELICKSPELL_SOUND_SHOOT	"spells/flamelick.wav" 
#define FLAMELICKSPELL_SOUND_VOLUME	0.25 
#define FLAMELICKSPELL_DELAY		0.45
#define FLAMELICKSPELL_DAMAGE		15
#define FLAMELICKSPELL_COST			4 //+1

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_flamelickspell, CFlamelickSpell);

void CFlamelickSpell::Precache( void ){
	PRECACHE_SOUND (FLAMELICKSPELL_SOUND_SHOOT);
	MushroomSprite = PRECACHE_MODEL ("sprites/mushroom.spr");
	m_usFlamelickSpellFire=PRECACHE_EVENT(1,"events/spells/flamelickspellfire.sc");

	m_iIdleAnim=FPANIMS_FLAMELICKIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CFlamelickSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = FLAMELICKSPELL_SLOT;
	p->iPosition = FLAMELICKSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_FLAMELICKSPELL;
	p->iWeight = FLAMELICKSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CFlamelickSpell::PrimaryAttack( void ){

	int seedX = gpGlobals->time; //seed for X with the current time.
	int seedY = gpGlobals->time; //seed for Y with the current time.

	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=FLAMELICKSPELL_COST;


	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle );
	Vector AimingDir = gpGlobals->v_forward;
	Vector GunPosition = m_pPlayer->GetGunPosition( ); 
	Vector EndPoint = GunPosition + AimingDir * 8192;
	Vector vecDir = Vector(/*gpGlobals->v_right**/UTIL_SharedRandomFloat( m_pPlayer->random_seed, -600.0, 600.0 ),/*gpGlobals->v_up**/UTIL_SharedRandomFloat( seedY, -600.0, 600.0 ),0); //shared random numbers

	TraceResult TResult; 
	edict_t* EntityToIgnore; 
	EntityToIgnore = ENT( m_pPlayer->pev );
    UTIL_TraceLine( GunPosition, EndPoint+(gpGlobals->v_right*vecDir.x+gpGlobals->v_up*vecDir.y), dont_ignore_monsters, EntityToIgnore, &TResult ); //Multiply the random number with world right and world up.
/*#ifndef CLIENT_DLL
	UTIL_ParticleEffect(TResult.vecEndPos,GunPosition,255,255); //For seeing where the server traceline hits and compare it to where the client side flames appear.[Debug]
#endif*/

	ClearMultiDamage( ); 

#ifndef CLIENT_DLL
	if(TResult.pHit && VARS(TResult.pHit)->takedamage)
		if (Instance(TResult.pHit)->pev->waterlevel>=1)
			Instance(TResult.pHit)->TakeDamage(pev,m_pPlayer->pev,5,DMG_BURN|DMG_SLOWBURN);
		else
			Instance(TResult.pHit)->TakeDamage(pev,m_pPlayer->pev,2,NULL);

	
	::RadiusDamage( TResult.vecEndPos, pev, m_pPlayer->pev, FLAMELICKSPELL_DAMAGE, 128, CLASS_NONE, DMG_BLAST | DMG_BURN);
#endif

	int flags;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#else
	flags=0;
#endif

	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usFlamelickSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,vecDir.x,vecDir.y,0,0,1,0); //5th and 6th from the last parm are the floats that can be transfered. yes, only 2 :(

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + FLAMELICKSPELL_DELAY; 
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_FLAMELICKFIRE];
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 
}
