/*
	FireballSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define FIREBALLSPELL_DELAY			1.7
#define FIREBALLSPELL_COST			20

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_fireballspell, CFireballSpell );

void CFireballSpell::Precache( void ){
	m_usFireballSpellFire=PRECACHE_EVENT(1,"events/spells/fireballspellfire.sc");

	m_iIdleAnim=FPANIMS_FIREBALLIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CFireballSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = FIREBALLSPELL_SLOT;
	p->iPosition = FIREBALLSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_FIREBALLSPELL;
	p->iWeight = FIREBALLSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CFireballSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<FIREBALLSPELL_COST) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=FIREBALLSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + FIREBALLSPELL_DELAY;
	m_pPlayer->pev->punchangle.x -= 5;

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;

	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_FIREBALLFIRE];

	// player "shoot" animation
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );
	Vector vecSrc = m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * 8 + gpGlobals->v_up * -8;
		
#ifndef CLIENT_DLL
	Create("proj_fireball",vecSrc,UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usFireballSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}
