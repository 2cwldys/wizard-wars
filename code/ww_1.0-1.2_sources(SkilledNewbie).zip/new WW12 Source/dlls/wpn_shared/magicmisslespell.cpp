/*
	MagicMissleSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define MAGICMISSLESPELL_DELAY			.1
#define MAGICMISSLESPELL_COST			1

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_magicmisslespell, CMagicMissleSpell );

void CMagicMissleSpell::Precache( void ){
	PRECACHE_SOUND("spells/magicmissile.wav");
	m_usMagicMissleSpellFire=PRECACHE_EVENT(1,"events/spells/magicmisslespellfire.sc");

	m_iIdleAnim=FPANIMS_MMIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CMagicMissleSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = MAGICMISSLESPELL_SLOT;
	p->iPosition = MAGICMISSLESPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_MAGICMISSLESPELL;
	p->iWeight = MAGICMISSLESPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CMagicMissleSpell::PrimaryAttack( void ){
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=MAGICMISSLESPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + MAGICMISSLESPELL_DELAY;
	m_flTimeWeaponIdle=UTIL_WeaponTimeBase()+FirstPersonAnimTimes[FPANIMS_MMFIRE];

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;

	// player "shoot" animation
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

#ifndef CLIENT_DLL
	UTIL_MakeVectors( m_pPlayer->pev->v_angle );
	Vector vecSrc = m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * -8 + gpGlobals->v_up * -8;
		
	Create("proj_magicmissle",vecSrc,UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usMagicMissleSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}
