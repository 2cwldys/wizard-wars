/*
	LightningboltSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define LIGHTNINGBOLTSPELL_DELAY			.25
#define LIGHTNINGBOLTSPELL_COST				2

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_lightningboltspell, CLightningboltSpell);

void CLightningboltSpell::Precache( void ){
	PRECACHE_SOUND("spells/lightningzap.wav");
	m_usLightningboltSpellFire=PRECACHE_EVENT(1,"events/spells/lightningboltspellfire.sc");

	m_iIdleAnim=FPANIMS_LITBOLTIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CLightningboltSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = LIGHTNINGBOLTSPELL_SLOT;
	p->iPosition = LIGHTNINGBOLTSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_LIGHTNINGBOLTSPELL;
	p->iWeight = LIGHTNINGBOLTSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CLightningboltSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=LIGHTNINGBOLTSPELL_COST;

	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_LITBOLTFIRE];;
	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + LIGHTNINGBOLTSPELL_DELAY; 

	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle );
	Vector AimingDir = gpGlobals->v_forward;
	Vector GunPosition = m_pPlayer->GetGunPosition( ); 
	Vector EndPoint = GunPosition + AimingDir * 8192;

	TraceResult TResult; 
	edict_t* EntityToIgnore; 
	EntityToIgnore = ENT( m_pPlayer->pev );

	UTIL_TraceLine( GunPosition, EndPoint, dont_ignore_monsters, EntityToIgnore, &TResult ); 
	if( TResult.fAllSolid ) return;

#ifndef CLIENT_DLL
	CBaseEntity* Victim = CBaseEntity :: Instance( TResult.pHit ); 

	if(Victim){
		ClearMultiDamage();
		Victim->TraceAttack(m_pPlayer->pev,20,AimingDir,&TResult,DMG_SHOCK);
		ApplyMultiDamage(pev,m_pPlayer->pev);
	}
#endif

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usLightningboltSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}