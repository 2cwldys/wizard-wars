// I have burned my bridges behind me, and their crimson flames ignite the night sky with the blood of my enemies...

/*
	UpdraftSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define UPDRAFTSPELL_SOUND_SHOOT	"weapons/electro5.wav" 
#define UPDRAFTSPELL_SOUND_VOLUME	0.25 
#define UPDRAFTSPELL_DELAY		.4
#define UPDRAFTSPELL_DAMAGE		5
#define UPDRAFTSPELL_COST			2
#define UPDRAFTSPELL_STRENGTH	600

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_updraftspell, CUpdraftSpell);

void CUpdraftSpell::Precache( void ){
	PRECACHE_SOUND (UPDRAFTSPELL_SOUND_SHOOT);
	MushroomSprite = PRECACHE_MODEL ("sprites/updraft.spr");
	m_usUpdraftSpellFire=PRECACHE_EVENT(1,"events/spells/updraftspellfire.sc");

	m_iIdleAnim=FPANIMS_FLAMELICKIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CUpdraftSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = UPDRAFTSPELL_SLOT;
	p->iPosition = UPDRAFTSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_UPDRAFTSPELL;
	p->iWeight = UPDRAFTSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CUpdraftSpell::PrimaryAttack( void ){
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=UPDRAFTSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + UPDRAFTSPELL_DELAY; 
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_FLAMELICKFIRE];

	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle );
	Vector AimingDir = gpGlobals->v_forward;
	Vector GunPosition = m_pPlayer->GetGunPosition( ); 
	Vector EndPoint = GunPosition + AimingDir * 8192;

	TraceResult TResult; 
	edict_t* EntityToIgnore; 
	EntityToIgnore = ENT( m_pPlayer->pev );

	UTIL_TraceLine( GunPosition, EndPoint, dont_ignore_monsters, EntityToIgnore, &TResult ); 

	ClearMultiDamage( ); 

#ifndef CLIENT_DLL
	::RadiusDamage( TResult.vecEndPos, pev, m_pPlayer->pev, UPDRAFTSPELL_DAMAGE, 128, CLASS_NONE, DMG_GENERIC);

	CBaseEntity *pEnt=NULL;
	
	while((pEnt=UTIL_FindEntityInSphere(pEnt,TResult.vecEndPos,50))!=NULL){
		if(pEnt->IsAlive() && pEnt->IsPlayer() && m_pPlayer->IRelationship(pEnt)>=0){
			pEnt->pev->velocity=pEnt->pev->velocity+(pEnt->pev->origin-TResult.vecEndPos).Normalize()*UPDRAFTSPELL_STRENGTH;
			pEnt->pev->velocity.z+=UPDRAFTSPELL_STRENGTH/10;
			pEnt->pev->flags&=~FL_ONGROUND;
		}
	}
#endif

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usUpdraftSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}