/*
	skullspell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define SKULLSPELL_DELAY		.8
#define SKULLSPELL_MAX_CARRY	100
#define SKULLSPELL_MAX_COUNT	3
#define SKULLSPELL_COST			5

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_skullspell, CSkullSpell );

void CSkullSpell::Precache( void ){
	m_usSkullSpellFire=PRECACHE_EVENT(1,"events/spells/skullspellfire.sc");

	m_iIdleAnim=FPANIMS_SKULLIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CSkullSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = SKULLSPELL_SLOT;
	p->iPosition = SKULLSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_SKULLSPELL;
	p->iWeight = SKULLSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CSkullSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<SKULLSPELL_COST) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=SKULLSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + SKULLSPELL_DELAY;
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_SKULLFIRE];

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );

#ifndef CLIENT_DLL
	CBaseEntity *pSkull = CBaseEntity::Create( "proj_flyingskull", m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * 8 + gpGlobals->v_up * -12, m_pPlayer->pev->v_angle, m_pPlayer->edict() );
	pSkull->pev->team=m_pPlayer->pev->team;
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usSkullSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);
}