/*
	shieldspell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define SHIELDSPELL_SOUND_CAST			"houndeye/he_blast2.wav"
#define SHIELDSPELL_SPRITE			"sprites/armorspell.spr"
#define SHIELDSPELL_DELAY			1.5
#define SHIELDSPELL_COST			10
#define SHIELDSPELL_SHIELD			30

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_shieldspell, CShieldSpell);

void CShieldSpell::Precache( void ){
	PRECACHE_MODEL(SHIELDSPELL_SPRITE);
	PRECACHE_SOUND(SHIELDSPELL_SOUND_CAST);
	m_usShieldSpellFire=PRECACHE_EVENT(1,"events/spells/shieldspellfire.sc");

	m_iIdleAnim=FPANIMS_SHIELDIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CShieldSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = SHIELDSPELL_SLOT;
	p->iPosition = SHIELDSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_SHIELDSPELL;
	p->iWeight = SHIELDSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CShieldSpell::PrimaryAttack( void ){
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=SHIELDSPELL_COST;

	m_flNextPrimaryAttack = gpGlobals->time + SHIELDSPELL_DELAY; 
	m_flTimeWeaponIdle = gpGlobals->time + FirstPersonAnimTimes[FPANIMS_SHIELDFIRE];
	
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 

	EMIT_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,SHIELDSPELL_SOUND_CAST,1,ATTN_NORM);

	m_pPlayer->pev->armorvalue+=SHIELDSPELL_SHIELD;
	if(m_pPlayer->pev->armorvalue>m_pPlayer->pev->armortype)
		m_pPlayer->pev->armorvalue=m_pPlayer->pev->armortype;

	PLAYBACK_EVENT(0,m_pPlayer->edict(),m_usShieldSpellFire);
}