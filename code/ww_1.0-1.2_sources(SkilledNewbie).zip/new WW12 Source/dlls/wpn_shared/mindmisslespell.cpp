/*
	MindMissleSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define MINDMISSLESPELL_SOUND_VOLUME	0.4
#define MINDMISSLESPELL_DELAY			.2
#define MINDMISSLESPELL_COST			2

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_mindmisslespell, CMindMissleSpell );

void CMindMissleSpell::Precache( void ){
	PRECACHE_SOUND("spells/mindmissile.wav");
	m_usMindMissleSpellFire=PRECACHE_EVENT(1,"events/spells/mindmisslespellfire.sc");

	m_iIdleAnim=FPANIMS_MMIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CMindMissleSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = MINDMISSLESPELL_SLOT;
	p->iPosition = MINDMISSLESPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_MINDMISSLESPELL;
	p->iWeight = MINDMISSLESPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CMindMissleSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] < MINDMISSLESPELL_COST ) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=MINDMISSLESPELL_COST;

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + MINDMISSLESPELL_DELAY;
	m_flTimeWeaponIdle=UTIL_WeaponTimeBase()+FirstPersonAnimTimes[FPANIMS_MMFIRE];

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );
	Vector vecSrc = m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 - gpGlobals->v_right * 8 + gpGlobals->v_up * -8;
		
	CBaseEntity *pMindMissle1 = Create("proj_mindmissle",vecSrc,vecSrc,m_pPlayer->edict());

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usMindMissleSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}
