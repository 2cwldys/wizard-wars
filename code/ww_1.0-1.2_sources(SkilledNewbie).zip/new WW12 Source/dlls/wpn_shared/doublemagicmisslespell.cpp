/*
	DoubleMagicMissleSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define DOUBLEMAGICMISSLESPELL_SOUND_VOLUME	0.4
#define DOUBLEMAGICMISSLESPELL_DELAY		.1
#define DOUBLEMAGICMISSLESPELL_COST			1

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_doublemagicmisslespell, CDoubleMagicMissleSpell );

void CDoubleMagicMissleSpell::Precache( void ){
	PRECACHE_SOUND("spells/magicmissile.wav");

	m_usDoubleMagicMissleSpellFire=PRECACHE_EVENT(1,"events/spells/doublemagicmisslespellfire.sc");

	m_iIdleAnim=FPANIMS_MMIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CDoubleMagicMissleSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = DOUBLEMAGICMISSLESPELL_SLOT;
	p->iPosition = DOUBLEMAGICMISSLESPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_DOUBLEMAGICMISSLESPELL;
	p->iWeight = DOUBLEMAGICMISSLESPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CDoubleMagicMissleSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] < DOUBLEMAGICMISSLESPELL_COST ) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=DOUBLEMAGICMISSLESPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + DOUBLEMAGICMISSLESPELL_DELAY;
	m_flTimeWeaponIdle=UTIL_WeaponTimeBase()+30/14;

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;

	// player "shoot" animation
	m_pPlayer->SetAnimation(PLAYER_ATTACK1);

	Vector offset=Vector(0,0,0);

	if(!iAlternate){
		iAlternate=TRUE;
		offset=gpGlobals->v_right*8;
	}
	else{
		iAlternate=FALSE;
		offset=gpGlobals->v_right*-8;
	}

#ifndef CLIENT_DLL
	UTIL_MakeVectors( m_pPlayer->pev->v_angle );
	Vector vecSrc = m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_up * -8 + offset;
    Create("proj_doublemagicmissle",vecSrc,UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usDoubleMagicMissleSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,iAlternate,0);
}

void CDoubleMagicMissleSpell::WeaponIdle( void ){
	iAlternate=FALSE;

	CBaseSpell::WeaponIdle();
}