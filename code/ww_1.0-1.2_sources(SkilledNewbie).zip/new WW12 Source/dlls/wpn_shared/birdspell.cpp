/*
	BirdSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define BIRDSPELL_DELAY		.8
#define BIRDSPELL_MAX_CARRY	200
#define BIRDSPELL_COST		4

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_birdspell, CBirdSpell );

void CBirdSpell::Precache(){
	m_usBirdSpellFire=PRECACHE_EVENT(1,"events/spells/birdspellfire.sc");

	m_iIdleAnim=FPANIMS_BIRDIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CBirdSpell::GetItemInfo(ItemInfo *p){
	p->iMaxClip = WEAPON_NOCLIP;
	p->iSlot = BIRDSPELL_SLOT;
	p->iPosition = BIRDSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_BIRDSPELL;
	p->iWeight = BIRDSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CBirdSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<BIRDSPELL_COST) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=BIRDSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + BIRDSPELL_DELAY;
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_BIRDFIRE];

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );

#ifndef CLIENT_DLL
	CBaseEntity *pBird = CBaseEntity::Create( "proj_bird", m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * 8 + gpGlobals->v_up * -12, m_pPlayer->pev->v_angle, m_pPlayer->edict() );
	pBird->pev->team=m_pPlayer->pev->team;
	pBird->pev->velocity=gpGlobals->v_forward*300;		
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usBirdSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);
	
#ifdef OLD_WEAPONS
	SendWeaponAnim(BIRDSPELL_SHOOT);

	m_pPlayer->pev->punchangle.x -= 5;
#endif
}