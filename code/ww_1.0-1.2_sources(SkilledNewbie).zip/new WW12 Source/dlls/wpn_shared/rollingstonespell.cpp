/*
	RollingStoneSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define ROLLINGSTONESPELL_SOUND_VOLUME	0.25 
#define ROLLINGSTONESPELL_DELAY			.5
#define ROLLINGSTONESPELL_MAX_COUNT		4
#define ROLLINGSTONESPELL_COST			2

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_rollingstonespell, CRollingStoneSpell );

void CRollingStoneSpell::Precache( void ){
	m_usRollingStoneSpellFire=PRECACHE_EVENT(1,"events/spells/rollingstonespellfire.sc");

	m_iIdleAnim=FPANIMS_ROLLINGSTONEIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CRollingStoneSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = ROLLINGSTONESPELL_SLOT;
	p->iPosition = ROLLINGSTONESPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_ROLLINGSTONESPELL;
	p->iWeight = ROLLINGSTONESPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CRollingStoneSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] <ROLLINGSTONESPELL_COST ) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=ROLLINGSTONESPELL_COST;

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + ROLLINGSTONESPELL_DELAY;
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_ROLLINGSTONEFIRE];

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );

	Vector vecSrc = m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * 8 + gpGlobals->v_up * -8;

#ifndef CLIENT_DLL
	CBaseEntity *pStone = CBaseEntity::Create( "proj_rollingstone", vecSrc, m_pPlayer->pev->v_angle, m_pPlayer->edict() );
	pStone->pev->team=m_pPlayer->pev->team;
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usRollingStoneSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);
}