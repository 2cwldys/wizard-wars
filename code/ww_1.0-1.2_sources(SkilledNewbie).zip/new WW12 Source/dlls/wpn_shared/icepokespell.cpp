/*
	IcepokeSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

#define ICEPOKESPELL_SOUND_SHOOT	"spells/icepoke.wav"
#define ICEPOKESPELL_SOUND_VOLUME	0.25 
#define ICEPOKESPELL_DELAY			.3
#define ICEPOKESPELL_COST			1

LINK_ENTITY_TO_CLASS( weapon_icepokespell, CIcepokeSpell );

void CIcepokeSpell::Precache( void ){
	PRECACHE_SOUND (ICEPOKESPELL_SOUND_SHOOT);
	m_usIcepokeSpellFire=PRECACHE_EVENT(1,"events/spells/icepokespellfire.sc");

	m_iIdleAnim=FPANIMS_ICEPOKEIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CIcepokeSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = ICEPOKESPELL_SLOT;
	p->iPosition = ICEPOKESPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_ICEPOKESPELL;
	p->iFlags = 0;
	p->iWeight = ICEPOKESPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CIcepokeSpell::PrimaryAttack( void ){
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=ICEPOKESPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + ICEPOKESPELL_DELAY;
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_ICEPOKEFIRE];

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;

	// player "shoot" animation
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );
	Vector vecSrc = m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * 8 + gpGlobals->v_up * -8;
		
#ifndef CLIENT_DLL
	Create("proj_icepoke",vecSrc+Vector(RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40)),UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
	Create("proj_icepoke",vecSrc+Vector(RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40)),UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
	Create("proj_icepoke",vecSrc+Vector(RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40)),UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
	Create("proj_icepoke",vecSrc+Vector(RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40)),UTIL_VecToAngles(vecSrc),m_pPlayer->edict());
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usIcepokeSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);
}
