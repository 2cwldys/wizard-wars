/*
	BeanstalkSpell.cpp
	By: Alan Fischer
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "beanstalk.h"

#define BEANSTALKSPELL_DELAY			.5
#define BEANSTALKSPELL_COST				5
#define BEANSTALKSPELL_SEARCHDIST		30

//=========================================================
//=========================================================

class CBeanstalkSpell:public CBaseSpell{
public:
	void Spawn();
	int iItemSlot() { return BEANSTALKSPELL_SLOT+1;}
	int GetItemInfo(ItemInfo *p);
	void WeaponIdle();
	BOOL UseDecrement(){return FALSE;}
	void Precache();

	void CBeanstalkSpell::Drop();
	void CBeanstalkSpell::Holster(int skiplocal);
	void PrimaryAttack();
	int StalkRoom(Vector stalkPos);

	Vector m_stalkPos;
	int m_iIsStalking;
	CBeanstalk *pLastStalk;
};

LINK_ENTITY_TO_CLASS( weapon_beanstalkspell, CBeanstalkSpell );

void CBeanstalkSpell::Spawn(){
	pLastStalk=NULL;
	m_iId=WEAPON_BEANSTALKSPELL;
	m_iIsStalking=0;

	CBaseSpell::Spawn();
}

void CBeanstalkSpell::Precache(){
	m_iIdleAnim=FPANIMS_BEANSTALKIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;
}

int CBeanstalkSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = BEANSTALKSPELL_SLOT;
	p->iPosition = BEANSTALKSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_BEANSTALKSPELL;
	p->iWeight = BEANSTALKSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CBeanstalkSpell::PrimaryAttack(){
	Vector temp;
	TraceResult TResult; 

	//Stop the Player from moving while he is making a beanstalk
	g_engfuncs.pfnSetClientMaxspeed(ENT(m_pPlayer->pev),-1);
	m_pPlayer->pev->velocity.x=0;
	m_pPlayer->pev->velocity.y=0;

	if(m_flNextPrimaryAttack>gpGlobals->time)return;

	m_flNextPrimaryAttack=gpGlobals->time+BEANSTALKSPELL_DELAY;

	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<BEANSTALKSPELL_COST){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
		return;
	}

	if(!(m_pPlayer->pev->flags & FL_ONGROUND)){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#NotOnGround");
		return;
	}

	if(m_iIsStalking==0&&
	  ((CNatureWizard*)m_pPlayer->m_pClass)->m_pStalk==NULL){

		UTIL_MakeVectors( m_pPlayer->pev->v_angle );
		
		Vector v_for=Vector(gpGlobals->v_forward);
		v_for.z=0;v_for.Normalize();
		m_stalkPos=Vector(m_pPlayer->GetGunPosition()+v_for*80);
		m_stalkPos.z=m_stalkPos.z-64;

		//Find the ground beneath the Stalk
		temp.x=m_stalkPos.x;
		temp.y=m_stalkPos.y;
		temp.z=m_stalkPos.z;
		temp.z=temp.z-64;

		UTIL_TraceLine( m_stalkPos, temp, dont_ignore_monsters, ENT(pev), &TResult );

		m_stalkPos=TResult.vecEndPos;

		StalkRoom(m_stalkPos);

		if(StalkRoom(m_stalkPos)==2 || TResult.vecEndPos.z==temp.z){
			ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#OutOfRoom");
			return;
		}

		m_iIsStalking=1;

		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=BEANSTALKSPELL_COST;
		pLastStalk=(CBeanstalk*)CBaseEntity::Create( "beanstalk", m_stalkPos, Vector(0,RANDOM_FLOAT(-255,255),0), m_pPlayer->edict() );
		((CNatureWizard*)m_pPlayer->m_pClass)->AddStalk(pLastStalk);

		m_stalkPos.z=m_stalkPos.z+180/4;
		return;
	}

	if(m_iIsStalking==1 && ((CNatureWizard*)m_pPlayer->m_pClass)->m_pStalk!=NULL){
		//Make sure there is room
		m_iIsStalking=StalkRoom(m_stalkPos);
		if(m_iIsStalking==2){
			ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#OutOfRoom");
			m_iIsStalking=0;
			return;
		}
		
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=BEANSTALKSPELL_COST;
		CBeanstalk *pEnt=(CBeanstalk*)CBaseEntity::Create( "beanstalk", m_stalkPos, Vector(0,RANDOM_FLOAT(-255,255),0), m_pPlayer->edict() );
		pLastStalk->m_hNextStalk=pEnt;//Linked list-o-stalks
		pLastStalk=pEnt;

		m_stalkPos.z=m_stalkPos.z+180/4;
	}

	else{
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#BeanstalkSpell_AlreadyHaveOne");
		return;
	}
}

int CBeanstalkSpell::StalkRoom(Vector stalkPos){
	Vector mins=stalkPos;
	Vector maxs=stalkPos;
	mins.x=mins.x-BEANSTALKSPELL_SEARCHDIST;
	mins.y=mins.y-BEANSTALKSPELL_SEARCHDIST;
	maxs.x=maxs.x+BEANSTALKSPELL_SEARCHDIST;
	maxs.y=maxs.y+BEANSTALKSPELL_SEARCHDIST;
	maxs.z=maxs.z+40;

	if(!UTIL_SearchArea(mins,maxs,15))
		return 2;

	return 1;
}

void CBeanstalkSpell::Drop(){
	if(m_iIsStalking==1)
		m_iIsStalking=0;

	g_engfuncs.pfnSetClientMaxspeed( ENT( m_pPlayer->pev ), m_pPlayer->m_pClass->PlayerSpeed() );

	CBaseSpell::Drop();
}

void CBeanstalkSpell::Holster(int skiplocal){
	if(m_iIsStalking==1)
		m_iIsStalking=0;

	g_engfuncs.pfnSetClientMaxspeed( ENT( m_pPlayer->pev ), m_pPlayer->m_pClass->PlayerSpeed() );

	CBaseSpell::Holster();
}

void CBeanstalkSpell::WeaponIdle(){
	if(m_iIsStalking==1)
		m_iIsStalking=0;

	g_engfuncs.pfnSetClientMaxspeed( ENT( m_pPlayer->pev ), m_pPlayer->m_pClass->PlayerSpeed() );

	CBaseSpell::WeaponIdle();
}