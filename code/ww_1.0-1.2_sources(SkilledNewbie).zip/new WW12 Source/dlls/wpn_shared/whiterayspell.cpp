/*
	WhiteraySpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "effects.h"
#include "customentity.h"
#include "gamerules.h"

// Define all constants here
#define WHITERAYSPELL_SOUND_SHOOT	"spells/rayspell_life.wav" 
#define WHITERAYSPELL_SOUND_VOLUME	0.75
#define WHITERAYSPELL_DAMAGE		9
#define WHITERAYSPELL_COST			2
#define WHITERAYSPELL_BEAM			"sprites/xbeam3.spr"
#define WHITERAYSPELL_ENDSPRITE		"sprites/glow04.spr"
#define WHITERAYSPELL_LENGTH		500

class CWhiteraySpell:public CBaseSpell{
public:
	void Spawn();
	void Precache();
	int iItemSlot(){return WHITERAYSPELL_SLOT+1;}
	int GetItemInfo(ItemInfo *p);
	BOOL UseDecrement(){return FALSE;}

	void PrimaryAttack();
	BOOL Deploy();
	void WeaponIdle();
	void Drop();
	void Holster(int skiplocal=0);

	void CreateEffect( void );
	void UpdateEffect( const Vector &startPoint, const Vector &endPoint, float timeBlend );
	void DestroyEffect( void );

	CBeam* m_pBeam;
//	CSprite* m_pSprite;
	float m_flNextAmmoUseTime;
	float m_flAmmoUseTime;// since we use < 1 point of ammo per update, we subtract ammo on a timer.
	int m_iAnimation;
};

LINK_ENTITY_TO_CLASS( weapon_whiterayspell, CWhiteraySpell );

void CWhiteraySpell::Spawn(){
	m_iId = WEAPON_WHITERAYSPELL;

	CBaseSpell::Spawn();
}

void CWhiteraySpell::Precache(){
	PRECACHE_MODEL(WHITERAYSPELL_BEAM);
	PRECACHE_MODEL(WHITERAYSPELL_ENDSPRITE);

	PRECACHE_SOUND(WHITERAYSPELL_SOUND_SHOOT);

	m_iIdleAnim=FPANIMS_RAYIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CWhiteraySpell::GetItemInfo(ItemInfo *p){
	p->iSlot = WHITERAYSPELL_SLOT;
	p->iPosition = WHITERAYSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_WHITERAYSPELL;
	p->iWeight = WHITERAYSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

BOOL CWhiteraySpell::Deploy(){
	m_iAnimation=0;

	return CBaseSpell::Deploy();
}

void CWhiteraySpell::PrimaryAttack(){
	TraceResult tr;
	float timedist;
	
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<WHITERAYSPELL_COST){
		DestroyEffect();
		return;
	}
	if(m_flNextAmmoUseTime<=gpGlobals->time){
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=WHITERAYSPELL_COST;
		m_flNextAmmoUseTime=gpGlobals->time+.3;
	}
	
	if(m_iAnimation==0){
		m_iAnimation=1;
		SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYFIRE]);
	}

	m_flTimeWeaponIdle = gpGlobals->time + 30/14;
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle );
	Vector vecAiming = gpGlobals->v_forward;
	Vector vecSrc	 = m_pPlayer->GetGunPosition( );

	Vector vecDest = vecSrc + vecAiming * WHITERAYSPELL_LENGTH;

	Vector tmpSrc = vecSrc + gpGlobals->v_up * -8 + gpGlobals->v_right * 3;

	UTIL_TraceLine( vecSrc, vecDest, dont_ignore_monsters, m_pPlayer->edict(), &tr );

	if (tr.fAllSolid)
			return;
		
	if((tr.vecEndPos-m_pPlayer->pev->origin).Length()>=WHITERAYSPELL_LENGTH-5){
//		if(m_pSprite){
//			m_pSprite->pev->effects |= EF_NODRAW;
//		}
	}
	else{
		CBaseEntity *pEntity = CBaseEntity::Instance(tr.pHit);

//		if(m_pSprite)
//			m_pSprite->pev->effects &= ~EF_NODRAW;
		
		if (pEntity == NULL){
			return;
		}

		if(pev->dmgtime<gpGlobals->time){
			if (m_pPlayer->IRelationship(pEntity)==R_AL){
				pEntity->TakeHealth(WHITERAYSPELL_DAMAGE/2,DMG_GENERIC);
			}
			else{
				ClearMultiDamage();
				if (pEntity->pev->takedamage)
				{
					pEntity->TraceAttack( m_pPlayer->pev, WHITERAYSPELL_DAMAGE, vecAiming, &tr, DMG_ENERGYBEAM );
				}
				ApplyMultiDamage(m_pPlayer->pev, m_pPlayer->pev);
			}
			pev->dmgtime = gpGlobals->time + .1;
		}
	}

	timedist = ( pev->dmgtime - gpGlobals->time ) / .025;

	if ( timedist < 0 )
		timedist = 0;
	else if ( timedist > 1 )
		timedist = 1;
	timedist = 1-timedist;

	UpdateEffect( tr.vecEndPos, tr.vecEndPos, timedist );
}

void CWhiteraySpell::WeaponIdle(){
	DestroyEffect();

	if(m_iAnimation==1){
		m_iAnimation=0;
		SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYEND]);
		m_flTimeWeaponIdle=gpGlobals->time+30/14;
	}

	if (m_flTimeWeaponIdle > gpGlobals->time)
		return;

	m_iAnimation=0;
	SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYIDLE]);
}

void CWhiteraySpell::Drop(){
	DestroyEffect();

	CBaseSpell::Drop();
}

void CWhiteraySpell::Holster( int skiplocal ){
	DestroyEffect();

	CBaseSpell::Holster();
}

void CWhiteraySpell::UpdateEffect( const Vector &startPoint, const Vector &endPoint, float timeBlend ){
	if ( !m_pBeam ){
		CreateEffect();
	}

	m_pBeam->PointEntInit( pev->origin, m_pPlayer->entindex() );
	m_pBeam->SetEndAttachment( 1 );

	m_pBeam->SetStartPos( endPoint );
	m_pBeam->SetBrightness( 255 - (timeBlend*64) );
	m_pBeam->SetColor( 60 + (25*timeBlend), 120 + (30*timeBlend), 64 + 80*fabs(sin(gpGlobals->time*10)) );

//	UTIL_SetOrigin( m_pSprite->pev, endPoint );
//	m_pSprite->pev->frame += 8 * gpGlobals->frametime;
//	if ( m_pSprite->pev->frame > m_pSprite->Frames() )
//		m_pSprite->pev->frame = 0;
}

void CWhiteraySpell::CreateEffect(){
//	DestroyEffect();
	if ( m_pBeam ){
		UTIL_Remove( m_pBeam );
		m_pBeam = NULL;
	}

	m_pBeam = CBeam::BeamCreate(WHITERAYSPELL_BEAM, 55 );
	m_pBeam->PointEntInit( pev->origin, m_pPlayer->entindex() );
	m_pBeam->SetEndAttachment( 1 );
	m_pBeam->pev->spawnflags |= SF_BEAM_TEMPORARY;	// Flag these to be destroyed on save/restore or level transition

	m_pBeam->SetScrollRate( 25 );
	m_pBeam->SetWidth(64);
	m_pBeam->SetNoise( 2 );

//	m_pSprite=CSprite::SpriteCreate(DEATHRAYSPELL_ENDSPRITE,pev->origin,TRUE);
//	m_pSprite->pev->scale = 1.5;
//	m_pSprite->SetTransparency( kRenderGlow, 255, 255, 255, 255, kRenderFxNoDissipation );
//	m_pSprite->pev->spawnflags |= SF_SPRITE_TEMPORARY;

	EMIT_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,WHITERAYSPELL_SOUND_SHOOT,WHITERAYSPELL_SOUND_VOLUME,ATTN_NORM);
}

void CWhiteraySpell::DestroyEffect(){
	if ( m_pBeam ){
		UTIL_Remove( m_pBeam );
		m_pBeam = NULL;
	}
//	if ( m_pSprite ){
//		UTIL_Remove( m_pSprite );
//		m_pSprite = NULL;
//	}

	STOP_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,WHITERAYSPELL_SOUND_SHOOT);
}