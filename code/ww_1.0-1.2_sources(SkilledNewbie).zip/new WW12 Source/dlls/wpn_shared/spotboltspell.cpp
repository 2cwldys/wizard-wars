/*
	SpotboltSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define SPOTBOLTSPELL_DELAY				2.0
#define SPOTBOLTSPELL_DAMAGE			600
#define SPOTBOLTSPELL_MAXCHARGE			11
#define SPOTBOLTSPELL_OVERCHARGE		20
#define SPOTBOLTSPELL_SLOWDOWN			.5 //neo

#ifndef CLIENT_DLL
extern unsigned short g_usSpark;
#endif

LINK_ENTITY_TO_CLASS( weapon_spotboltspell, CSpotboltSpell);

void CSpotboltSpell::Precache( void ){
	PRECACHE_SOUND("spells/spotbolt.wav");
	m_usSpotboltSpellFire=PRECACHE_EVENT(1,"events/spells/spotboltspellfire.sc");
	m_usSpotboltSpellCharge=PRECACHE_EVENT(1,"events/spells/spotboltspellcharge.sc");

	m_iIdleAnim=FPANIMS_SPOTBOLTIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CSpotboltSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = SPOTBOLTSPELL_SLOT;
	p->iPosition = SPOTBOLTSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_SPOTBOLTSPELL;
	p->iWeight = SPOTBOLTSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CSpotboltSpell::PrimaryAttack( void ){
	//float t = pPlayer->m_pClass->PlayerSpeed();//neo
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<5) return;


	
	if(m_iState==0){
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] -= 5;
		m_flChargeStart=SpotboltTimebase();
		m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 
		SendWeaponAnim(FirstPersonAnims[FPANIMS_SPOTBOLTSTART],1);
		m_iState=1;
		g_engfuncs.pfnSetClientMaxspeed(ENT( m_pPlayer->pev ),150);//neo
	}

	if(m_iState==1 && (SpotboltTimebase()-m_flChargeStart)>FirstPersonAnimTimes[FPANIMS_SPOTBOLTSTART]){
		SendWeaponAnim(FirstPersonAnims[FPANIMS_SPOTBOLTCHARGE],0);
		m_iState=2;

	}

	if((m_iState==2 && (SpotboltTimebase()-m_flChargeStart)>SPOTBOLTSPELL_MAXCHARGE))
	{
		SendWeaponAnim(FirstPersonAnims[FPANIMS_SPOTBOLTFULL],0);
		m_iState=3;
	}
		

	if((SpotboltTimebase()-m_flChargeStart)>SPOTBOLTSPELL_OVERCHARGE){
		Fire();

#ifndef CLIENT_DLL
		PLAYBACK_EVENT(0,m_pPlayer->edict(),g_usSpark);
#endif
	}
}

void CSpotboltSpell::WeaponIdle(){
	if(m_iState>0){
		Fire();
	}

	m_iState=0;

	CBaseSpell::WeaponIdle();
}

void CSpotboltSpell::Fire(){
	int flags=0;
	float flCharge;

	flCharge=SpotboltTimebase()-m_flChargeStart;

	flCharge=flCharge/SPOTBOLTSPELL_MAXCHARGE;

	if(flCharge>1)
		flCharge=1;

#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usSpotboltSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	SendWeaponAnim(FirstPersonAnims[FPANIMS_SPOTBOLTFIRE],1);

	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle);
	
	Vector AimingDir = gpGlobals->v_forward;
	Vector GunPosition = m_pPlayer->GetGunPosition();
	Vector EndPoint = GunPosition + AimingDir * 8192;

	TraceResult TResult;

	UTIL_TraceLine( GunPosition, EndPoint, dont_ignore_monsters, m_pPlayer->edict(), &TResult ); 

#ifndef CLIENT_DLL
	CBaseEntity* Victim = CBaseEntity :: Instance( TResult.pHit );
	if(Victim){
		ClearMultiDamage();
		Victim->TraceAttack(m_pPlayer->pev,SPOTBOLTSPELL_DAMAGE*flCharge,AimingDir,&TResult,DMG_SHOCK);
		ApplyMultiDamage(pev,m_pPlayer->pev);
	}
#endif

	m_flNextPrimaryAttack=UTIL_WeaponTimeBase()+SPOTBOLTSPELL_DELAY;
	m_flTimeWeaponIdle=UTIL_WeaponTimeBase()+FirstPersonAnimTimes[FPANIMS_SPOTBOLTFIRE];

	m_iState=0;
	g_engfuncs.pfnSetClientMaxspeed(ENT( m_pPlayer->pev ),300);//neo
}

float CSpotboltSpell::SpotboltTimebase(){
#ifndef CLIENT_DLL
	return gpGlobals->time;
#else
	return UTIL_WeaponTimeBase();
#endif
}
