/*
	ForceSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define FORCESPELL_SOUND_SHOOT		"spells/forceblast.wav" 
#define FORCESPELL_DELAY			1.5
#define FORCESPELL_COST				5
#define FORCESPELL_RADIUS			500
#define FORCESPELL_FORCE			1200
#define FORCESPELL_SPRITE			"sprites/muz7.spr"
#define FORCESPELL_BLAST			"sprites/shockwave.spr"
#define FORCESPELL_UP				30
#define FORCESPELL_DAMAGE			5

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_forcespell, CForceSpell);

void CForceSpell::Precache( void ){
	m_iForceSprite=PRECACHE_MODEL(FORCESPELL_SPRITE);
	m_iForceBlast=PRECACHE_MODEL(FORCESPELL_BLAST);
	PRECACHE_SOUND (FORCESPELL_SOUND_SHOOT);
	m_usForceSpellFire=PRECACHE_EVENT(1,"events/spells/forcespellfire.sc");

	m_iIdleAnim=FPANIMS_FORCEIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CForceSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = FORCESPELL_SLOT;
	p->iPosition = FORCESPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_FORCESPELL;
	p->iWeight = FORCESPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CForceSpell::PrimaryAttack( void ){
	CBaseEntity* pEntity=NULL;
	Vector tmpVec;
	TraceResult tr;
	
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=FORCESPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + FORCESPELL_DELAY; 
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + 30/14;
	
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 

#ifndef CLIENT_DLL
	// iterate on all entities in the vicinity.
	while ((pEntity = UTIL_FindEntityInSphere( pEntity, m_pPlayer->pev->origin, FORCESPELL_RADIUS )) != NULL){
		//Don't hit yourself, or your teammates
		if(pEntity->IsPlayer() && m_pPlayer->IRelationship(pEntity)>0){
			UTIL_TraceLine(m_pPlayer->pev->origin,pEntity->pev->origin,dont_ignore_monsters,m_pPlayer->edict(),&tr);

			if(tr.flFraction==1.0 || tr.pHit==pEntity->edict()){
				tmpVec=pEntity->pev->origin-m_pPlayer->pev->origin;
				tmpVec.z=tmpVec.z+FORCESPELL_UP;
				tmpVec=tmpVec.Normalize();
				tmpVec=tmpVec*FORCESPELL_FORCE;
				pEntity->pev->velocity=tmpVec;

				pEntity->TakeDamage(pev,m_pPlayer->pev,FORCESPELL_DAMAGE,DMG_GENERIC);
			}
		}
	}
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usForceSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}