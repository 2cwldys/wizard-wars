/*
	ThornblastSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define THORNBLASTSPELL_SOUND_SHOOT		"spells/thornblast.wav"
#define THORNBLASTSPELL_DELAY			.8
#define THORNBLASTSPELL_COST			3
#define THORNBLASTSPELL_SHOTS			5

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_thornblastspell, CThornblastSpell);

void CThornblastSpell::Precache( void ){
	PRECACHE_MODEL("models/thorn.mdl");
	PRECACHE_SOUND (THORNBLASTSPELL_SOUND_SHOOT);
	m_usThornblastSpellFire=PRECACHE_EVENT(1,"events/spells/thornblastspellfire.sc");

	m_iIdleAnim=FPANIMS_THORNBLASTIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CThornblastSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = THORNBLASTSPELL_SLOT;
	p->iPosition = THORNBLASTSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_THORNBLASTSPELL;
	p->iWeight = THORNBLASTSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CThornblastSpell::PrimaryAttack( void ){
	if(m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<=0) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] -= THORNBLASTSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + THORNBLASTSPELL_DELAY; 
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_THORNBLASTFIRE];

	Vector vecSrc	 = m_pPlayer->GetGunPosition( );
	Vector vecAiming = m_pPlayer->GetAutoaimVector( AUTOAIM_5DEGREES );

	m_pPlayer->FireBullets(THORNBLASTSPELL_SHOTS, vecSrc, vecAiming, Vector(0.1,0.1,0.00), 2048, BULLET_PLAYER_BUCKSHOT, 0);
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usThornblastSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,1,0);
}