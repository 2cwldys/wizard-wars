/*
	FreezeraySpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "effects.h"
#include "customentity.h"
#include "gamerules.h"

// Define all constants here
#define FREEZERAYSPELL_SOUND_SHOOT	"spells/rayspell_aqua.wav" 
#define FREEZERAYSPELL_SOUND_VOLUME	0.75
#define FREEZERAYSPELL_DAMAGE		8
#define FREEZERAYSPELL_COST			3
#define FREEZERAYSPELL_BEAM			"sprites/xbeam3.spr"
#define FREEZERAYSPELL_ENDSPRITE		"sprites/glow04.spr"
#define FREEZERAYSPELL_LENGTH		500

class CFreezeraySpell:public CBaseSpell{
public:
	void Spawn();
	void Precache();
	int iItemSlot(){return FREEZERAYSPELL_SLOT+1;}
	int GetItemInfo(ItemInfo *p);
	BOOL UseDecrement(){return FALSE;}

	void PrimaryAttack();
	BOOL Deploy();
	void WeaponIdle();
	void Drop();
	void Holster(int skiplocal=0);

	void CreateEffect( void );
	void UpdateEffect( const Vector &startPoint, const Vector &endPoint, float timeBlend );
	void DestroyEffect( void );

	CBeam* m_pBeam;
//	CSprite* m_pSprite;
	float m_flNextAmmoUseTime;
	float m_flAmmoUseTime;// since we use < 1 point of ammo per update, we subtract ammo on a timer.
	int m_iAnimation;
};

LINK_ENTITY_TO_CLASS( weapon_freezerayspell, CFreezeraySpell );

void CFreezeraySpell::Spawn(){
	m_iId = WEAPON_FREEZERAYSPELL;

	CBaseSpell::Spawn();
}

void CFreezeraySpell::Precache(){
	PRECACHE_MODEL(FREEZERAYSPELL_BEAM);
	PRECACHE_MODEL(FREEZERAYSPELL_ENDSPRITE);

	PRECACHE_SOUND(FREEZERAYSPELL_SOUND_SHOOT);

	m_iIdleAnim=FPANIMS_RAYIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CFreezeraySpell::GetItemInfo(ItemInfo *p){
	p->iSlot = FREEZERAYSPELL_SLOT;
	p->iPosition = FREEZERAYSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_FREEZERAYSPELL;
	p->iWeight = FREEZERAYSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

BOOL CFreezeraySpell::Deploy(){
	m_iAnimation=0;

	return CBaseSpell::Deploy();
}

void CFreezeraySpell::PrimaryAttack(){
	TraceResult tr;
	float timedist;
	
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<FREEZERAYSPELL_COST){
		DestroyEffect();
		return;
	}
	if(m_flNextAmmoUseTime<=gpGlobals->time){
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=FREEZERAYSPELL_COST;
		m_flNextAmmoUseTime=gpGlobals->time+.3;
	}
	
	if(m_iAnimation==0){
		m_iAnimation=1;
		SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYFIRE]);
	}

	m_flTimeWeaponIdle = gpGlobals->time + 30/14;
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle );
	Vector vecAiming = gpGlobals->v_forward;
	Vector vecSrc	 = m_pPlayer->GetGunPosition( );

	Vector vecDest = vecSrc + vecAiming * FREEZERAYSPELL_LENGTH;

	Vector tmpSrc = vecSrc + gpGlobals->v_up * -8 + gpGlobals->v_right * 3;

	UTIL_TraceLine( vecSrc, vecDest, dont_ignore_monsters, m_pPlayer->edict(), &tr );

	if (tr.fAllSolid)
			return;
		
	if((tr.vecEndPos-m_pPlayer->pev->origin).Length()>=FREEZERAYSPELL_LENGTH-5){
//		if(m_pSprite){
//			m_pSprite->pev->effects |= EF_NODRAW;
//		}
	}
	else{
		CBaseEntity *pEntity = CBaseEntity::Instance(tr.pHit);

//		if(m_pSprite)
//			m_pSprite->pev->effects &= ~EF_NODRAW;
		
		if (pEntity == NULL){
			return;
		}

		if(pev->dmgtime<gpGlobals->time){
			ClearMultiDamage();
			if (pEntity->pev->takedamage){
				pEntity->TraceAttack( m_pPlayer->pev, FREEZERAYSPELL_DAMAGE, vecAiming, &tr, DMG_ENERGYBEAM|DMG_FREEZE );
				if(pEntity->IsPlayer())
					pEntity->pev->friction=.1;
			}

			ApplyMultiDamage(m_pPlayer->pev, m_pPlayer->pev);

			pev->dmgtime = gpGlobals->time + .1;
		}
	}

	timedist = ( pev->dmgtime - gpGlobals->time ) / .025;

	if ( timedist < 0 )
		timedist = 0;
	else if ( timedist > 1 )
		timedist = 1;
	timedist = 1-timedist;

	UpdateEffect( tr.vecEndPos, tr.vecEndPos, timedist );
}

void CFreezeraySpell::WeaponIdle(){
	DestroyEffect();

	if(m_iAnimation==1){
		m_iAnimation=0;
		SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYEND]);
		m_flTimeWeaponIdle=gpGlobals->time+30/14;
	}

	if (m_flTimeWeaponIdle > gpGlobals->time)
		return;

	m_iAnimation=0;
	SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYIDLE]);
}

void CFreezeraySpell::Drop(){
	DestroyEffect();

	CBaseSpell::Drop();
}

void CFreezeraySpell::Holster( int skiplocal ){
	DestroyEffect();

	CBaseSpell::Holster();
}

void CFreezeraySpell::UpdateEffect( const Vector &startPoint, const Vector &endPoint, float timeBlend ){
	if ( !m_pBeam ){
		CreateEffect();
	}

	m_pBeam->PointEntInit( pev->origin, m_pPlayer->entindex() );
	m_pBeam->SetEndAttachment( 1 );

	m_pBeam->SetStartPos( endPoint );
	m_pBeam->SetBrightness( 255 - (timeBlend*64) );
	m_pBeam->SetColor( 60 + (25*timeBlend), 60 + (30*timeBlend), 180 + 80*fabs(sin(gpGlobals->time*10)) );

//	UTIL_SetOrigin( m_pSprite->pev, endPoint );
//	m_pSprite->pev->frame += 8 * gpGlobals->frametime;
//	if ( m_pSprite->pev->frame > m_pSprite->Frames() )
//		m_pSprite->pev->frame = 0;
}

void CFreezeraySpell::CreateEffect( void ){
//	DestroyEffect();
	if ( m_pBeam ){
		UTIL_Remove( m_pBeam );
		m_pBeam = NULL;
	}

	m_pBeam = CBeam::BeamCreate(FREEZERAYSPELL_BEAM, 55 );
	m_pBeam->PointEntInit( pev->origin, m_pPlayer->entindex() );
	m_pBeam->SetEndAttachment( 1 );
	m_pBeam->pev->spawnflags |= SF_BEAM_TEMPORARY;	// Flag these to be destroyed on save/restore or level transition

	m_pBeam->SetScrollRate( 25 );
	m_pBeam->SetWidth(64);
	m_pBeam->SetNoise(2);

//	m_pSprite=CSprite::SpriteCreate(FREEZERAYSPELL_ENDSPRITE,pev->origin,TRUE);
//	m_pSprite->pev->scale = .5;
//	m_pSprite->SetTransparency( kRenderGlow, 255, 255, 255, 255, kRenderFxNoDissipation );
//	m_pSprite->pev->spawnflags |= SF_SPRITE_TEMPORARY;

	EMIT_SOUND_DYN(ENT(m_pPlayer->pev),CHAN_WEAPON,FREEZERAYSPELL_SOUND_SHOOT,FREEZERAYSPELL_SOUND_VOLUME,ATTN_NORM,0,150);
}

void CFreezeraySpell::DestroyEffect( void ){
	if ( m_pBeam ){
		UTIL_Remove( m_pBeam );
		m_pBeam = NULL;
	}
//	if ( m_pSprite ){
//		UTIL_Remove( m_pSprite );
//		m_pSprite = NULL;
//	}

	STOP_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,FREEZERAYSPELL_SOUND_SHOOT);
}