/*
	WyvernSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

// Define all constants here
#define WYVERNSPELL_DELAY		.8
#define WYVERNSPELL_MAX_CARRY	200
#define WYVERNSPELL_COST		4

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_wyvernspell, CWyvernSpell );

void CWyvernSpell::Precache(){
	m_usWyvernSpellFire=PRECACHE_EVENT(1,"events/spells/wyvernspellfire.sc");

	m_iIdleAnim=FPANIMS_BIRDIDLE;
	m_iTPAnim=TPANIMS_TWOHANDED;

	CBaseSpell::Precache();
}

int CWyvernSpell::GetItemInfo(ItemInfo *p){
	p->iMaxClip = WEAPON_NOCLIP;
	p->iSlot = WYVERNSPELL_SLOT;
	p->iPosition = WYVERNSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_WYVERNSPELL;
	p->iWeight = WYVERNSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CWyvernSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<WYVERNSPELL_COST) return; 
	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=WYVERNSPELL_COST;

	m_flNextPrimaryAttack = UTIL_WeaponTimeBase() + WYVERNSPELL_DELAY;
	m_flTimeWeaponIdle = UTIL_WeaponTimeBase() + FirstPersonAnimTimes[FPANIMS_BIRDFIRE];

	m_pPlayer->m_iWeaponVolume = LOUD_GUN_VOLUME;
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );

#ifndef CLIENT_DLL
	CBaseEntity *pWyvern = CBaseEntity::Create( "proj_wyvern", m_pPlayer->GetGunPosition( ) + gpGlobals->v_forward * 16 + gpGlobals->v_right * 8 + gpGlobals->v_up * -12, m_pPlayer->pev->v_angle, m_pPlayer->edict() );
	pWyvern->pev->team=m_pPlayer->pev->team;
	pWyvern->pev->velocity=gpGlobals->v_forward*300;		
#endif

	int flags=0;
#if defined( CLIENT_WEAPONS )
	flags = FEV_NOTHOST;
#endif
	PLAYBACK_EVENT_FULL(flags,m_pPlayer->edict(),m_usWyvernSpellFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);
	
#ifdef OLD_WEAPONS
	SendWeaponAnim(WYVERNSPELL_SHOOT);

	m_pPlayer->pev->punchangle.x -= 5;
#endif
}