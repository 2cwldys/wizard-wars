/*
	LevitationSpell.cpp
	By: Alan Fischer
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "beanstalk.h"

#define LEVITATIONSPELL_SOUND_SHOOT		"weapons/rocket1.wav" 
#define LEVITATIONSPELL_SOUND_VOLUME	0.25 
#define LEVITATIONSPELL_DELAY			0
#define LEVITATIONSPELL_COST			3
#define LEVITATIONSPELL_MAXVELOCITY		75

//=========================================================
//=========================================================

class CLevitationSpell : public CBaseSpell{
public:
	void Spawn( void );
	void Precache( void );
	int iItemSlot( void ) { return LEVITATIONSPELL_SLOT+1;}
	int GetItemInfo(ItemInfo *p);

	void PrimaryAttack( void );
	void WeaponIdle( void );
	void Drop();
	void Draw();
	void Holster( int skiplocal = 0 );

	float m_flAmmoUseTime;
};

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_levitationspell, CLevitationSpell );

void CLevitationSpell::Spawn( ){
	CBaseSpell::Spawn();
	
	m_iId = WEAPON_LEVITATIONSPELL;

	m_iDefaultAmmo=0;
	m_flAmmoUseTime=0;
}

void CLevitationSpell::Precache( void ){
	m_iIdleAnim=FPANIMS_LEVITATIONIDLE;
	m_iTPAnim=TPANIMS_ONEHANDED;

	CBaseSpell::Precache();
}

int CLevitationSpell::GetItemInfo(ItemInfo *p){
	p->iSlot = LEVITATIONSPELL_SLOT;
	p->iPosition = LEVITATIONSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_LEVITATIONSPELL;
	p->iWeight = LEVITATIONSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

void CLevitationSpell::PrimaryAttack( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<LEVITATIONSPELL_COST){
		m_pPlayer->pev->gravity=1.0;
		return;
	}
	if(m_flAmmoUseTime<=gpGlobals->time){
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=LEVITATIONSPELL_COST;
		m_flAmmoUseTime=gpGlobals->time+1;
	}

	m_pPlayer->pev->gravity=-.2;
	if(m_pPlayer->pev->velocity.z>LEVITATIONSPELL_MAXVELOCITY){
		m_pPlayer->pev->velocity.z=LEVITATIONSPELL_MAXVELOCITY;
	}

	m_pPlayer->pev->gaitsequence=m_pPlayer->LookupActivity( ACT_CROUCHIDLE );
}

void CLevitationSpell::Drop(){
	m_pPlayer->pev->gravity=1.0;

	CBasePlayerWeapon::Drop();
}

void CLevitationSpell::Draw(){
	SendWeaponAnim(13);
}

void CLevitationSpell::Holster( int skiplocal ){
	m_pPlayer->pev->gravity=1.0;

	CBaseSpell::Holster();
}

void CLevitationSpell::WeaponIdle( void ){
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<LEVITATIONSPELL_COST){
		m_pPlayer->pev->gravity=1.0;
		SendWeaponAnim(0);
		return;
	}
	if(m_flAmmoUseTime<=gpGlobals->time){
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=LEVITATIONSPELL_COST;
		m_flAmmoUseTime=gpGlobals->time+1;
	}

	m_pPlayer->pev->gravity=.2;
	
	ResetEmptySound( );

	m_pPlayer->pev->gaitsequence=m_pPlayer->LookupActivity( ACT_CROUCHIDLE );

	CBaseSpell::WeaponIdle();
}