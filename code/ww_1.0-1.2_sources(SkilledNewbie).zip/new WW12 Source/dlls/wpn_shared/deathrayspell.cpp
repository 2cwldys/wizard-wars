/*
	DeathraySpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "effects.h"
#include "customentity.h"
#include "gamerules.h"

// Define all constants here
#define DEATHRAYSPELL_SOUND_SHOOT	"spells/rayspell_death.wav"
#define DEATHRAYSPELL_SOUND_VOLUME	0.75
#define DEATHRAYSPELL_DAMAGE		9
#define DEATHRAYSPELL_COST			2
#define DEATHRAYSPELL_BEAM			"sprites/xbeam2.spr"
#define DEATHRAYSPELL_ENDSPRITE		"sprites/gargeye1.spr"
#define DEATHRAYSPELL_LENGTH		500

class CDeathraySpell:public CBaseSpell{
public:
	void Spawn();
	void Precache();
	int iItemSlot() { return DEATHRAYSPELL_SLOT+1;}
	int GetItemInfo(ItemInfo *p);
	BOOL UseDecrement(){return FALSE;}

	void PrimaryAttack();
	BOOL Deploy();
	void WeaponIdle();
	void Drop();
	void Holster( int skiplocal = 0 );

	void CreateEffect( void );
	void UpdateEffect( const Vector &startPoint, const Vector &endPoint, float timeBlend );
	void DestroyEffect( void );

	CBeam* m_pBeam;
//	CSprite* m_pSprite;
	float m_flNextAmmoUseTime;
	float m_flAmmoUseTime;// since we use < 1 point of ammo per update, we subtract ammo on a timer.
	int m_iAnimation;
};

// These associate the weapon with the entity name
LINK_ENTITY_TO_CLASS( weapon_deathrayspell, CDeathraySpell );

void CDeathraySpell::Spawn(){
	m_iId = WEAPON_DEATHRAYSPELL;

	CBaseSpell::Spawn();
}

void CDeathraySpell::Precache( void ){
	PRECACHE_MODEL(DEATHRAYSPELL_BEAM);
	PRECACHE_MODEL(DEATHRAYSPELL_ENDSPRITE);
	PRECACHE_SOUND(DEATHRAYSPELL_SOUND_SHOOT);

	m_iIdleAnim=FPANIMS_RAYIDLE;
	m_iTPAnim=TPANIMS_RAY;

	CBaseSpell::Precache();
}

int CDeathraySpell::GetItemInfo(ItemInfo *p){
	p->iSlot = DEATHRAYSPELL_SLOT;
	p->iPosition = DEATHRAYSPELL_SLOTPOS;
	p->iId = m_iId = WEAPON_DEATHRAYSPELL;
	p->iWeight = DEATHRAYSPELL_WEIGHT;

	return CBaseSpell::GetItemInfo(p);
}

BOOL CDeathraySpell::Deploy(){
	m_iAnimation=0;

	return CBaseSpell::Deploy();
}

void CDeathraySpell::PrimaryAttack(){
	TraceResult tr;
	float timedist;
	
	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<DEATHRAYSPELL_COST){
		DestroyEffect();
		return;
	}
	if(m_flNextAmmoUseTime<=gpGlobals->time){
		m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]-=DEATHRAYSPELL_COST;
		m_flNextAmmoUseTime=gpGlobals->time+.3;
	}
	
	if(m_iAnimation==0){
		m_iAnimation=1;
		SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYFIRE]);
	}

	m_flTimeWeaponIdle = gpGlobals->time + 30/14;
	m_pPlayer->SetAnimation( PLAYER_ATTACK1 );

	UTIL_MakeVectors( m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle );
	Vector vecAiming = gpGlobals->v_forward;
	Vector vecSrc	 = m_pPlayer->GetGunPosition( );

	Vector vecDest = vecSrc + vecAiming * DEATHRAYSPELL_LENGTH;

	Vector tmpSrc = vecSrc + gpGlobals->v_up * -8 + gpGlobals->v_right * 3;

	UTIL_TraceLine( vecSrc, vecDest, dont_ignore_monsters, m_pPlayer->edict(), &tr );

	if (tr.fAllSolid)
		return;

	if((tr.vecEndPos-m_pPlayer->pev->origin).Length()>=DEATHRAYSPELL_LENGTH-5){
//		if(m_pSprite){
//			m_pSprite->pev->effects |= EF_NODRAW;
//		}
	}
	else{
		CBaseEntity *pEntity = CBaseEntity::Instance(tr.pHit);
//		if(m_pSprite)
//			m_pSprite->pev->effects &= ~EF_NODRAW;
	
		if (pEntity == NULL){
			return;
		}
		if(pev->dmgtime<gpGlobals->time){
			ClearMultiDamage();

			if (pEntity->pev->takedamage)
			{
				if (m_pPlayer->IRelationship(pEntity)>0){
					m_pPlayer->TakeHealth(DEATHRAYSPELL_DAMAGE/3,DMG_GENERIC);
				}
				pEntity->TraceAttack( m_pPlayer->pev, DEATHRAYSPELL_DAMAGE, vecAiming, &tr, DMG_ENERGYBEAM );
			}
			ApplyMultiDamage(m_pPlayer->pev, m_pPlayer->pev);

			pev->dmgtime = gpGlobals->time + .1;
		}
	}

	timedist = ( pev->dmgtime - gpGlobals->time ) / .025;
	if ( timedist < 0 )
		timedist = 0;
	else if ( timedist > 1 )
		timedist = 1;

	timedist = 1-timedist;
	UpdateEffect( tr.vecEndPos, tr.vecEndPos, timedist );
}

void CDeathraySpell::WeaponIdle(){
	DestroyEffect();

	if(m_iAnimation==1){
		m_iAnimation=0;
		SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYEND]);
		m_flTimeWeaponIdle=gpGlobals->time+30/14;
	}

	if (m_flTimeWeaponIdle > gpGlobals->time)
		return;

	m_iAnimation=0;
	SendWeaponAnim(FirstPersonAnims[FPANIMS_RAYIDLE]);
}

void CDeathraySpell::Drop(){
	DestroyEffect();

	CBaseSpell::Drop();
}

void CDeathraySpell::Holster( int skiplocal ){
	DestroyEffect();

	CBaseSpell::Holster();
}

void CDeathraySpell::UpdateEffect( const Vector &startPoint, const Vector &endPoint, float timeBlend ){
	if ( !m_pBeam ){
		CreateEffect();
	}

	m_pBeam->PointEntInit( pev->origin, m_pPlayer->entindex() );
	m_pBeam->SetEndAttachment( 1 );

	m_pBeam->SetStartPos( endPoint );
	m_pBeam->SetBrightness( 255 - (timeBlend*64) );
	m_pBeam->SetColor( 60 + (25*timeBlend), 120 + (30*timeBlend), 64 + 80*fabs(sin(gpGlobals->time*10)) );

//	UTIL_SetOrigin( m_pSprite->pev, endPoint );
//	m_pSprite->pev->frame += 8 * gpGlobals->frametime;
//	if ( m_pSprite->pev->frame > m_pSprite->Frames() )
//		m_pSprite->pev->frame = 0;
}

void CDeathraySpell::CreateEffect(){
//	DestroyEffect();
	if ( m_pBeam ){
		UTIL_Remove( m_pBeam );
		m_pBeam = NULL;
	}

	m_pBeam = CBeam::BeamCreate(DEATHRAYSPELL_BEAM, 55 );
	m_pBeam->PointEntInit( pev->origin, m_pPlayer->entindex() );
	m_pBeam->SetEndAttachment( 1 );
	m_pBeam->pev->spawnflags |= SF_BEAM_TEMPORARY;	// Flag these to be destroyed on save/restore or level transition

	m_pBeam->SetScrollRate( 25 );
	m_pBeam->SetWidth(64);
	m_pBeam->SetNoise( 2 );

//	m_pSprite=CSprite::SpriteCreate(DEATHRAYSPELL_ENDSPRITE,pev->origin,TRUE);
//	m_pSprite->pev->scale = 1.5;
//	m_pSprite->SetTransparency( kRenderGlow, 255, 255, 255, 255, kRenderFxNoDissipation );
//	m_pSprite->pev->spawnflags |= SF_SPRITE_TEMPORARY;

	EMIT_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,DEATHRAYSPELL_SOUND_SHOOT,DEATHRAYSPELL_SOUND_VOLUME,ATTN_NORM);
}

void CDeathraySpell::DestroyEffect(){
	if ( m_pBeam ){
		UTIL_Remove( m_pBeam );
		m_pBeam = NULL;
	}
//	if ( m_pSprite ){
//		UTIL_Remove( m_pSprite );
//		m_pSprite = NULL;
//	}

	STOP_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,DEATHRAYSPELL_SOUND_SHOOT);
}