/*
	CometSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "gamerules.h"
#include "shake.h"

// Define all constants here
#define COMETSPELL_DELAY		.5
#define COMETSPELL_COST			1

#define COMET_VELOCITY			2.0
#define COMET_SOUND_HIT			"spells/combos/comet_hit.wav"
#define COMET_SOUND_SHOOT		"weapons/rocket1.wav" 
#define COMET_SPRITE			"models/rpgrocket.mdl"
#define COMET_EXPLODE_DISTANCE	50
#define COMET_DAMAGE			800
#define COMET_RADIUS			200

enum cometspell_e {
	COMETSPELL_IDLE1 = 0,
	COMETSPELL_IDLE2,
	COMETSPELL_IDLE3,
	COMETSPELL_SHOOT,
	COMETSPELL_SHOOT_EMPTY,
	COMETSPELL_RELOAD,
	COMETSPELL_RELOAD_NOT_EMPTY,
	COMETSPELL_DRAW,
	COMETSPELL_HOLSTER,
	COMETSPELL_ADD_SILENCER
};

class CComet:public CBaseMonster{
public:
	void Spawn();
	void Precache();
	void EXPORT CometThink();
	void Killed(entvars_t *pevAttacker,int iGib);

	int m_iTrail;
	float m_flNextTrailTime;
};

void CComet::Precache(){
	PRECACHE_MODEL(COMET_SPRITE);
	PRECACHE_SOUND(COMET_SOUND_SHOOT);
	PRECACHE_SOUND("ambience/biggun3.wav");

	m_iTrail = PRECACHE_MODEL("sprites/smoke.spr");
}

void CComet::Spawn(){
	Precache();

	pev->solid = SOLID_BBOX;
	pev->movetype=MOVETYPE_NOCLIP;
	pev->effects |= EF_LIGHT;

	UTIL_MakeVectors(pev->angles);
	pev->velocity = gpGlobals->v_forward * CVAR_GET_FLOAT("sv_maxspeed")*COMET_VELOCITY; //Comets velocity now depends on globals maxspeed

	SET_MODEL(ENT(pev),COMET_SPRITE);

	SetThink(CometThink);

	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	m_flNextTrailTime=gpGlobals->time+.1;
	pev->nextthink=gpGlobals->time+.1;
}

void CComet::CometThink(){
	if(m_hEnemy==NULL){
		Killed(pev,0);
		return;
	}

	Vector vecToEnemy;

	m_vecEnemyLKP = m_hEnemy->BodyTarget(pev->origin);
	vecToEnemy = ( m_vecEnemyLKP - pev->origin ).Normalize();
	pev->velocity=(vecToEnemy*pev->velocity.Length());
	pev->angles=UTIL_VecToAngles(pev->velocity);

	if(m_flNextTrailTime<=gpGlobals->time){
		MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY );
			WRITE_BYTE( TE_BEAMFOLLOW );
			WRITE_SHORT(entindex() );	// entity
			WRITE_SHORT(m_iTrail );	// model
			WRITE_BYTE( 20 ); // life
			WRITE_BYTE( 30 );  // width
			WRITE_BYTE( 255 );   // r, g, b
			WRITE_BYTE( 0 );   // r, g, b
			WRITE_BYTE( 0 );   // r, g, b
			WRITE_BYTE( 255 );	// brightness
		MESSAGE_END();  // move PHS/PVS data sending into here (SEND_ALL, SEND_PVS, SEND_PHS)

		m_flNextTrailTime=gpGlobals->time+.3;
	}

	if((m_vecEnemyLKP-pev->origin).Length()<COMET_EXPLODE_DISTANCE || !m_hEnemy->IsAlive() ){
		if(pev->owner)
			::RadiusDamage(pev->origin,pev,VARS(pev->owner),COMET_DAMAGE,COMET_RADIUS,NULL,DMG_BURN|DMG_ALWAYSGIB|DMG_BLAST);
		else
			::RadiusDamage(pev->origin,pev,pev,COMET_DAMAGE,COMET_RADIUS,NULL,DMG_BURN|DMG_ALWAYSGIB|DMG_BLAST);
		
		MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY, pev->origin );
			WRITE_BYTE( TE_EXPLOSION);
			WRITE_COORD( pev->origin.x );
			WRITE_COORD( pev->origin.y );
			WRITE_COORD( pev->origin.z);
			WRITE_SHORT( g_sModelIndexFireball );
			WRITE_BYTE( 40  ); // scale * 10
			WRITE_BYTE( 15  ); // framerate
			WRITE_BYTE( TE_EXPLFLAG_NOSOUND );
		MESSAGE_END();

		EMIT_SOUND( ENT(pev), CHAN_VOICE, COMET_SOUND_HIT, 1, 1 );

		MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY, pev->origin);
			WRITE_BYTE(TE_BEAMTORUS);
			WRITE_COORD(pev->origin.x);
			WRITE_COORD(pev->origin.y);
			WRITE_COORD(pev->origin.z+32);
			WRITE_COORD(pev->origin.x);
			WRITE_COORD(pev->origin.y);
			WRITE_COORD(pev->origin.z+COMET_RADIUS*3);
 			WRITE_SHORT(g_sModelIndexSmoke);
			WRITE_BYTE(0); // startframe
			WRITE_BYTE(0); // framerate
			WRITE_BYTE(10); // life
			WRITE_BYTE(30);  // width
			WRITE_BYTE(5);   // noise
			WRITE_BYTE(255);   // r, g, b
			WRITE_BYTE(0);   // r, g, b
			WRITE_BYTE(0);   // r, g, b
			WRITE_BYTE(128);	// brightness
			WRITE_BYTE(1);		// speed
		MESSAGE_END();

		UTIL_ScreenShake(pev->origin, 45.0, 35.0, 12.0, 60.0);


		Killed(pev,0);
		return;
	}

	pev->nextthink=gpGlobals->time+.1;
}

void CComet::Killed(entvars_t *pevAttacker,int iGib){
	STOP_SOUND(ENT(pev), CHAN_VOICE, COMET_SOUND_SHOOT );
	
	CBaseEntity::Killed(pevAttacker,iGib);
}

LINK_ENTITY_TO_CLASS( proj_comet, CComet);


class CCometSpell : public CBasePlayerWeapon{
public:
	void Spawn( void );
	void Precache( void );
	int iItemSlot( void ) { return COMBOSPELL_SLOT+1; }
	int GetItemInfo(ItemInfo *p);

	void PrimaryAttack( void );
	void SecondaryAttack( void );
	BOOL Deploy( void );
	void WeaponIdle( void );
};

LINK_ENTITY_TO_CLASS( weapon_cometspell, CCometSpell);

void CCometSpell::Spawn( ){
	m_iId = WEAPON_COMBOSPELL;
	SET_MODEL(ENT(pev), "models/w_spellbook.mdl");
	m_iDefaultAmmo=1;

	pev->classname=MAKE_STRING("weapon_cometspell");

	FallInit();// get ready to fall down.
}

void CCometSpell::Precache( void ){
	PRECACHE_MODEL("models/v_fireballspell.mdl");
	PRECACHE_MODEL("models/w_spellbook.mdl");

	PRECACHE_SOUND("ambience/hawk1.wav");
}

int CCometSpell::GetItemInfo(ItemInfo *p){
	p->pszName = STRING(pev->classname);
	p->pszAmmo1 = "rockets";
	p->iMaxAmmo1 = 1;
	p->pszAmmo2 = "ARgrenades";
	p->iMaxAmmo2 = 4;
	p->iMaxClip = WEAPON_NOCLIP;
	p->iSlot = COMBOSPELL_SLOT;
	p->iPosition = COMBOSPELL_SLOTPOS;
	p->iFlags = 0;
	p->iId = m_iId = WEAPON_COMBOSPELL;
	p->iWeight = COMBOSPELL_WEIGHT;

	return 1;
}

BOOL CCometSpell::Deploy( ){
	m_flNextPrimaryAttack=gpGlobals->time+COMETSPELL_DELAY;

	ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Have_CometSpell");
	
	return DefaultDeploy( "models/v_fireballspell.mdl", NULL, COMETSPELL_DRAW, "onehanded" );
}

void CCometSpell::SecondaryAttack( void ){;}

void CCometSpell::PrimaryAttack( void ){
	CBaseEntity *pEnt;
	float tmp;

	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] <COMETSPELL_COST ) return; 

	m_pPlayer->SetAnimation( PLAYER_ATTACK1 ); 
	SendWeaponAnim( COMETSPELL_SHOOT );

	m_flNextPrimaryAttack = gpGlobals->time + COMETSPELL_DELAY; 
	m_flTimeWeaponIdle = gpGlobals->time + 30/14;

	m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType] -=COMETSPELL_COST;

	tmp=m_pPlayer->m_flFieldOfView;
	m_pPlayer->m_flFieldOfView=.25;
	m_pPlayer->Look(1024);
	m_pPlayer->m_flFieldOfView=tmp;

	pEnt = m_pPlayer->BestVisibleEnemy( );
	if(pEnt==NULL || m_pPlayer->IRelationship(pEnt)<0){
		EMIT_SOUND( ENT(m_pPlayer->pev), CHAN_VOICE, "ambience/hawk1.wav",1,ATTN_NORM);
	}
	else{
		Vector temp;
		CComet *met;

		temp=pEnt->pev->origin;
		temp.z=temp.z+1024;
		met=(CComet*)CBaseEntity::Create("proj_comet",temp,temp,pev->owner);
		met->m_hEnemy=pEnt;
		met->pev->team=m_pPlayer->pev->team;
	}

	if( m_pPlayer->m_rgAmmo[m_iPrimaryAmmoType]<COMETSPELL_COST ){
		g_pGameRules->GetNextBestWeapon(m_pPlayer,this);
		m_pPlayer->pev->weapons &= ~(1<<m_iId);// take item off hud
		m_pPlayer->RemovePlayerItem(this);
	}
}

void CCometSpell::WeaponIdle( void ){
	ResetEmptySound( );

	m_pPlayer->GetAutoaimVector( AUTOAIM_10DEGREES );

	if (m_flTimeWeaponIdle > gpGlobals->time)
		return;

	int iAnim;
	float flRand = RANDOM_FLOAT(0, 1);
	if (flRand <= 0.3 + 0 * 0.75)
	{
		iAnim = COMETSPELL_IDLE3;
		m_flTimeWeaponIdle = gpGlobals->time + 30/14;
	}
	else if (flRand <= 0.6 + 0 * 0.875)
	{
		iAnim = COMETSPELL_IDLE1;
		m_flTimeWeaponIdle = gpGlobals->time + 30/14;
	}
	else
	{
		iAnim = COMETSPELL_IDLE2;
		m_flTimeWeaponIdle = gpGlobals->time + 30/14;
	}
	SendWeaponAnim( iAnim );
}