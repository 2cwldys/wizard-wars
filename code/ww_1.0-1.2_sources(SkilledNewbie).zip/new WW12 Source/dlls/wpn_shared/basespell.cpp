/*
	BaseSpell.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"

#ifdef CLIENT_DLL
extern int g_iPlayerClass;
#endif

char *GetHandModel(int pc){
#ifdef CLIENT_DLL
	pc=g_iPlayerClass;
#endif
	
	switch(pc){
	case(LIFE_CLASS):
		return "models/hands/v_lifestaffhands.mdl";
		break;
	case(FIRE_CLASS):
		return "models/hands/v_firestaffhands.mdl";
		break;
	case(LIGHTNING_CLASS):
		return "models/hands/v_lightningstaffhands.mdl";
		break;
	case(DEATH_CLASS):
		return "models/hands/v_deathstaffhands.mdl";
		break;
	case(ICE_CLASS):
		return "models/hands/v_icestaffhands.mdl";
		break;
	case(NATURE_CLASS):
		return "models/hands/v_plantstaffhands.mdl";
		break;
	case(EARTH_CLASS):
		return "models/hands/v_earthstaffhands.mdl";
		break;
	case(WIND_CLASS):
		return "models/hands/v_windstaffhands.mdl";
		break;
	case(DRAGONWIZARD_CLASS):
		return "models/hands/v_dragonstaffhands.mdl";
		break;
	case(ARCHMAGE_CLASS):
		return "models/hands/v_archmagestaffhands.mdl";
		break;
	}

	return "models/hands/v_archmagestaffhands.mdl";
}

char *GetStaffModel(int pc){
	switch(pc){
	case(LIFE_CLASS):
		return "models/staves/p_lifestaff.mdl";
		break;
	case(FIRE_CLASS):
		return "models/staves/p_firestaff.mdl";
		break;
	case(LIGHTNING_CLASS):
		return "models/staves/p_lightningstaff.mdl";
		break;
	case(DEATH_CLASS):
		return "models/staves/p_scythestaff.mdl";
		break;
	case(ICE_CLASS):
		return "models/staves/p_crystalstaff.mdl";
		break;
	case(NATURE_CLASS):
		return "models/staves/p_stickstaff.mdl";
		break;
	case(EARTH_CLASS):
		return "models/staves/p_quakestaff.mdl";
		break;
	case(WIND_CLASS):
		return "models/staves/p_windstaff.mdl";
		break;
	case(DRAGONWIZARD_CLASS):
		return "models/staves/p_dragonstaff.mdl";
		break;
	case(ARCHMAGE_CLASS):
		return "models/staves/p_crookstaff.mdl";
		break;
	}

	return "models/staves/p_crookstaff.mdl";

}

void CBaseSpell::Precache( void ){
	PRECACHE_MODEL("models/hands/v_lifestaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_archmagestaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_firestaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_lightningstaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_deathstaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_icestaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_plantstaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_earthstaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_windstaffhands.mdl");
	PRECACHE_MODEL("models/hands/v_dragonstaffhands.mdl");

	PRECACHE_MODEL("models/w_spellbook.mdl");
}

void CBaseSpell::Spawn(){
	Precache();
	SET_MODEL(ENT(pev), "models/w_spellbook.mdl");

	m_iDefaultAmmo=0;

	FallInit();
}

int CBaseSpell::GetItemInfo(ItemInfo *p){
	p->pszName = STRING(pev->classname);
	p->pszAmmo1 = "uranium";
	p->iMaxAmmo1 = URANIUM_MAX_CARRY;
	p->pszAmmo2 = "ARgrenades";
	p->iMaxAmmo2 = 4;
	p->iMaxClip = WEAPON_NOCLIP;
	p->iFlags = 0;

	return 1;
}

BOOL CBaseSpell::Deploy(){
	return DefaultDeploy(GetHandModel(m_pPlayer->pev->playerclass),GetStaffModel(m_pPlayer->pev->playerclass),FirstPersonAnims[m_iIdleAnim],ThirdPersonAnims[m_iTPAnim]);
}

void CBaseSpell::WeaponIdle( void ){
	ResetEmptySound();

	m_pPlayer->GetAutoaimVector(AUTOAIM_10DEGREES);

	if(UseDecrement()){
		if(m_flTimeWeaponIdle>UTIL_WeaponTimeBase())
			return;

		SendWeaponAnim(FirstPersonAnims[m_iIdleAnim],1);
	
		m_flTimeWeaponIdle=UTIL_WeaponTimeBase()+FirstPersonAnimTimes[m_iIdleAnim];
	}
	else{
		if(m_flTimeWeaponIdle>gpGlobals->time)
			return;

		SendWeaponAnim(FirstPersonAnims[m_iIdleAnim],1);

		m_flTimeWeaponIdle=gpGlobals->time+FirstPersonAnimTimes[m_iIdleAnim];
	}
}
