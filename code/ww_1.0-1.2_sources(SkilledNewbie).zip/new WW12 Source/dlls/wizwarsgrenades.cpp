/* HOLY CRAP DOES MICROSOFT BLOW!

  A system crash just took out this file.. I hope I finish it again...

  YAY!!  I did!

  By:  Alan Fischer
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "soundent.h"
#include "gamerules.h"
#include "effects.h"
#include "tfcentities.h"

#include "wizwarsgrenades.h"
#include "monsters/dragon.h"

#define TCRYSTAL_SEARCHLENGTH				20

#define LIGHTNINGSATCHEL_BOLT_WIDTH			40
#define LIGHTNINGSATCHEL_BOLT_BRIGHTNESS	255 // Full. 
#define LIGHTNINGSATCHEL_BOLT_LIFE			5
#define LIGHTNINGSATCHEL_BOLT_NOISE			60
#define LIGHTNINGSATCHEL_DAMAGE				115
#define LIGHTNINGSATCHEL_RADIUS				175

#define POISONSATCHEL_DAMAGE				175
#define POISONSATCHEL_RADIUS				175

#define HEALHURTSATCHEL_DAMAGE				220
#define HEALHURTSATCHEL_RADIUS				175

#define FIRESPIRAL_LIFE						3
#define FIRESPIRAL_DAMAGE					75
#define FIRESPIRAL_RADIUS					90

#define FIRESATCHEL_DAMAGE					100
#define FIRESATCHEL_RADIUS					100

#define COCKLEBUR_LIFE						30
#define COCKLEBUR_OFFSET					20
#define COCKLEBUR_HEALTH					25
#define COCKLEBUR_DAMAGE					45

#define BURSATCHEL_DAMAGE					150
#define BURSATCHEL_RADIUS					100

#define EARTHQUAKESATCHEL_DAMAGE			30
#define EARTHQUAKESATCHEL_LIFE				1.4
#define EARTHQUAKESATCHEL_RADIUS			150

#define SUCTIONSATCHEL_DAMAGE				150
#define SUCTIONSATCHEL_RADIUS				300
#define SUCTIONSATCHEL_SUCTION				8
#define SUCTIONSATCHEL_UP					200

#define TOOTHSATCHEL_TOOTHDAMAGE			60
#define TOOTHSATCHEL_NUMSHOTS				50

#define TOOTHSATCHEL_DAMAGE					150
#define TOOTHSATCHEL_RADIUS					100

#define SATCHEL_VELOCITY					600

void CTCrystal::Spawn(){
	SET_MODEL(edict(),"models/w_tcrystal.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;
	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;
	pev->dmgtime=gpGlobals->time+3;

	pev->classname=MAKE_STRING("satchel");
	pev->rendercolor.z=255;
	pev->renderfx=kRenderFxGlowShell;

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CTCrystal::GrenadeThink( void ){
	if(!IsInWorld() || (pev->owner!=NULL && !Instance(pev->owner)->IsAlive())){
		UTIL_Remove( this );
		return;
	}

	StudioFrameAdvance( );
	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink( GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CTCrystal::Precache(){
	PRECACHE_MODEL("models/w_tcrystal.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");

	m_sTCrystalModelIndex=PRECACHE_MODEL("sprites/xspark2.spr");

	PRECACHE_SOUND("spells/satchels/aqua_satchel.wav");

	m_usTCrystalFire=PRECACHE_EVENT(1,"events/satchels/tcrystalfire.sc");
}
void CTCrystal::GrenadeAction(){
	Precache();
	
	Vector vOrigin=pev->origin;

	vOrigin.z+=48;
	int offset=TCRYSTAL_SEARCHLENGTH;
	int t;
	TraceResult tr;
	Vector v1;

	v1=vOrigin;
	v1.x+=offset;
	UTIL_TraceLine(vOrigin,v1,dont_ignore_monsters,edict(),&tr);
	t=offset+vOrigin.x-tr.vecEndPos.x;
	vOrigin.x=vOrigin.x-t;

	v1=vOrigin;
	v1.x-=offset;
	UTIL_TraceLine(vOrigin,v1,dont_ignore_monsters,edict(),&tr);
	t=offset-vOrigin.x+tr.vecEndPos.x;
	vOrigin.x=vOrigin.x+t;

	v1=vOrigin;
	v1.y+=offset;
	UTIL_TraceLine(vOrigin,v1,dont_ignore_monsters,edict(),&tr);
	t=offset+vOrigin.y-tr.vecEndPos.y;
	vOrigin.y=vOrigin.y-t;

	v1=vOrigin;
	v1.y-=offset;
	UTIL_TraceLine(vOrigin,v1,dont_ignore_monsters,edict(),&tr);
	t=offset-vOrigin.y+tr.vecEndPos.y;
	vOrigin.y=vOrigin.y+t;

	v1=vOrigin;
	v1.z+=offset;
	UTIL_TraceLine(vOrigin,v1,dont_ignore_monsters,edict(),&tr);
	t=offset+vOrigin.z-tr.vecEndPos.z;
	vOrigin.z=vOrigin.z-t;

	if(pev->owner!=NULL){
		CBaseEntity *pOwner=Instance(pev->owner);

		if(pOwner->IsPlayer()){
			CBasePlayer *pPlayer=(CBasePlayer*)pOwner;

			if(pPlayer->m_hMounted!=NULL){
				((CDragon*)(CBaseEntity*)pPlayer->m_hMounted)->DeMount();
			}

			if(pPlayer->m_pAttachedItem){
				pPlayer->m_pAttachedItem->DropFromPlayer();
			}
		}

		UTIL_SetOrigin(pOwner->pev,vOrigin);
	}

	PLAYBACK_EVENT_FULL(0,edict(),m_usTCrystalFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	UTIL_Remove(this);
}
LINK_ENTITY_TO_CLASS(proj_tcrystal,CTCrystal);


void CLightningSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_lightningsatchel.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CLightningSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		m_iExplosionCount=0;
		
		SetThink( GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CLightningSatchel::Precache(){
	PRECACHE_MODEL("models/w_lightningsatchel.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");

	PRECACHE_SOUND("spells/satchels/volt_satchel.wav");

	m_usLightningSatchelFire=PRECACHE_EVENT(1,"events/satchels/lightningsatchelfire.sc");
}
void CLightningSatchel::GrenadeAction(){
	Vector temp=pev->origin;

	Precache();

	temp.x+=RANDOM_FLOAT(-30,30);
	temp.y+=RANDOM_FLOAT(-30,30);
	
	if(pev->owner)
		::RadiusDamage(pev->origin,pev,VARS(pev->owner),LIGHTNINGSATCHEL_DAMAGE,LIGHTNINGSATCHEL_RADIUS,NULL,DMG_SHOCK);
	else
		::RadiusDamage(pev->origin,pev,pev,LIGHTNINGSATCHEL_DAMAGE,LIGHTNINGSATCHEL_RADIUS,NULL,DMG_SHOCK);

	PLAYBACK_EVENT_FULL(0,edict(),m_usLightningSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	if(m_iExplosionCount<2){
		m_iExplosionCount++;
		pev->nextthink=gpGlobals->time+.4;
	}
	else{
		SetThink(NULL);
		UTIL_Remove(this);
	}
}
LINK_ENTITY_TO_CLASS(proj_lightningsatchel,CLightningSatchel);


void CPoisonSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_rollingskull.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	m_hSprite=CSprite::SpriteCreate("sprites/skullsteam.spr",pev->origin,TRUE);
	((CSprite*)(CBaseEntity*)m_hSprite)->SetTransparency( kRenderTransAdd, 255, 255, 255, 255, kRenderFxNoDissipation|kRenderFxFlickerFast );
	m_hSprite->pev->framerate=20;
	m_hSprite->pev->scale=.5;
	m_hSprite->pev->movetype=MOVETYPE_FOLLOW;
	m_hSprite->pev->aiment=edict();
	((CSprite*)(CBaseEntity*)m_hSprite)->TurnOn();

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CPoisonSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink( GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CPoisonSatchel::Precache(){
	PRECACHE_MODEL("models/w_poisonsatchel.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");
	PRECACHE_MODEL("models/w_rollingskull.mdl");
	PRECACHE_MODEL("sprites/skullsteam.spr");
	m_sPoisonModelIndex=PRECACHE_MODEL("sprites/stmbal1.spr");
	
	PRECACHE_SOUND("spells/satchels/necro_satchel.wav");

	m_usPoisonSatchelFire=PRECACHE_EVENT(1,"events/satchels/poisonsatchelfire.sc");
}
void CPoisonSatchel::GrenadeAction(){
	Precache();

	if(pev->owner)
		::RadiusDamage(pev->origin,pev,VARS(pev->owner),POISONSATCHEL_DAMAGE,POISONSATCHEL_RADIUS,NULL,DMG_POISON);
	else
		::RadiusDamage(pev->origin,pev,pev,POISONSATCHEL_DAMAGE,POISONSATCHEL_RADIUS,NULL,DMG_POISON);

	PLAYBACK_EVENT_FULL(0,edict(),m_usPoisonSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	UTIL_Remove(m_hSprite);
	UTIL_Remove(this);
}
LINK_ENTITY_TO_CLASS(proj_poisonsatchel,CPoisonSatchel);


void CHealHurtSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_healhurtsatchel.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CHealHurtSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink( GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CHealHurtSatchel::Precache(){
	PRECACHE_MODEL("models/w_healhurtsatchel.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");

	m_sHealHurtModelIndex=PRECACHE_MODEL("sprites/b-tele1.spr");

	PRECACHE_SOUND("spells/satchels/life_satchel.wav");
}
void CHealHurtSatchel::GrenadeAction(){

	if(pev->owner)
		RadiusDamageAndHeal(pev->origin,pev,VARS(pev->owner),HEALHURTSATCHEL_DAMAGE,HEALHURTSATCHEL_RADIUS,0,DMG_GENERIC);
	else
		RadiusDamageAndHeal(pev->origin,pev,pev,HEALHURTSATCHEL_DAMAGE,HEALHURTSATCHEL_RADIUS,0,DMG_GENERIC);

	// Draw the Explosion
	MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY, pev->origin );
		WRITE_BYTE( TE_EXPLOSION);		
		WRITE_COORD( pev->origin.x );
		WRITE_COORD( pev->origin.y );
		WRITE_COORD( pev->origin.z);
		WRITE_SHORT( m_sHealHurtModelIndex );
		WRITE_BYTE( 25  ); // scale * 10
		WRITE_BYTE( 40  ); // framerate
		WRITE_BYTE( TE_EXPLFLAG_NOSOUND );
	MESSAGE_END();

	pev->effects |= EF_NODRAW;

	EMIT_SOUND(ENT(pev),CHAN_VOICE,"spells/satchels/life_satchel.wav",1, ATTN_NORM);

	SetThink(StopSound);
	pev->nextthink=gpGlobals->time+.5;
}
void CHealHurtSatchel::StopSound(){
	STOP_SOUND(ENT(pev),CHAN_VOICE,"spells/satchels/life_satchel.wav");

	UTIL_Remove(this);
}
void CHealHurtSatchel::RadiusDamageAndHeal( Vector vecSrc, entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, float flRadius, int iClassIgnore, int bitsDamageType )
{
	CBaseEntity *pEntity = NULL;
	TraceResult	tr;
	float		flAdjustedDamage, falloff;
	Vector		vecSpot;

	CBasePlayer *pOwner=NULL;
	if(pev->owner!=NULL)
		pOwner=(CBasePlayer*)Instance(pev->owner);

	if ( flRadius )
		falloff = flDamage / flRadius;
	else
		falloff = 1.0;

	int bInWater = (UTIL_PointContents ( vecSrc ) == CONTENTS_WATER);

	vecSrc.z += 1;// in case grenade is lying on the ground

	if ( !pevAttacker )
		pevAttacker = pevInflictor;

	// iterate on all entities in the vicinity.
	while ((pEntity = UTIL_FindEntityInSphere( pEntity, vecSrc, flRadius )) != NULL)
	{
		if ( pEntity->pev->takedamage != DAMAGE_NO )
		{
			// UNDONE: this should check a damage mask, not an ignore
			if ( iClassIgnore != CLASS_NONE && pEntity->Classify() == iClassIgnore )
			{// houndeyes don't hurt other houndeyes with their attack
				continue;
			}

			// blast's don't tavel into or out of water
			if (bInWater && pEntity->pev->waterlevel == 0)
				continue;
			if (!bInWater && pEntity->pev->waterlevel == 3)
				continue;

			vecSpot = pEntity->BodyTarget( vecSrc );
			
			UTIL_TraceLine ( vecSrc, vecSpot, dont_ignore_monsters, ENT(pevInflictor), &tr );

			if ( tr.flFraction == 1.0 || tr.pHit == pEntity->edict() )
			{// the explosion can 'see' this entity, so hurt them!
				if (tr.fStartSolid)
				{
					// if we're stuck inside them, fixup the position and distance
					tr.vecEndPos = vecSrc;
					tr.flFraction = 0.0;
				}
				
				// decrease damage for an ent that's farther from the bomb.
				flAdjustedDamage = ( vecSrc - tr.vecEndPos ).Length() * falloff;
				flAdjustedDamage = flDamage - flAdjustedDamage;
			
				if ( flAdjustedDamage < 0 )
				{
					flAdjustedDamage = 0;
				}
			
				if (pOwner->IRelationship(pEntity)<0){
					pEntity->TakeHealth(flAdjustedDamage/2,DMG_GENERIC);
				}
				// ALERT( at_console, "hit %s\n", STRING( pEntity->pev->classname ) );
				else if (tr.flFraction != 1.0)
				{
					ClearMultiDamage( );
					pEntity->TraceAttack( pevInflictor, flAdjustedDamage, (tr.vecEndPos - vecSrc).Normalize( ), &tr, bitsDamageType );
					ApplyMultiDamage( pevInflictor, pevAttacker );
				}
				else
				{
					pEntity->TakeDamage ( pevInflictor, pevAttacker, flAdjustedDamage, bitsDamageType );
				}
			}
		}
	}
}
LINK_ENTITY_TO_CLASS(proj_healhurtsatchel,CHealHurtSatchel);


void CFireSpiral :: Spawn( void )
{
	Precache( );
	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), "sprites/fexplo1.spr");
	m_maxFrame=(float)MODEL_FRAMES(pev->modelindex)-1;
	
	pev->skin = 0;
	pev->body = 0;
	pev->rendermode=kRenderTransAdd;
	pev->rendercolor.x=255;
	pev->rendercolor.y=255;
	pev->rendercolor.z=255;
	pev->renderamt=255;
	pev->frame=0;
	pev->scale=.75;

	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("proj_firespiral");

	SetThink(MoveThink);
	
	pev->velocity = Vector(0,0,0);
	pev->gravity = 0;
	pev->nextthink = gpGlobals->time + 0.1;
	pev->dmg = FIRESPIRAL_DAMAGE;
	pev->effects|=EF_DIMLIGHT;

	m_flIgniteTime=gpGlobals->time;
	m_flThetaOffset=0;

	EMIT_SOUND(ENT(pev),CHAN_VOICE,"spells/satchels/pyro_spiral.wav",1,.5);
}

void CFireSpiral :: Precache( void )
{
	PRECACHE_MODEL("sprites/fexplo1.spr");

	PRECACHE_SOUND("spells/satchels/pyro_satchel.wav");
}

void CFireSpiral :: MoveThink( void  )
{
	if(gpGlobals->time-m_flIgniteTime>FIRESPIRAL_LIFE){
		STOP_SOUND(ENT(pev),CHAN_VOICE,"spells/satchels/pyro_spiral.wav");
		UTIL_Remove(this);
	}

	pev->frame+=.61;

	Vector vOffset=Vector(0,0,0);
	float Theta=(gpGlobals->time-m_flIgniteTime)*8;

	vOffset.x=3*Theta*sin(Theta+m_flThetaOffset);
	vOffset.y=3*Theta*cos(Theta+m_flThetaOffset);
	
	UTIL_SetOrigin(pev,pev->origin+vOffset);

	if(pev->owner)
		::RadiusDamage(pev->origin,pev,VARS(pev->owner),FIRESPIRAL_DAMAGE,FIRESPIRAL_RADIUS,NULL,DMG_BURN|DMG_BLAST|DMG_SLOWBURN);
	else
		::RadiusDamage(pev->origin,pev,pev,FIRESPIRAL_DAMAGE,FIRESPIRAL_RADIUS,NULL,DMG_BURN|DMG_BLAST|DMG_SLOWBURN);
	
	if(pev->frame>m_maxFrame)
		pev->frame=0;

	pev->nextthink = gpGlobals->time + 0.1;
}
LINK_ENTITY_TO_CLASS( proj_firespiral, CFireSpiral );


void CFireSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_firestone.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;
	pev->rendercolor.x=255;
	pev->rendercolor.y=0;
	pev->rendercolor.z=0;
	pev->renderfx=kRenderFxGlowShell;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	m_hSprite=CSprite::SpriteCreate("sprites/firestone.spr",pev->origin,TRUE);
	((CSprite*)(CBaseEntity*)m_hSprite)->SetTransparency( kRenderTransAdd, 255, 255, 255, 255, kRenderFxNoDissipation|kRenderFxFlickerFast );
	m_hSprite->pev->framerate=20;
	m_hSprite->pev->scale=.5;
	m_hSprite->pev->movetype=MOVETYPE_FOLLOW;
	m_hSprite->pev->aiment=edict();
	((CSprite*)(CBaseEntity*)m_hSprite)->TurnOn();

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CFireSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink( GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CFireSatchel::Precache(){
	PRECACHE_MODEL("models/w_grenade.mdl");

	PRECACHE_MODEL("sprites/firestone.spr");
	PRECACHE_MODEL("models/w_firestone.mdl");

	m_sSpiralModelIndex=PRECACHE_MODEL("sprites/gexplo.spr");

	m_usFireSatchelFire=PRECACHE_EVENT(1,"events/satchels/firesatchelfire.sc");
}
void CFireSatchel::GrenadeAction(){
	Precache();

	if(pev->owner)
		::RadiusDamage(pev->origin,pev,VARS(pev->owner),FIRESATCHEL_DAMAGE,FIRESATCHEL_RADIUS,NULL,DMG_BURN);
	else
		::RadiusDamage(pev->origin,pev,pev,FIRESATCHEL_DAMAGE,FIRESATCHEL_RADIUS,NULL,DMG_BURN);

	Vector vOrigin=pev->origin;
	vOrigin.z+=16;
	
	CFireSpiral *pFire=(CFireSpiral*)CBaseEntity::Create("proj_firespiral",vOrigin,pev->angles,pev->owner);
	
	CFireSpiral *pFire2=(CFireSpiral*)CBaseEntity::Create("proj_firespiral",vOrigin,pev->angles,pev->owner);
	pFire2->m_flThetaOffset=M_PI;

	PLAYBACK_EVENT_FULL(0,edict(),m_usFireSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	UTIL_Remove(m_hSprite);
	UTIL_Remove(this);
}
LINK_ENTITY_TO_CLASS(proj_firesatchel,CFireSatchel);

void CCockleBur :: Spawn( void )
{
	Precache( );
	pev->movetype = MOVETYPE_TOSS;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), "models/cocklebur.mdl");
	
	UTIL_SetSize(pev, Vector( -2, -2, -2), Vector(2, 2, 2));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("proj_cocklebur");
	pev->flags|=FL_MONSTER;

	SetThink(MoveThink);
	SetTouch(GrabTouch);
	
	pev->nextthink = gpGlobals->time + 0.1;
	pev->takedamage=DAMAGE_YES;
	pev->health=COCKLEBUR_HEALTH;
	pev->dmgtime=0;

	if(pev->owner)
		m_hOwner=Instance(pev->owner);
	pev->owner=NULL;

	m_flLife=gpGlobals->time+COCKLEBUR_LIFE;

	m_flFieldOfView=0;
	Look(400);
	CBaseEntity *pTarget=BestVisibleEnemy();

	Vector vec;
	if(pTarget!=NULL){
		vec=pTarget->pev->origin-pev->origin;
		vec.z=0;
	}
	else{
		UTIL_MakeVectors(pev->angles);
		vec=gpGlobals->v_forward;
		vec.x=vec.x+RANDOM_FLOAT(-.5,.5);
		vec.y=vec.y+RANDOM_FLOAT(-.5,.5);
	}
	vec=vec.Normalize();
	pev->velocity = vec*400;
}

void CCockleBur :: Precache( void )
{
	PRECACHE_MODEL("models/cocklebur.mdl");
}

void CCockleBur :: MoveThink( void  ){
	if(m_flLife<gpGlobals->time){CBaseMonster::Killed(pev,GIB_ALWAYS);}

	if(m_hEnemy!=NULL && !m_hEnemy->IsAlive()){CBaseMonster::Killed(pev,GIB_ALWAYS);}

	if(m_hEnemy!=NULL){
		if(pev->dmgtime<=gpGlobals->time){
			if(m_hOwner!=NULL)
				m_hEnemy->TakeDamage(pev,m_hOwner->pev,COCKLEBUR_DAMAGE/4,DMG_ACID);
			else
				m_hEnemy->TakeDamage(pev,pev,COCKLEBUR_DAMAGE/4,DMG_ACID);
			pev->dmgtime=gpGlobals->time+1;
		}

		if(m_hEnemy!=NULL){
			UTIL_SetOrigin(pev,m_hEnemy->pev->origin+m_vOffset);
			m_hEnemy->pev->velocity.x=m_hEnemy->pev->velocity.x*.35;
			m_hEnemy->pev->velocity.y=m_hEnemy->pev->velocity.y*.35;
		}
	}

	pev->nextthink = gpGlobals->time + 0.1;
}

void CCockleBur::GrabTouch(CBaseEntity *pEnt){
	if(IRelationship(pEnt)>=0){//Grab him!
		if(m_hEnemy==NULL)
			m_flLife=gpGlobals->time+30;
		
		m_hEnemy=pEnt;

		m_vOffset=Vector(0,0,0);
		float Theta=RANDOM_FLOAT(0,2*M_PI);

		m_vOffset.x=COCKLEBUR_OFFSET*sin(Theta);
		m_vOffset.y=COCKLEBUR_OFFSET*cos(Theta);
		m_vOffset.z=RANDOM_FLOAT(-10,10);
	}
}

int CCockleBur::IRelationship(CBaseEntity *pEnt){
	if(pEnt==m_hOwner)
		return R_AL;

	if(m_hOwner->pev->team > 0 && pEnt->pev->team==m_hOwner->pev->team)
		return R_AL;

	if(pEnt->IsPlayer() && pev->team > 0 && m_hOwner->pev->team == pEnt->pev->team)
		return R_AL;

	if (pev->team > 0 && pev->team == pEnt->pev->team)
		return R_AL;

	if(!pEnt->IsPlayer())
		return R_AL;

	return CBaseMonster::IRelationship(pEnt);
}
LINK_ENTITY_TO_CLASS( proj_cocklebur, CCockleBur );


void CBurSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_bursatchel.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CBurSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		CBaseMonster::Killed(pev,0);
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink( GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CBurSatchel::Precache(){
	PRECACHE_MODEL("models/w_bursatchel.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");

	m_sBurModelIndex=PRECACHE_MODEL("sprites/blast.spr");

	m_usBurSatchelFire=PRECACHE_EVENT(1,"events/satchels/bursatchelfire.sc");
}
void CBurSatchel::GrenadeAction(){
	Precache();

	Vector vOrigin=pev->origin;
	vOrigin.z+=32;
	
	Vector vAngles=Vector(0,0,0);

	::RadiusDamage(pev->origin,pev,VARS(pev->owner),BURSATCHEL_DAMAGE,BURSATCHEL_RADIUS,NULL,DMG_GENERIC);

	vAngles.x=0;
	vAngles.y=1;
	CCockleBur *pBur=(CCockleBur*)CBaseEntity::Create("proj_cocklebur",vOrigin,UTIL_VecToAngles(vAngles),pev->owner);

	vAngles.x=0;
	vAngles.y=-1;
	CCockleBur *pBur2=(CCockleBur*)CBaseEntity::Create("proj_cocklebur",vOrigin,UTIL_VecToAngles(vAngles),pev->owner);

	vAngles.x=1;
	vAngles.y=0;
	CCockleBur *pBur3=(CCockleBur*)CBaseEntity::Create("proj_cocklebur",vOrigin,UTIL_VecToAngles(vAngles),pev->owner);
	
	vAngles.x=-1;
	vAngles.y=0;
	CCockleBur *pBur4=(CCockleBur*)CBaseEntity::Create("proj_cocklebur",vOrigin,UTIL_VecToAngles(vAngles),pev->owner);

	PLAYBACK_EVENT_FULL(0,edict(),m_usBurSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	UTIL_Remove(this);
}
LINK_ENTITY_TO_CLASS(proj_bursatchel,CBurSatchel);


void CEarthquakeSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_earthquakesatchel.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}

void CEarthquakeSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink(GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CEarthquakeSatchel::Precache(){
	PRECACHE_MODEL("models/w_earthquakesatchel.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");

	PRECACHE_SOUND("debris/bustconcrete2.wav");
	
	m_usEarthquakeSatchelFire=PRECACHE_EVENT(1,"events/satchels/earthquakesatchelfire.sc");
}
void CEarthquakeSatchel::GrenadeAction(){
	Precache();
	
	m_iCounter=0;

	SetThink(MakeEarthquake);

	pev->nextthink=gpGlobals->time+.1;
}
void CEarthquakeSatchel::MakeEarthquake(){
	::RadiusDamage(pev->origin,pev,VARS(pev->owner),EARTHQUAKESATCHEL_DAMAGE,EARTHQUAKESATCHEL_RADIUS*1.5,NULL,DMG_BLAST);

	if(m_iCounter%5==0){
		PLAYBACK_EVENT_FULL(0,edict(),m_usEarthquakeSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

		MESSAGE_BEGIN( MSG_PAS, SVC_TEMPENTITY,pev->origin);
			WRITE_BYTE(TE_BEAMTORUS);
			WRITE_COORD(pev->origin.x);
			WRITE_COORD(pev->origin.y);
			WRITE_COORD(pev->origin.z+32);
			WRITE_COORD(pev->origin.x);
			WRITE_COORD(pev->origin.y);
			WRITE_COORD(pev->origin.z+EARTHQUAKESATCHEL_RADIUS*3);
 			WRITE_SHORT(g_sModelIndexSmoke);
			WRITE_BYTE(0); // startframe
			WRITE_BYTE(10); // framerate
			WRITE_BYTE(EARTHQUAKESATCHEL_LIFE*2); // life
			WRITE_BYTE(30);  // width
			WRITE_BYTE(5);   // noise
			WRITE_BYTE(128);   // r, g, b
			WRITE_BYTE(32);   // r, g, b
			WRITE_BYTE(0);   // r, g, b
			WRITE_BYTE(128);	// brightness
			WRITE_BYTE(1);		// speed
		MESSAGE_END();

		UTIL_ScreenShake(pev->origin,100,100,1,EARTHQUAKESATCHEL_RADIUS);

#ifdef OLD_WEAPONS
		EMIT_SOUND(ENT(pev),CHAN_VOICE,"debris/bustconcrete2.wav",1, ATTN_NORM);
#endif
	}

	m_iCounter++;

	pev->nextthink=gpGlobals->time+.1;

	if((int)(m_iCounter/10)>=EARTHQUAKESATCHEL_LIFE){
		UTIL_Remove(this);
		return;
	}
}
LINK_ENTITY_TO_CLASS(proj_earthquakesatchel,CEarthquakeSatchel);


void CSuctionSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_cyclonesatchel.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CSuctionSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink(GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CSuctionSatchel::Precache(){
	PRECACHE_MODEL("models/w_cyclonesatchel.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");
	m_sSucModelIndex=PRECACHE_MODEL("sprites/c-tele1.spr");

	m_usSuctionSatchelFire=PRECACHE_EVENT(1,"events/satchels/suctionsatchelfire.sc");
}
void CSuctionSatchel::GrenadeAction(){
	Precache();
	
	CBaseEntity *pEntity=NULL;
	Vector vec;

	CBaseEntity *pOwner=NULL;
	pOwner=Instance(pev->owner);

	if(pOwner==NULL){
		UTIL_Remove(this);
		return;
	}

	while ((pEntity = UTIL_FindEntityInSphere( pEntity, pev->origin, SUCTIONSATCHEL_RADIUS )) != NULL){
		if (pEntity->pev->movetype!=MOVETYPE_NONE && pEntity->pev->takedamage && (g_pGameRules->PlayerRelationship(pOwner,pEntity)>0 || pEntity==pOwner)){
			pEntity->pev->velocity=pEntity->pev->origin-pev->origin;
			pEntity->pev->velocity=pEntity->pev->velocity.Normalize()*(SUCTIONSATCHEL_RADIUS-pEntity->pev->velocity.Length())*SUCTIONSATCHEL_SUCTION;

			pEntity->pev->velocity.z+=SUCTIONSATCHEL_UP;
			if(pEntity->pev->velocity.z>SUCTIONSATCHEL_UP)
				pEntity->pev->velocity.z=SUCTIONSATCHEL_UP;
		}
	}

	::RadiusDamage(pev->origin,pev,VARS(pev->owner),SUCTIONSATCHEL_DAMAGE,SUCTIONSATCHEL_RADIUS,0,DMG_GENERIC);

	PLAYBACK_EVENT_FULL(0,edict(),m_usSuctionSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

	UTIL_Remove(this);
	
	pev->nextthink=gpGlobals->time+.1;
}
int CSuctionSatchel::IRelationship(CBaseEntity *pEnt){
	if(pEnt->edict()==pev->owner)
		return R_NM;

	return CBaseMonster::IRelationship(pEnt);
}
LINK_ENTITY_TO_CLASS(proj_suctionsatchel,CSuctionSatchel);


void CToothSatchel::Spawn(){
	SET_MODEL(edict(),"models/w_dragonskull.mdl");

	pev->gravity=.5;
	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->friction=.8;

	pev->sequence = RANDOM_LONG( 3, 6 );
	pev->framerate=1.0;

	pev->classname=MAKE_STRING("satchel");

	pev->velocity=pev->angles.Normalize()*SATCHEL_VELOCITY;
	pev->angles=Vector(0,0,0);
	if(pev->owner)
		pev->angles.y=VARS(pev->owner)->angles.y;

	UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
	UTIL_SetOrigin(pev,pev->origin);

	SetThink(GrenadeThink);
	SetTouch(BounceTouch);
	pev->nextthink=gpGlobals->time+.1;
}
void CToothSatchel::GrenadeThink( void ){
	if (!IsInWorld())
	{
		UTIL_Remove( this );
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;

	if (pev->dmgtime - 1 < gpGlobals->time){
		CSoundEnt::InsertSound ( bits_SOUND_DANGER, pev->origin + pev->velocity * (pev->dmgtime - gpGlobals->time), 400, 0.1 );
	}

	if (pev->dmgtime <= gpGlobals->time){
		SetThink(GrenadeAction );
	}
	if (pev->waterlevel != 0){
		pev->velocity = pev->velocity * 0.5;
		pev->framerate = 0.2;
	}
}
void CToothSatchel::Precache(){
	PRECACHE_MODEL("models/w_dragonskull.mdl");
	PRECACHE_MODEL("models/w_grenade.mdl");
	PRECACHE_MODEL("models/dragontooth.mdl");

	m_usToothSatchelFire=PRECACHE_EVENT(1,"events/satchels/toothsatchelfire.sc");
}
void CToothSatchel::GrenadeAction(){
	Precache();
	
	CBaseEntity *pEntity=NULL;
	Vector vec;

	CBaseEntity *pOwner=NULL;
	pOwner=Instance(pev->owner);

	StudioFrameAdvance();

	if(pOwner==NULL){
		UTIL_Remove(this);
		return;
	}

	m_iExplosionCount++;

	if(m_iExplosionCount%2==1){
		pev->flags&=~FL_ONGROUND;
		pev->velocity.z=200;
		pev->sequence=3;
		ResetSequenceInfo();
	}
	else{
		TraceResult tr;
		Vector end;
			
		for(int i=0;i<TOOTHSATCHEL_NUMSHOTS;i++){
			end.x=RANDOM_FLOAT(-1,1);
			end.y=RANDOM_FLOAT(-1,1);
			end.z=RANDOM_FLOAT(-1,1);

			end=pev->origin+end.Normalize()*1000;

			UTIL_TraceLine(pev->origin,end,dont_ignore_monsters,dont_ignore_glass,0,&tr);
			
			CBaseEntity *hit=CBaseEntity::Instance(tr.pHit);

			if(hit && hit->pev->takedamage!=DAMAGE_NO){
				CBaseEntity *pOwner=NULL;
				if(pev->owner)
					pOwner=Instance(pev->owner);
				else
					pOwner=this;

				hit->TakeDamage(pev,pOwner->pev,TOOTHSATCHEL_TOOTHDAMAGE,0);
			}
		}
		PLAYBACK_EVENT_FULL(0,edict(),m_usToothSatchelFire,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);
	}
	if(m_iExplosionCount>5){
		MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY, pev->origin );
			WRITE_BYTE( TE_EXPLOSION);
			WRITE_COORD( pev->origin.x );
			WRITE_COORD( pev->origin.y );
			WRITE_COORD( pev->origin.z );
			WRITE_SHORT( g_sModelIndexFireball );
			WRITE_BYTE( 20 );
			WRITE_BYTE( 12  ); // framerate
			WRITE_BYTE( TE_EXPLFLAG_NONE );
		MESSAGE_END();

		::RadiusDamage(pev->origin,pev,VARS(pev->owner),TOOTHSATCHEL_DAMAGE,TOOTHSATCHEL_RADIUS,NULL,DMG_GENERIC);

		UTIL_Remove(this);
		return;
	}

	pev->nextthink=gpGlobals->time+.5;
}
int CToothSatchel::IRelationship(CBaseEntity *pEnt){
	if(pEnt->edict()==pev->owner)
		return R_NM;

	return CBaseMonster::IRelationship(pEnt);
}
LINK_ENTITY_TO_CLASS(proj_toothsatchel,CToothSatchel);
