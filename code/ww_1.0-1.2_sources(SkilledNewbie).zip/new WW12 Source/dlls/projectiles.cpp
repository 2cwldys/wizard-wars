/*
	MagicMissle.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "tfcentities.h"
#include "wizardwarsdefs.h"

#define MAGICMISSLE_SPRITE				"sprites/flare6.spr"
#define MAGICMISSLE_VELOCITY			1500
#define MAGICMISSLE_DAMAGE				10

class CMagicMissle : public CGrenade{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT MoveThink( void );
	void EXPORT MagicMissleTouch( CBaseEntity *pOther );

	float m_flIgniteTime;
	float m_maxFrame;
};
LINK_ENTITY_TO_CLASS( proj_magicmissle, CMagicMissle );

void CMagicMissle :: Spawn( void ){
	Precache( );
	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), MAGICMISSLE_SPRITE);

	m_maxFrame=(float)MODEL_FRAMES(pev->modelindex)-1;
	
	pev->skin = 0;
	pev->body = 0;
	pev->rendermode=kRenderTransAdd;
	pev->rendercolor.x=255;
	pev->rendercolor.y=255;
	pev->rendercolor.z=255;
	pev->renderamt=255;
	pev->frame=0;
	pev->scale=.75;

	if(pev->owner && FClassnameIs(&(pev->owner->v),"player")){
		pev->effects|=EF_NODRAW;
	}

	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("magicmissle");

	SetThink( MoveThink );
	SetTouch( MagicMissleTouch );
	
	pev->angles = UTIL_VecToAngles( gpGlobals->v_forward );
	pev->velocity = gpGlobals->v_forward * MAGICMISSLE_VELOCITY;
	pev->gravity = 0;
	pev->nextthink = UTIL_WeaponTimeBase() + 0.1;
	pev->dmg = MAGICMISSLE_DAMAGE;

	m_flIgniteTime=UTIL_WeaponTimeBase();
}

void CMagicMissle :: MagicMissleTouch ( CBaseEntity *pOther ){
	SetTouch( NULL );
	SetThink( NULL );

	if (pOther->pev->takedamage){
		TraceResult tr = UTIL_GetGlobalTrace( );
		entvars_t	*pevOwner;

		pevOwner = VARS( pev->owner );

		// UNDONE: this needs to call TraceAttack instead
		ClearMultiDamage( );

		pOther->TraceAttack(pevOwner, pev->dmg, pev->velocity.Normalize(), &tr, DMG_NEVERGIB ); 
		ApplyMultiDamage( pev, pevOwner );

		// play body "thwack" sound
		switch(RANDOM_LONG(0,1)){
		case 0:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod1.wav", 1, ATTN_NORM); break;
		case 1:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod2.wav", 1, ATTN_NORM); break;
		}
	}

	UTIL_Remove(this);
}

void CMagicMissle :: Precache( void ){
	PRECACHE_SOUND("weapons/xbow_hitbod1.wav");
	PRECACHE_SOUND("weapons/xbow_hitbod2.wav");
	
	PRECACHE_MODEL(MAGICMISSLE_SPRITE);
}

void CMagicMissle :: MoveThink( void  ){
	if(UTIL_WeaponTimeBase()-m_flIgniteTime>20){UTIL_Remove(this);}

	pev->frame++;

	if(pev->frame>m_maxFrame)
		pev->frame=0;

	pev->nextthink = UTIL_WeaponTimeBase() + 0.1;
}

#define DOUBLEMAGICMISSLE_SPRITE			"sprites/flare6.spr"
#define DOUBLEMAGICMISSLE_VELOCITY			1800
#define DOUBLEMAGICMISSLE_DAMAGE			14
#define HEALER_MM							"sprites/healermm.spr"
#define DRACO_MM							"sprites/dracomm.spr"

class CDoubleMagicMissle : public CGrenade{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT MoveThink( void );
	void EXPORT MagicMissleTouch( CBaseEntity *pOther );

	float m_flIgniteTime;
	float m_maxFrame;
};
LINK_ENTITY_TO_CLASS( proj_doublemagicmissle, CDoubleMagicMissle );

void CDoubleMagicMissle :: Spawn( void ){
	Precache( );
	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), DOUBLEMAGICMISSLE_SPRITE);

	m_maxFrame=(float)MODEL_FRAMES(pev->modelindex)-1;
	
	pev->skin = 0;
	pev->body = 0;
	pev->rendermode=kRenderTransAdd;
	pev->rendercolor.x=255;
	pev->rendercolor.y=255;
	pev->rendercolor.z=255;
	pev->renderamt=255;
	pev->frame=0;
	pev->scale=.75;

	if(pev->owner && FClassnameIs(&(pev->owner->v),"player")){
		pev->effects|=EF_NODRAW;
	}

	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("doublemagicmissle");

	SetThink( MoveThink );
	SetTouch( MagicMissleTouch );
	
	pev->angles = UTIL_VecToAngles( gpGlobals->v_forward );
	pev->velocity = gpGlobals->v_forward * DOUBLEMAGICMISSLE_VELOCITY;
	pev->gravity = 0;
	pev->nextthink = gpGlobals->time + 0.1;
	pev->dmg = DOUBLEMAGICMISSLE_DAMAGE;

	m_flIgniteTime=gpGlobals->time;
}

void CDoubleMagicMissle :: MagicMissleTouch ( CBaseEntity *pOther ){
	SetTouch( NULL );
	SetThink( NULL );

	if (pOther->pev->takedamage)
	{
		TraceResult tr = UTIL_GetGlobalTrace( );
		entvars_t	*pevOwner;

		pevOwner = VARS( pev->owner );

		// UNDONE: this needs to call TraceAttack instead
		ClearMultiDamage( );

		pOther->TraceAttack(pevOwner,pev->dmg, pev->velocity.Normalize(), &tr, DMG_NEVERGIB ); 
		ApplyMultiDamage( pev, pevOwner );

		// play body "thwack" sound
		switch( RANDOM_LONG(0,1) )
		{
		case 0:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod1.wav", 1, ATTN_NORM); break;
		case 1:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod2.wav", 1, ATTN_NORM); break;
		}
	}

	UTIL_Remove(this);
}

void CDoubleMagicMissle :: Precache( void ){
	PRECACHE_SOUND("weapons/xbow_hitbod1.wav");
	PRECACHE_SOUND("weapons/xbow_hitbod2.wav");
	
	PRECACHE_MODEL(DOUBLEMAGICMISSLE_SPRITE);
}


void CDoubleMagicMissle :: MoveThink( void  ){
	if(gpGlobals->time-m_flIgniteTime>20){UTIL_Remove(this);}

	pev->frame++;

	if(pev->frame>m_maxFrame)
		pev->frame=0;

	pev->nextthink = gpGlobals->time + 0.1;
}

#define FIREBALL_SOUND_SHOOT		"spells/fireball.wav" 
#define FIREBALL_MODEL				"models/rpgrocket.mdl"
#define FIREBALL_SOUND_VOLUME		0.25 
#define FIREBALL_DAMAGE				100
#define FIREBALL_CONTACTDMG			50

class CFireball : public CGrenade{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT MoveThink( void );
	void EXPORT FireballTouch( CBaseEntity *pOther );
	static CFireball *CreateFireball( Vector vecOrigin, CBaseEntity *pOwner);

	int m_iTrail;

private:
	unsigned short m_usFireballTrail;
};
LINK_ENTITY_TO_CLASS( proj_fireball, CFireball );

void CFireball :: Spawn( void ){
	Precache( );
	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), FIREBALL_MODEL);
	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("fireball");

	SetThink( MoveThink );
	pev->nextthink = gpGlobals->time + 20;

	SetTouch( FireballTouch );

	pev->angles = UTIL_VecToAngles( gpGlobals->v_forward );
	pev->velocity = gpGlobals->v_forward * 650;

	pev->dmg = FIREBALL_DAMAGE;
	pev->effects |= EF_LIGHT;
	pev->effects|=EF_DIMLIGHT;

	EMIT_SOUND( ENT(pev), CHAN_VOICE, FIREBALL_SOUND_SHOOT, 1, 0.5 );

	PLAYBACK_EVENT_FULL(0,edict(),m_usFireballTrail,0,(float *)&g_vecZero,(float *)&g_vecZero,0,0,0,0,0,0);

#ifdef OLD_WEAPONS
	// Black trail
	MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY );
		WRITE_BYTE( TE_BEAMFOLLOW );
		WRITE_SHORT(entindex() );	// entity
		WRITE_SHORT(m_iTrail );	// model
		WRITE_BYTE( 5 ); // life
		WRITE_BYTE( 20 );  // width
		WRITE_BYTE( 0 );   // r, g, b
		WRITE_BYTE( 0 );   // r, g, b
		WRITE_BYTE( 0 );   // r, g, b
		WRITE_BYTE( 255 );	// brightness
	MESSAGE_END();
	// Grey trail
	MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY );
		WRITE_BYTE( TE_BEAMFOLLOW );
		WRITE_SHORT(entindex() );	// entity
		WRITE_SHORT(m_iTrail );	// model
		WRITE_BYTE( 10 ); // life
		WRITE_BYTE( 15 );  // width
		WRITE_BYTE( 75 );   // r, g, b
		WRITE_BYTE( 75 );   // r, g, b
		WRITE_BYTE( 75 );   // r, g, b
		WRITE_BYTE( 255 );	// brightness
	MESSAGE_END();
	// Light Grey trail
	MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY );
		WRITE_BYTE( TE_BEAMFOLLOW );
		WRITE_SHORT(entindex() );	// entity
		WRITE_SHORT(m_iTrail );	// model
		WRITE_BYTE( 15 ); // life
		WRITE_BYTE( 10 );  // width
		WRITE_BYTE( 150 );   // r, g, b
		WRITE_BYTE( 150 );   // r, g, b
		WRITE_BYTE( 150 );   // r, g, b
		WRITE_BYTE( 255 );	// brightness
	MESSAGE_END();
#endif
}

void CFireball :: FireballTouch ( CBaseEntity *pOther ){
	TraceResult tr;
	Vector		vecSpot;// trace starts here!

	STOP_SOUND(ENT(pev), CHAN_VOICE, FIREBALL_SOUND_SHOOT );
	SetThink(NULL);

	if(pOther->pev->takedamage){
		if(pev->owner)
			pOther->TakeDamage(pev,VARS(pev->owner),FIREBALL_CONTACTDMG,DMG_BURN|DMG_SLOWBURN);
		else
			pOther->TakeDamage(pev,pev,FIREBALL_CONTACTDMG,DMG_BURN|DMG_SLOWBURN);
	}

	pev->enemy = pOther->edict();

	vecSpot = pev->origin - pev->velocity.Normalize() * 32;
	UTIL_TraceLine( vecSpot, vecSpot + pev->velocity.Normalize() * 64, ignore_monsters, ENT(pev), &tr );

	Explode( &tr, DMG_BLAST|DMG_SLOWBURN );

	UTIL_Remove(this);
}

void CFireball :: Precache( void ){
	PRECACHE_MODEL(FIREBALL_MODEL);
	m_iTrail = PRECACHE_MODEL("sprites/smoke.spr");
	PRECACHE_SOUND (FIREBALL_SOUND_SHOOT);

	m_usFireballTrail=PRECACHE_EVENT(1,"events/fireballtrail.sc");
}

void CFireball :: MoveThink( void ){
	STOP_SOUND(ENT(pev), CHAN_VOICE, FIREBALL_SOUND_SHOOT );
	UTIL_Remove(this);
}

#define ICEPOKE_MODEL				"models/icepoke.mdl"
#define ICEPOKE_DAMAGE				14

class CIcepoke : public CGrenade{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT IcepokeTouch( CBaseEntity *pOther );

	int m_iTrail;
};
LINK_ENTITY_TO_CLASS( proj_icepoke, CIcepoke );

void CIcepoke :: Spawn( void ){
	Precache( );

	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), ICEPOKE_MODEL);

	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("icepoke");

	SetThink( SUB_Remove );
	pev->nextthink = gpGlobals->time + 20;

	SetTouch( IcepokeTouch );
	
	pev->angles = UTIL_VecToAngles( gpGlobals->v_forward );
	pev->velocity = gpGlobals->v_forward * 1000;
	pev->velocity = pev->velocity+Vector(RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40),RANDOM_FLOAT(-40,40));
	pev->dmg = ICEPOKE_DAMAGE;

	if(pev->owner && FClassnameIs(&(pev->owner->v),"player")){
		pev->effects|=EF_NODRAW;
	}
	else{
		pev->rendercolor.z=255;
		pev->renderfx=kRenderFxGlowShell;

		MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY );
			WRITE_BYTE( TE_BEAMFOLLOW );
			WRITE_SHORT(entindex() );	// entity
			WRITE_SHORT(m_iTrail );	// model
			WRITE_BYTE( 2 ); // life
			WRITE_BYTE( 2 );  // width
			WRITE_BYTE( 0 );   // r, g, b
			WRITE_BYTE( 0 );   // r, g, b
			WRITE_BYTE( 255 );   // r, g, b
			WRITE_BYTE( 255 );	// brightness
		MESSAGE_END();  // move PHS/PVS data sending into here (SEND_ALL, SEND_PVS, SEND_PHS)
	}
}

void CIcepoke :: IcepokeTouch ( CBaseEntity *pOther ){
	SetTouch( NULL );
	SetThink( NULL );

	if (pOther->pev->takedamage)
	{
		TraceResult tr = UTIL_GetGlobalTrace( );
		entvars_t	*pevOwner;

		pevOwner = VARS( pev->owner );

		ClearMultiDamage( );

		pOther->TraceAttack(pevOwner,pev->dmg,pev->velocity.Normalize(),&tr,DMG_NEVERGIB|DMG_FREEZE); 
		ApplyMultiDamage( pev, pevOwner );

		// play body "thwack" sound
		switch( RANDOM_LONG(0,1) )
		{
		case 0:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod1.wav", 1, ATTN_NORM); break;
		case 1:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod2.wav", 1, ATTN_NORM); break;
		}
	}

	UTIL_Remove(this);
}

void CIcepoke :: Precache( void ){
	PRECACHE_SOUND("weapons/xbow_hitbod1.wav");
	PRECACHE_SOUND("weapons/xbow_hitbod2.wav");

	PRECACHE_MODEL(ICEPOKE_MODEL);
	m_iTrail = PRECACHE_MODEL("sprites/smoke.spr");
}

#define FLYINGSKULL_VELOCITY	1
#define FLYINGSKULL_DAMAGE		35
#define FLYINGSKULL_MODEL		"models/flyingskull.mdl"
#define FLYINGSKULL_LIFETIME	.8
#define FLYINGSKULL_HEALTH		10
#define FLYINGSKULL_SOUND_SHOOT	"ambience/alienclicker1.wav"

class CFlyingSkull : public CBaseMonster{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT MoveThink( void );
	void EXPORT FlyingSkullTouch( CBaseEntity *pOther );
	void Killed( entvars_t *pevAttacker, int iGib );
	int IRelationship ( CBaseEntity *pTarget );
	int Classify();

	EHANDLE m_hOwner;
	float m_flDie;
	float m_flIgniteTime;
	int m_iTrail;
};
LINK_ENTITY_TO_CLASS( proj_flyingskull, CFlyingSkull );

void CFlyingSkull :: Spawn( void ){
	Precache( );

	SET_MODEL(ENT(pev), FLYINGSKULL_MODEL);
	UTIL_SetSize(pev, Vector( -4, -4, 0), Vector(4, 4, 8));

	SetThink( MoveThink );
	SetTouch( FlyingSkullTouch );

	pev->movetype = MOVETYPE_FLY;
	pev->classname = MAKE_STRING("flyingskull");
	pev->flags |= FL_MONSTER;
	pev->takedamage	= DAMAGE_YES;
	pev->health = FLYINGSKULL_HEALTH;
	pev->dmg = FLYINGSKULL_DAMAGE;
	pev->rendercolor.x=255;
	pev->renderfx=kRenderFxGlowShell;

	pev->angles = UTIL_VecToAngles(gpGlobals->v_forward);
	pev->velocity = gpGlobals->v_forward * CVAR_GET_FLOAT("sv_maxspeed")*FLYINGSKULL_VELOCITY; //Skulls velocity now depends on globals maxspeed

	pev->sequence = 0;
	ResetSequenceInfo( );

	m_flFieldOfView=VIEW_FIELD_NARROW;
	m_flDie=gpGlobals->time+FLYINGSKULL_LIFETIME;
	m_flIgniteTime=gpGlobals->time+.1;
	m_hEnemy=NULL;

	if(pev->owner){
		m_hOwner=CBaseEntity::Instance(pev->owner);
	}
		
	pev->solid = SOLID_BBOX;
	pev->nextthink = gpGlobals->time + 0.1;
	UTIL_SetOrigin( pev, pev->origin );

	pev->nextthink = gpGlobals->time + 0.1;

	EMIT_SOUND( ENT(pev), CHAN_VOICE, FLYINGSKULL_SOUND_SHOOT, 1, 0.5 );

	// Red trail
	MESSAGE_BEGIN( MSG_BROADCAST, SVC_TEMPENTITY );
		WRITE_BYTE( TE_BEAMFOLLOW );
		WRITE_SHORT(entindex() );	// entity
		WRITE_SHORT(m_iTrail );	// model
		WRITE_BYTE( 4 ); // life
		WRITE_BYTE( 5 );  // width
		WRITE_BYTE( 255 );   // r, g, b
		WRITE_BYTE( 0 );   // r, g, b
		WRITE_BYTE( 0 );   // r, g, b
		WRITE_BYTE( 128 );	// brightness
	MESSAGE_END();
}

void CFlyingSkull::Killed( entvars_t *pevAttacker, int iGib ){
	STOP_SOUND(ENT(pev),CHAN_VOICE,FLYINGSKULL_SOUND_SHOOT);

	CBaseEntity::Killed(pevAttacker,iGib);
}

void CFlyingSkull :: FlyingSkullTouch ( CBaseEntity *pOther ){
	ClearMultiDamage();

	if(pOther->pev->takedamage){
		if(m_hOwner)
			pOther->TakeDamage( pev, m_hOwner->pev, FLYINGSKULL_DAMAGE, DMG_NEVERGIB);
		else
			pOther->TakeDamage( pev, pev, FLYINGSKULL_DAMAGE, DMG_NEVERGIB);
	}

	ApplyMultiDamage(pOther->pev, pOther->pev);

	// reset owner so death message happens
	if(m_hOwner!=NULL)
		pev->owner=m_hOwner->edict();

	Killed(pev,0);
}

void CFlyingSkull :: Precache( void ){
	PRECACHE_MODEL(FLYINGSKULL_MODEL);
	m_iTrail = PRECACHE_MODEL("sprites/smoke.spr");
	PRECACHE_SOUND(FLYINGSKULL_SOUND_SHOOT);
}

int CFlyingSkull::Classify(){
	return CLASS_PLAYER_BIOWEAPON;
}

void CFlyingSkull :: MoveThink( void  ){
	Vector vecToEnemy;

	if (!IsInWorld()){
		Killed(pev,0);
		return;
	}
	if (gpGlobals->time >= m_flDie){
		Killed( pev, 0 );
		return;
	}
	if ( m_hEnemy != NULL && FVisible( m_hEnemy )){
		m_vecEnemyLKP = m_hEnemy->BodyTarget( pev->origin );
		vecToEnemy = ( m_vecEnemyLKP - pev->origin ).Normalize();
		pev->velocity=(vecToEnemy*pev->velocity.Length());
		pev->angles=UTIL_VecToAngles(pev->velocity);

		m_flDie=gpGlobals->time+FLYINGSKULL_LIFETIME;
	}
	else{//Find something else
		Look(400);
		m_hEnemy = BestVisibleEnemy( );
	}
	
	StudioFrameAdvance( );
	pev->nextthink = gpGlobals->time + 0.1;
}

int CFlyingSkull::IRelationship ( CBaseEntity *pTarget ){
	if( pTarget->pev->takedamage==DAMAGE_NO ) return R_NO; //Don't attack stones

	if(pTarget->pev->owner == pev->owner)
		return R_AL;

	if(!pTarget->IsPlayer())
		return R_AL;

	if(pTarget->IsPlayer() && pTarget->pev->playerclass==ICE_CLASS){
			CBasePlayer* pl=((CBasePlayer*)pTarget);
			CIceWizard* bw=((CIceWizard*)pl->m_pClass);

			if(bw->m_iIsInvisible==TRUE && pTarget->pev->renderamt<20)
				return R_NO;

			if(pev->team!=0 && bw->m_iDisguisedTeam==pev->team)
				return R_NO;
	}

	return CBaseMonster::IRelationship(pTarget);
}

#define ROLLINGSTONE_DAMAGE				80
#define ROLLINGSTONE_VELOCITY			700
#define ROLLINGSTONE_MODEL				"models/rollingstone.mdl"
#define ROLLINGSTONE_LIFETIME			4
#define ROLLINGSTONE_BOUNCE_SOUND		"weapons/ric5.wav"

class CRollingStone : public CGrenade{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT MoveThink( void );
	void EXPORT RollingStoneTouch( CBaseEntity *pOther );
	void Killed( entvars_t *pevAttacker, int iGib );

	EHANDLE m_hOwner;
	float m_flDie;
};
LINK_ENTITY_TO_CLASS( proj_rollingstone, CRollingStone );

void CRollingStone :: Spawn( void ){
	Precache( );

	SET_MODEL(ENT(pev), ROLLINGSTONE_MODEL);
	UTIL_SetSize(pev, Vector( -4, -4, -4), Vector(4, 4, 4));
	UTIL_SetOrigin( pev, pev->origin );

	SetThink( MoveThink );
	SetTouch( RollingStoneTouch );

	pev->nextthink = gpGlobals->time + 0.1;

	pev->movetype = MOVETYPE_BOUNCE;
	pev->solid = SOLID_BBOX;
	pev->classname = MAKE_STRING("rollingstone");
	pev->flags |= FL_MONSTER;
	pev->takedamage	= DAMAGE_NO;
	pev->dmg = ROLLINGSTONE_DAMAGE;

	pev->angles = UTIL_VecToAngles(gpGlobals->v_forward);
	pev->velocity = gpGlobals->v_forward * ROLLINGSTONE_VELOCITY;

	pev->sequence = 0;
	ResetSequenceInfo();

	pev->framerate=-1;

	m_flDie = gpGlobals->time + ROLLINGSTONE_LIFETIME;

	if(pev->owner)
		m_hOwner=Instance(pev->owner);
}

void CRollingStone :: Killed( entvars_t *pevAttacker, int iGib ){
	SetTouch( NULL );

	CBaseEntity::Killed(pevAttacker,iGib);
}

void CRollingStone :: RollingStoneTouch ( CBaseEntity *pOther ){
	if(pOther->pev->takedamage){
		if(m_hOwner!=NULL)
			pOther->TakeDamage(pev,m_hOwner->pev,pev->velocity.Length()/ROLLINGSTONE_VELOCITY*pev->dmg,DMG_NEVERGIB); 
		else
			pOther->TakeDamage(pev,pev,pev->velocity.Length()/ROLLINGSTONE_VELOCITY*pev->dmg,DMG_NEVERGIB); 
		Killed(pOther->pev,GIB_NEVER);
	}

	pev->velocity=pev->velocity-pev->velocity*.2;

	pev->framerate=-pev->velocity.Length()/ROLLINGSTONE_VELOCITY;

	if(pev->velocity.Length()>ROLLINGSTONE_VELOCITY*1/8)
		EMIT_SOUND(ENT(pev),CHAN_VOICE,ROLLINGSTONE_BOUNCE_SOUND,1,ATTN_NORM);
}

void CRollingStone :: Precache( void ){
	PRECACHE_MODEL(ROLLINGSTONE_MODEL);

	PRECACHE_SOUND(ROLLINGSTONE_BOUNCE_SOUND);
}


void CRollingStone :: MoveThink( void  ){
	if(ROLLINGSTONE_LIFETIME-(m_flDie-gpGlobals->time)>1)
		pev->owner=NULL;

	StudioFrameAdvance();

	Vector vecToEnemy;

	if (!IsInWorld()){
		Killed(pev,0);
		return;
	}
	
	if (gpGlobals->time >= m_flDie){
		g_vecAttackDir = pev->velocity.Normalize( );
		pev->health = -1;
		Killed(pev,0);
		return;
	}

	pev->nextthink = gpGlobals->time + 0.1;
}

#define BIRD_VELOCITY		1000
#define BIRD_VOLUME			1
#define BIRD_DAMAGE			35

class CBird : public CBaseMonster
{
public:
	void Spawn( void );
	void Precache( void );
	int	 Classify ( void );
	int  IRelationship ( CBaseEntity *pTarget );
	void Killed(entvars_t *pevAttacker,int iGib);
	virtual int		Save( CSave &save );
	virtual int		Restore( CRestore &restore );
	static	TYPEDESCRIPTION m_SaveData[];

	void IgniteTrail( void );
	void EXPORT StartTrack ( void );
	void EXPORT StartDart ( void );
	void EXPORT TrackTarget ( void );
	void EXPORT TrackTouch ( CBaseEntity *pOther );
	void EXPORT DartTouch( CBaseEntity *pOther );
	void EXPORT DieTouch ( CBaseEntity *pOther );
	
	int TakeDamage( entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType );

	float			m_flStopAttack;
	float			m_flVelocity;
};

LINK_ENTITY_TO_CLASS( proj_bird, CBird );

//=========================================================
// Save/Restore
//=========================================================
TYPEDESCRIPTION	CBird::m_SaveData[] = 
{
	DEFINE_FIELD( CBird, m_flStopAttack, FIELD_TIME ),
};

IMPLEMENT_SAVERESTORE( CBird, CBaseMonster );

//=========================================================
// don't let birds gib, ever.
//=========================================================
int CBird :: TakeDamage( entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType )
{
	// filter these bits a little.
	bitsDamageType &= ~ ( DMG_ALWAYSGIB );
	bitsDamageType |= DMG_NEVERGIB;

	return CBaseMonster :: TakeDamage ( pevInflictor, pevAttacker, flDamage, bitsDamageType );
}

//=========================================================
//=========================================================
void CBird :: Spawn( void )
{
	pev->movetype	= MOVETYPE_FLY;
	pev->solid		= SOLID_BBOX;
	pev->takedamage = DAMAGE_YES;
	pev->flags		|= FL_MONSTER;
	pev->health		= 1;// weak!
	
	m_flStopAttack = gpGlobals->time + 3.5;

	m_flFieldOfView = 0.9; // +- 25 degrees

	m_flVelocity=BIRD_VELOCITY;

	SET_MODEL(ENT( pev ), "models/bird.mdl");
	UTIL_SetSize( pev, Vector( -4, -4, -4 ), Vector( 4, 4, 4 ) );

	SetTouch( DieTouch );
	SetThink( StartTrack );

	edict_t *pSoundEnt = pev->owner;
	if ( !pSoundEnt )
		pSoundEnt = edict();

	EMIT_SOUND( pSoundEnt, CHAN_WEAPON, "spells/birdspell.wav", 1, ATTN_NORM);

	pev->dmg=BIRD_DAMAGE;
	
	pev->nextthink = gpGlobals->time + 0.1;
	ResetSequenceInfo( );
}

void CBird :: Precache()
{
	PRECACHE_MODEL("models/bird.mdl");

	PRECACHE_SOUND("spells/birdspell.wav");

//	PRECACHE_SOUND( "hornet/ag_buzz1.wav" );
//	PRECACHE_SOUND( "hornet/ag_buzz2.wav" );
//	PRECACHE_SOUND( "hornet/ag_buzz3.wav" );

	PRECACHE_SOUND( "hornet/ag_hornethit1.wav" );
	PRECACHE_SOUND( "hornet/ag_hornethit2.wav" );
	PRECACHE_SOUND( "hornet/ag_hornethit3.wav" );
}	

void CBird::Killed(entvars_t *pevAttacker,int iGib){
	CBaseEntity::Killed(pevAttacker,iGib);
}

//=========================================================
// birds will never get mad at each other, no matter who the owner is.
//=========================================================
int CBird::IRelationship ( CBaseEntity *pTarget )
{
	if ( pTarget->pev->modelindex == pev->modelindex )
	{
		return R_NO;
	}

	if(pTarget->pev->owner == pev->owner)
		return R_AL;

	if(pTarget->IsPlayer() && pTarget->pev->playerclass==ICE_CLASS){
			CBasePlayer* pl=((CBasePlayer*)pTarget);
			CIceWizard* bw=((CIceWizard*)pl->m_pClass);

			if(bw->m_iIsInvisible==TRUE && pTarget->pev->renderamt<20)
				return R_NO;

			if(pev->team!=0 && bw->m_iDisguisedTeam==pev->team)
				return R_NO;
	}

	return CBaseMonster :: IRelationship( pTarget );
}

//=========================================================
// ID's Bird as their owner
//=========================================================
int CBird::Classify ( void )
{

	if ( pev->owner && pev->owner->v.flags & FL_CLIENT)
	{
		return CLASS_PLAYER_BIOWEAPON;
	}

	return	CLASS_ALIEN_BIOWEAPON;
}

//=========================================================
// StartTrack - starts a bird out tracking its target
//=========================================================
void CBird :: StartTrack ( void )
{
	IgniteTrail();

	SetTouch( TrackTouch );
	SetThink( TrackTarget );

	pev->nextthink = gpGlobals->time + 0.1;
}

//=========================================================
// StartDart - starts a bird out just flying straight.
//=========================================================
void CBird :: StartDart ( void )
{
	IgniteTrail();

	SetTouch( DartTouch );

	SetThink( SUB_Remove );
	pev->nextthink = gpGlobals->time + 4;
}

void CBird::IgniteTrail( void )
{
	//No trail for now
}

//=========================================================
// Bird is flying, gently tracking target
//=========================================================
void CBird :: TrackTarget ( void )
{
	Vector	vecFlightDir;
	Vector	vecDirToEnemy;
	float	flDelta;

	StudioFrameAdvance( );

	if (gpGlobals->time > m_flStopAttack)
	{
		SetTouch( NULL );
		SetThink( SUB_Remove );
		pev->nextthink = gpGlobals->time + 0.1;
		return;
	}

	// UNDONE: The player pointer should come back after returning from another level
	if ( m_hEnemy == NULL )
	{// enemy is dead.
		Look( 512 );
		m_hEnemy = BestVisibleEnemy( );
	}
	
	if ( m_hEnemy != NULL && FVisible( m_hEnemy ))
	{
		m_vecEnemyLKP = m_hEnemy->BodyTarget( pev->origin );
	}
	else
	{
		m_vecEnemyLKP = m_vecEnemyLKP + pev->velocity * m_flVelocity * 0.1;
	}

	vecDirToEnemy = ( m_vecEnemyLKP - pev->origin ).Normalize();

	if (pev->velocity.Length() < 0.1)
		vecFlightDir = vecDirToEnemy;
	else 
		vecFlightDir = pev->velocity.Normalize();

	// measure how far the turn is, the wider the turn, the slow we'll go this time.
	flDelta = DotProduct ( vecFlightDir, vecDirToEnemy );
	
//	if ( flDelta < 0.5 ){// hafta turn wide again. play sound
//		switch (RANDOM_LONG(0,2)){
//		case 0:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_buzz1.wav", BIRD_VOLUME, ATTN_NORM);	break;
//		case 1:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_buzz2.wav", BIRD_VOLUME, ATTN_NORM);	break;
//		case 2:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_buzz3.wav", BIRD_VOLUME, ATTN_NORM);	break;
//		}
//	}

	if ( flDelta <= 0 )
	{// no flying backwards, but we don't want to invert this, cause we'd go fast when we have to turn REAL far.
		flDelta = 0.25;
	}

	pev->velocity = ( vecFlightDir + vecDirToEnemy).Normalize();

	if ( pev->owner && (pev->owner->v.flags & FL_MONSTER) )
	{
		// random pattern only applies to birds fired by monsters, not players. 

		pev->velocity.x += RANDOM_FLOAT ( -0.10, 0.10 );// scramble the flight dir a bit.
		pev->velocity.y += RANDOM_FLOAT ( -0.10, 0.10 );
		pev->velocity.z += RANDOM_FLOAT ( -0.10, 0.10 );
	}
	
	pev->velocity = pev->velocity * ( m_flVelocity * flDelta );// scale the dir by the ( speed * width of turn )
	pev->nextthink = gpGlobals->time + RANDOM_FLOAT( 0.1, 0.3 );

	pev->angles = UTIL_VecToAngles (pev->velocity);

	pev->solid = SOLID_BBOX;
}

//=========================================================
// Tracking Bird hit something
//=========================================================
void CBird :: TrackTouch ( CBaseEntity *pOther )
{
	if ( pOther->edict() == pev->owner || pOther->pev->modelindex == pev->modelindex )
	{// bumped into the guy that shot it.
		pev->solid = SOLID_NOT;
		return;
	}

	if ( IRelationship( pOther ) <= R_NO )
	{
		// hit something we don't want to hurt, so turn around.

		pev->velocity = pev->velocity.Normalize();

		pev->velocity.x *= -1;
		pev->velocity.y *= -1;

		pev->origin = pev->origin + pev->velocity * 4; // bounce the bird off a bit.
		pev->velocity = pev->velocity * m_flVelocity;

		return;
	}

	DieTouch( pOther );
}

void CBird::DartTouch( CBaseEntity *pOther )
{
	DieTouch( pOther );
}

void CBird::DieTouch ( CBaseEntity *pOther )
{
	if ( pOther && pOther->pev->takedamage )
	{// do the damage

		switch (RANDOM_LONG(0,2))
		{// buzz when you plug someone
		case 0:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_hornethit1.wav", 1, ATTN_NORM);	break;
		case 1:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_hornethit2.wav", 1, ATTN_NORM);	break;
		case 2:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_hornethit3.wav", 1, ATTN_NORM);	break;
		}
		
		pOther->TakeDamage( pev, VARS( pev->owner ), pev->dmg, DMG_BULLET );
	}

	pev->modelindex = 0;// so will disappear for the 0.1 secs we wait until NEXTTHINK gets rid
	pev->solid = SOLID_NOT;

	SetThink ( SUB_Remove );
	pev->nextthink = gpGlobals->time + 1;// stick around long enough for the sound to finish!
}

#define MINDMISSLE_SPRITE				"sprites/xspark1.spr"
#define MINDMISSLE_VELOCITY				1200
#define MINDMISSLE_DAMAGE				20

class CMindMissle : public CGrenade{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT MoveThink( void );
	void EXPORT MindMissleTouch( CBaseEntity *pOther );

	float m_flIgniteTime;
	float m_maxFrame;
};
LINK_ENTITY_TO_CLASS( proj_mindmissle, CMindMissle );

void CMindMissle :: Spawn( void ){
	Precache( );
	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;

	SET_MODEL(ENT(pev), MINDMISSLE_SPRITE);
	m_maxFrame=(float)MODEL_FRAMES(pev->modelindex)-1;
	
	pev->skin = 0;
	pev->body = 0;
	pev->rendermode=kRenderTransAdd;
	pev->rendercolor.x=255;
	pev->rendercolor.y=255;
	pev->rendercolor.z=255;
	pev->renderamt=255;
	pev->frame=0;
	pev->scale=.75;

	if(pev->owner && FClassnameIs(&(pev->owner->v),"player")){
		pev->effects|=EF_NODRAW;
	}

	UTIL_SetSize(pev, Vector( 0, 0, 0), Vector(0, 0, 0));
	UTIL_SetOrigin( pev, pev->origin );

	pev->classname = MAKE_STRING("mindmissle");

	SetThink( MoveThink );
	SetTouch( MindMissleTouch );
	
	pev->angles = UTIL_VecToAngles( gpGlobals->v_forward );
	pev->velocity = gpGlobals->v_forward * MINDMISSLE_VELOCITY;
	pev->gravity = 0;
	pev->nextthink = gpGlobals->time + 0.1;
	pev->dmg = MINDMISSLE_DAMAGE;

	m_flIgniteTime=gpGlobals->time;
}

void CMindMissle :: MindMissleTouch ( CBaseEntity *pOther ){
	SetTouch( NULL );
	SetThink( NULL );

	pOther->pev->punchangle=Vector(RANDOM_FLOAT(-20,20),RANDOM_FLOAT(-20,20),RANDOM_FLOAT(-20,20));

	if(pev->owner && (!FClassnameIs(pOther->pev, "monster_thornbush")))
		pOther->Touch(Instance(pev->owner));

	if(!FClassnameIs(pOther->pev,"monster_dragon") && pOther->ObjectCaps()&(FCAP_IMPULSE_USE|FCAP_CONTINUOUS_USE|FCAP_ONOFF_USE)){
			CBaseEntity *pPlayer=Instance(pev->owner);
			if(pPlayer==NULL)
				pPlayer=this;
			pOther->Use(pPlayer,pPlayer,USE_TOGGLE,0);
	}
	else if(strcmp(STRING(pOther->pev->classname),"func_button")==0 || strcmp(STRING(pOther->pev->classname),"func_door")==0){
		if(((CBaseToggle*)pOther)->m_iGoalActivation&TFCGOAL_ACTIVATION_MINDMISSLE){
			CBaseEntity *pPlayer=Instance(pev->owner);
			if(pPlayer==NULL)
				pPlayer=this;
			pOther->Use(pPlayer,pPlayer,USE_TOGGLE,0);
		}
	}

	if (pOther->pev->takedamage){
		TraceResult tr = UTIL_GetGlobalTrace( );
		entvars_t	*pevOwner;

		pevOwner = VARS( pev->owner );

		// UNDONE: this needs to call TraceAttack instead
		ClearMultiDamage( );

		pOther->TraceAttack(pevOwner, pev->dmg, pev->velocity.Normalize(), &tr, DMG_NEVERGIB ); 
		ApplyMultiDamage( pev, pevOwner );

		// play body "thwack" sound
		switch( RANDOM_LONG(0,1) )
		{
		case 0:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod1.wav", 1, ATTN_NORM); break;
		case 1:
			EMIT_SOUND(ENT(pev), CHAN_WEAPON, "weapons/xbow_hitbod2.wav", 1, ATTN_NORM); break;
		}
	}

	UTIL_Remove(this);
}

void CMindMissle :: Precache( void ){
	PRECACHE_SOUND("weapons/xbow_hitbod1.wav");
	PRECACHE_SOUND("weapons/xbow_hitbod2.wav");
	
	PRECACHE_MODEL(MINDMISSLE_SPRITE);
}

void CMindMissle :: MoveThink( void  ){
	if(gpGlobals->time-m_flIgniteTime>20){UTIL_Remove(this);}

	pev->frame++;

	if(pev->frame>m_maxFrame)
		pev->frame=0;

	pev->nextthink = gpGlobals->time + 0.1;
}

class CSpellAmmo : public CBasePlayerAmmo{
	void Spawn( void ){
		Precache( );
		SET_MODEL(ENT(pev), "models/w_spellbook.mdl");
		CBasePlayerAmmo::Spawn( );
	}
	void Precache( void ){
		PRECACHE_MODEL ("models/w_spellbook.mdl");
		PRECACHE_SOUND("items/gunpickup2.wav");
	}
	BOOL AddAmmo( CBaseEntity *pOther ){ 
		if(CVAR_GET_FLOAT("mp_combochaos")>0 && pOther->IsPlayer()){
			CBasePlayer *pPlayer=(CBasePlayer*)pOther;

			for(int i=0;i<MAX_ITEM_TYPES;i++){
				if(pPlayer->m_rgpPlayerItems[i] && pPlayer->m_rgpPlayerItems[i]->iItemSlot()==5){
					return FALSE;
				}
			}

			if(pPlayer->m_pClass==NULL)
				return FALSE;

			int x=(int)RANDOM_FLOAT(0,2);

			switch(pPlayer->pev->playerclass){
			case(LIFE_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_spiritwizspell");
				else
					pPlayer->GiveNamedItem("weapon_wombatspell");
				break;
			case(FIRE_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_meteorspell");
				else
					pPlayer->GiveNamedItem("weapon_balllightningspell");
				break;
			case(ICE_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_lightningcloudspell");
				else
					pPlayer->GiveNamedItem("weapon_giantplantspell");
				break;
			case(NATURE_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_spiritwizspell");
				else
					pPlayer->GiveNamedItem("weapon_giantplantspell");
				break;
			case(LIGHTNING_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_lightningcloudspell");
				else
					pPlayer->GiveNamedItem("weapon_balllightningspell");
				break;
			case(DEATH_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_meteorspell");
				else
					pPlayer->GiveNamedItem("weapon_skeletonspell");
				break;
			case(EARTH_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_tornadospell");
				else
					pPlayer->GiveNamedItem("weapon_wombatspell");
				break;
			case(WIND_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_tornadospell");
				else
					pPlayer->GiveNamedItem("weapon_dragonspell");
				break;			
			case(DRAGONWIZARD_CLASS):
				if(x==1)
					pPlayer->GiveNamedItem("weapon_dragonspell");
				else
					pPlayer->GiveNamedItem("weapon_skeletonspell");
				break;			
			case(ARCHMAGE_CLASS):
				pPlayer->GiveNamedItem("weapon_cometspell");
				break;
			}

			return TRUE;
		}
		else if (pOther->GiveAmmo( AMMO_URANIUMBOX_GIVE, "uranium", URANIUM_MAX_CARRY ) != -1){
			EMIT_SOUND(ENT(pev), CHAN_ITEM, "items/gunpickup2.wav", 1, ATTN_NORM);
			return TRUE;
		}
		return FALSE;
	}
};
LINK_ENTITY_TO_CLASS( ammo_spellbook, CSpellAmmo );

LINK_ENTITY_TO_CLASS( ammo_9mmclip, CSpellAmmo );
LINK_ENTITY_TO_CLASS( ammo_9mmAR, CSpellAmmo );
LINK_ENTITY_TO_CLASS( ammo_buckshot, CSpellAmmo );
LINK_ENTITY_TO_CLASS( ammo_crossbow, CSpellAmmo );
LINK_ENTITY_TO_CLASS( ammo_357, CSpellAmmo );
LINK_ENTITY_TO_CLASS( ammo_rpgclip, CSpellAmmo );
LINK_ENTITY_TO_CLASS( ammo_gaussclip, CSpellAmmo );

class CSatchelAmmo:public CBasePlayerAmmo{
	void Spawn(){
		Precache();
		SET_MODEL(ENT(pev),"models/w_spellbook.mdl");
		CBasePlayerAmmo::Spawn();
	}
	void Precache(){
		PRECACHE_MODEL("models/w_spellbook.mdl");
		PRECACHE_SOUND("items/gunpickup2.wav");
	}
	BOOL AddAmmo(CBaseEntity *pOther){
		if(pOther->GiveAmmo(2,"ARgrenades",4)!=-1){
			EMIT_SOUND(ENT(pev),CHAN_ITEM,"items/gunpickup2.wav",1,ATTN_NORM);
			return TRUE;
		}
		return FALSE;
	}
};
LINK_ENTITY_TO_CLASS(ammo_satchels,CSatchelAmmo);
LINK_ENTITY_TO_CLASS(ammo_ARgrenades, CSatchelAmmo );
LINK_ENTITY_TO_CLASS(ammo_mp5grenades, CSatchelAmmo );

#include "gamerules.h"

class CTriggerComet:public CPointEntity{
	void Use(CBaseEntity *pOther,CBaseEntity *pCaller,USE_TYPE useType,float value){
		CBaseMonster* pComet=(CBaseMonster*)Create("proj_comet",pOther->pev->origin+Vector(0,0,800),pOther->pev->angles);
		pComet->m_hEnemy=pOther;
	}
};
LINK_ENTITY_TO_CLASS(trigger_comet,CTriggerComet);

#define WYVERN_VELOCITY		600
#define WYVERN_VOLUME		1
#define WYVERN_DAMAGE		30

class CWyvern : public CBaseMonster
{
public:
	void Spawn( void );
	void Precache( void );
	int	 Classify ( void );
	int  IRelationship ( CBaseEntity *pTarget );
	void Killed(entvars_t *pevAttacker,int iGib);
	virtual int		Save( CSave &save );
	virtual int		Restore( CRestore &restore );
	static	TYPEDESCRIPTION m_SaveData[];
	void Explode();

	void IgniteTrail( void );
	void EXPORT StartTrack ( void );
	void EXPORT StartDart ( void );
	void EXPORT TrackTarget ( void );
	void EXPORT TrackTouch ( CBaseEntity *pOther );
	void EXPORT DartTouch( CBaseEntity *pOther );
	void EXPORT DieTouch ( CBaseEntity *pOther );
	
	int TakeDamage( entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType );

	float			m_flStopAttack;
	float			m_flVelocity;
};

LINK_ENTITY_TO_CLASS( proj_wyvern, CWyvern );

//=========================================================
// Save/Restore
//=========================================================
TYPEDESCRIPTION	CWyvern::m_SaveData[] = 
{
	DEFINE_FIELD( CWyvern, m_flStopAttack, FIELD_TIME ),
};

IMPLEMENT_SAVERESTORE( CWyvern, CBaseMonster );

//=========================================================
// don't let wyverns gib, ever.
//=========================================================
int CWyvern :: TakeDamage( entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, int bitsDamageType )
{
	// filter these bits a little.
	bitsDamageType &= ~ ( DMG_ALWAYSGIB );
	bitsDamageType |= DMG_NEVERGIB;

	return CBaseMonster :: TakeDamage ( pevInflictor, pevAttacker, flDamage, bitsDamageType );
}

//=========================================================
//=========================================================
void CWyvern :: Spawn( void )
{
	pev->movetype	= MOVETYPE_FLY;
	pev->solid		= SOLID_BBOX;
	pev->takedamage = DAMAGE_YES;
	pev->flags		|= FL_MONSTER;
	pev->health		= 1;// weak!
	
	m_flStopAttack = gpGlobals->time + 1.5;

	m_flFieldOfView = .7; // +- 45 degrees

	m_flVelocity=WYVERN_VELOCITY;

	SET_MODEL(ENT( pev ), "models/wyvern.mdl");
	UTIL_SetSize( pev, Vector( -4, -4, -4 ), Vector( 4, 4, 4 ) );

	SetTouch( DieTouch );
	SetThink( StartTrack );

	edict_t *pSoundEnt = pev->owner;
	if ( !pSoundEnt )
		pSoundEnt = edict();

	EMIT_SOUND( pSoundEnt, CHAN_WEAPON, "headcrab/hc_pain1.wav", 1, ATTN_NORM);

	pev->dmg=WYVERN_DAMAGE;
	
	pev->nextthink = gpGlobals->time + 0.1;
	ResetSequenceInfo( );
}

void CWyvern :: Precache()
{
	PRECACHE_MODEL("models/wyvern.mdl");

	PRECACHE_SOUND("headcrab/hc_pain1.wav");

//	PRECACHE_SOUND( "hornet/ag_buzz1.wav" );
//	PRECACHE_SOUND( "hornet/ag_buzz2.wav" );
//	PRECACHE_SOUND( "hornet/ag_buzz3.wav" );

	PRECACHE_SOUND( "hornet/ag_hornethit1.wav" );
	PRECACHE_SOUND( "hornet/ag_hornethit2.wav" );
	PRECACHE_SOUND( "hornet/ag_hornethit3.wav" );
}	

void CWyvern::Killed(entvars_t *pevAttacker,int iGib){
	CBaseEntity::Killed(pevAttacker,iGib);
}

//=========================================================
// wyverns will never get mad at each other, no matter who the owner is.
//=========================================================
int CWyvern::IRelationship ( CBaseEntity *pTarget )
{
	if ( pTarget->pev->modelindex == pev->modelindex )
	{
		return R_NO;
	}

	if(!pTarget->IsPlayer())
		return R_AL;

	if(pTarget->IsPlayer() && pTarget->pev->playerclass==ICE_CLASS){
			CBasePlayer* pl=((CBasePlayer*)pTarget);
			CIceWizard* bw=((CIceWizard*)pl->m_pClass);

			if(bw->m_iIsInvisible==TRUE && pTarget->pev->renderamt<20)
				return R_NO;

			if(pev->team!=0 && bw->m_iDisguisedTeam==pev->team)
				return R_NO;
	}

	return CBaseMonster :: IRelationship( pTarget );
}

//=========================================================
// ID's Wyvern as their owner
//=========================================================
int CWyvern::Classify ( void )
{

	if ( pev->owner && pev->owner->v.flags & FL_CLIENT)
	{
		return CLASS_PLAYER_BIOWEAPON;
	}

	return	CLASS_ALIEN_BIOWEAPON;
}

//=========================================================
// StartTrack - starts a wyvern out tracking its target
//=========================================================
void CWyvern :: StartTrack ( void )
{
	IgniteTrail();

	SetTouch( TrackTouch );
	SetThink( TrackTarget );

	pev->nextthink = gpGlobals->time + 0.1;
}

//=========================================================
// StartDart - starts a wyvern out just flying straight.
//=========================================================
void CWyvern :: StartDart ( void )
{
	IgniteTrail();

	SetTouch( DartTouch );

	SetThink( SUB_Remove );
	pev->nextthink = gpGlobals->time + 4;
}

void CWyvern::IgniteTrail( void )
{
	//No trail for now
}

//=========================================================
// Wyvern is flying, gently tracking target
//=========================================================
void CWyvern :: TrackTarget ( void )
{
	Vector	vecFlightDir;
	Vector	vecDirToEnemy;
	float	flDelta;

	StudioFrameAdvance( );

	if (gpGlobals->time > m_flStopAttack)
	{
		Explode();
		return;
	}

	// UNDONE: The player pointer should come back after returning from another level
	if ( m_hEnemy == NULL )
	{// enemy is dead.
		Look( 512 );
		m_hEnemy = BestVisibleEnemy( );
	}
	
	if ( m_hEnemy != NULL && FVisible( m_hEnemy ))
	{
		m_vecEnemyLKP = m_hEnemy->BodyTarget( pev->origin );
	}
	else
	{
		m_vecEnemyLKP = m_vecEnemyLKP + pev->velocity * m_flVelocity * 0.1;
	}

	vecDirToEnemy = ( m_vecEnemyLKP - pev->origin ).Normalize();

	if (pev->velocity.Length() < 0.1)
		vecFlightDir = vecDirToEnemy;
	else 
		vecFlightDir = pev->velocity.Normalize();

	// measure how far the turn is, the wider the turn, the slow we'll go this time.
	flDelta = DotProduct ( vecFlightDir, vecDirToEnemy );
	
//	if ( flDelta < 0.5 ){// hafta turn wide again. play sound
//		switch (RANDOM_LONG(0,2)){
//		case 0:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_buzz1.wav", WYVERN_VOLUME, ATTN_NORM);	break;
//		case 1:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_buzz2.wav", WYVERN_VOLUME, ATTN_NORM);	break;
//		case 2:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_buzz3.wav", WYVERN_VOLUME, ATTN_NORM);	break;
//		}
//	}

	if ( flDelta <= 0 )
	{// no flying backwards, but we don't want to invert this, cause we'd go fast when we have to turn REAL far.
		flDelta = 0.25;
	}

	pev->velocity = ( vecFlightDir + vecDirToEnemy).Normalize();

	if ( pev->owner && (pev->owner->v.flags & FL_MONSTER) )
	{
		// random pattern only applies to wyverns fired by monsters, not players. 

		pev->velocity.x += RANDOM_FLOAT ( -0.10, 0.10 );// scramble the flight dir a bit.
		pev->velocity.y += RANDOM_FLOAT ( -0.10, 0.10 );
		pev->velocity.z += RANDOM_FLOAT ( -0.10, 0.10 );
	}
	
	pev->velocity = pev->velocity * ( m_flVelocity * flDelta );// scale the dir by the ( speed * width of turn )
	pev->nextthink = gpGlobals->time + RANDOM_FLOAT( 0.1, 0.3 );

	pev->angles = UTIL_VecToAngles (pev->velocity);

	pev->solid = SOLID_BBOX;
}

//=========================================================
// Tracking Wyvern hit something
//=========================================================
void CWyvern :: TrackTouch ( CBaseEntity *pOther )
{
	if ( pOther->edict() == pev->owner || pOther->pev->modelindex == pev->modelindex )
	{// bumped into the guy that shot it.
		pev->solid = SOLID_NOT;
		return;
	}

	if ( IRelationship( pOther ) <= R_NO )
	{
		// hit something we don't want to hurt, so turn around.

		pev->velocity = pev->velocity.Normalize();

		pev->velocity.x *= -1;
		pev->velocity.y *= -1;

		pev->origin = pev->origin + pev->velocity * 4; // bounce the wyvern off a bit.
		pev->velocity = pev->velocity * m_flVelocity;

		return;
	}

	DieTouch( pOther );
}

void CWyvern::DartTouch( CBaseEntity *pOther )
{
	DieTouch( pOther );
}

void CWyvern::DieTouch ( CBaseEntity *pOther )
{
	if ( pOther && pOther->pev->takedamage )
	{// do the damage

		switch (RANDOM_LONG(0,2))
		{// buzz when you plug someone
		case 0:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_hornethit1.wav", 1, ATTN_NORM);	break;
		case 1:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_hornethit2.wav", 1, ATTN_NORM);	break;
		case 2:	EMIT_SOUND( ENT(pev), CHAN_VOICE, "hornet/ag_hornethit3.wav", 1, ATTN_NORM);	break;
		}
		
		pOther->TakeDamage( pev, VARS( pev->owner ), pev->dmg, DMG_BULLET );
	}

	Explode();
}

void CWyvern::Explode(){
	RadiusDamage(pev,VARS(pev->owner),WYVERN_DAMAGE,0,DMG_BURN);

	MESSAGE_BEGIN( MSG_PAS, SVC_TEMPENTITY, pev->origin );
		WRITE_BYTE( TE_EXPLOSION );		// This makes a dynamic light and the explosion sprites/sound
		WRITE_COORD( pev->origin.x );	// Send to PAS because of the sound
		WRITE_COORD( pev->origin.y );
		WRITE_COORD( pev->origin.z );
		WRITE_SHORT( g_sModelIndexFireball );
		WRITE_BYTE( 20  ); // scale * 10
		WRITE_BYTE( 15  ); // framerate
		WRITE_BYTE( TE_EXPLFLAG_NONE );
	MESSAGE_END();

	UTIL_Remove(this);
}

class CSoul:public CBaseEntity{
public:
	void Precache(){
		PRECACHE_MODEL("sprites/soul2.spr");
		PRECACHE_MODEL("sprites/soul.spr");
	}

	virtual void EXPORT Think(){
		pev->frame++;

		if(pev->frame>m_maxFrame)
			UTIL_Remove(this);

		pev->nextthink=gpGlobals->time+.1;
	}

	virtual void Spawn(){
		Precache();

		UTIL_SetOrigin(pev,pev->origin);

		pev->solid=SOLID_NOT;
		pev->movetype=MOVETYPE_FLY;
		pev->rendermode=kRenderTransAdd;
		pev->rendercolor.x=255;
		pev->rendercolor.y=255;
		pev->rendercolor.z=255;
		pev->renderamt=255;
		pev->frame=0;
		pev->scale=.2;
		pev->velocity.z=100;

		UTIL_SetOrigin(pev,pev->origin);		

		pev->nextthink=gpGlobals->time+.1;
	}

	short m_maxFrame;
};

class CLifeSoul:public CSoul{
	void Spawn(){
		SET_MODEL(ENT(pev),"sprites/soul2.spr");

		m_maxFrame=(float)MODEL_FRAMES(pev->modelindex)-1;

		CSoul::Spawn();
	}
};
LINK_ENTITY_TO_CLASS(lifesoul,CLifeSoul);

class CDeathSoul:public CSoul{
	void Spawn(){
		SET_MODEL(ENT(pev),"sprites/soul.spr");

		m_maxFrame=(float)MODEL_FRAMES(pev->modelindex)-1;

		CSoul::Spawn();
	}
};
LINK_ENTITY_TO_CLASS(deathsoul,CDeathSoul);
