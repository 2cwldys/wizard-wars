/* tfcentities.cpp

  Made for WizWars, to take TFC Levels

  By: Alan Fischer
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "effects.h"
#include "saverestore.h"
#include "weapons.h"
#include "nodes.h"
#include "doors.h"
#include "game.h"
#include "gamerules.h"
#include "teamplay_gamerules.h"
#include "items.h"
#include "player.h"
#include "tfcentities.h"
#include "wizardwarsdefs.h"

extern int gmsgItemPickup;
extern int g_iTeams;
extern int g_iClass;
extern int g_iMaxOnTeam[5];
extern int g_iMinForTeam[5];
extern int g_iTeamAllies[5];
extern int g_iTeamScore[5];
extern ClassLimits *g_pClassLimits;
extern int g_iTeamLives[5];
extern int g_iItemStatus[5];
extern int g_szTeamStrHome;
extern int g_szTeamStrCarried;
extern int g_szTeamStrMoved;
extern int g_szNonTeamStrHome;
extern int g_szNonTeamStrCarried;
extern int g_szNonTeamStrMoved;

extern int gmsgTeamScore;

enum key_e {
	NOT_CARRIED = 0,
	CARRIED
};

class CTFDetect : public CPointEntity{
	void KeyValue(KeyValueData *pkvd){
		if(FStrEq(pkvd->szKeyName,"ammo_medikit")){
			g_iMaxOnTeam[1]=atoi(pkvd->szValue);
		
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"ammo_detpack")){
			g_iMaxOnTeam[2]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"maxammo_medikit")){
			g_iMaxOnTeam[3]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"maxammo_detpack")){
			g_iMaxOnTeam[4]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"maxammo_shells")){
			ConvertLimits(1,atoi(pkvd->szValue));
		
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"maxammo_nails")){
			ConvertLimits(2,atoi(pkvd->szValue));

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"maxammo_rockets")){
			ConvertLimits(3,atoi(pkvd->szValue));

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"maxammo_cells")){
			ConvertLimits(4,atoi(pkvd->szValue));

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team1_allies")){
			g_iTeamAllies[1]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team2_allies")){
			g_iTeamAllies[2]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team3_allies")){
			g_iTeamAllies[3]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team4_allies")){
			g_iTeamAllies[4]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"ammo_shells")){
			g_iTeamLives[1]=atoi(pkvd->szValue);
			if(g_iTeamLives[1]==0)
				g_iTeamLives[1]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"ammo_nails")){
			g_iTeamLives[2]=atoi(pkvd->szValue);
			if(g_iTeamLives[2]==0)
				g_iTeamLives[2]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"ammo_rockets")){
			g_iTeamLives[3]=atoi(pkvd->szValue);
			if(g_iTeamLives[3]==0)
				g_iTeamLives[3]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"ammo_cells")){
			g_iTeamLives[4]=atoi(pkvd->szValue);
			if(g_iTeamLives[4]==0)
				g_iTeamLives[4]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status1")){
			g_iItemStatus[1]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status2")){
			g_iItemStatus[2]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status3")){
			g_iItemStatus[3]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status4")){
			g_iItemStatus[4]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team_str_home")){
			g_szTeamStrHome=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team_str_moved")){
			g_szTeamStrMoved=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team_str_carried")){
			g_szTeamStrCarried=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"non_team_str_home")){
			g_szNonTeamStrHome=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"non_team_str_moved")){
			g_szNonTeamStrMoved=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"non_team_str_carried") || FStrEq(pkvd->szKeyName,"n_t_s_c")){
			g_szNonTeamStrCarried=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else
			CPointEntity::KeyValue(pkvd);
	}

	void Spawn(void){
		Precache();
	}

	void ConvertLimits(int team,int x){
		int classlim=0;

		if(x==-1){
			classlim=(1<<ARCHMAGE_CLASS);
		}

		else{
			x=~x;

			if(x&CLASSLIMITS_LIFE)
				classlim|=(1<<LIFE_CLASS);
			if(x&CLASSLIMITS_FIRE)
				classlim|=(1<<FIRE_CLASS);
			if(x&CLASSLIMITS_ICE)
				classlim|=(1<<ICE_CLASS);
			if(x&CLASSLIMITS_NATURE)
				classlim|=(1<<NATURE_CLASS);
			if(x&CLASSLIMITS_LIGHTNING)
				classlim|=(1<<LIGHTNING_CLASS);
			if(x&CLASSLIMITS_DEATH)
				classlim|=(1<<DEATH_CLASS);
			if(x&CLASSLIMITS_EARTH)
				classlim|=(1<<EARTH_CLASS);
			if(x&CLASSLIMITS_WIND)
				classlim|=(1<<WIND_CLASS);
			if(x&CLASSLIMITS_DRACOMANCER)
				classlim|=(1<<DRAGONWIZARD_CLASS);
		}

		g_pClassLimits->SetClassLimits(team,classlim);
	}
};
		
LINK_ENTITY_TO_CLASS(info_tfdetect, CTFDetect);


class CItemShieldMagic : public CItem
{
	virtual int GetArmorValue(){
		return(20);
	}

	void Spawn( void )
	{ 
		Precache( );
		SET_MODEL(ENT(pev), "models/w_shield.mdl");

		CItem::Spawn( );

		pev->sequence=0;
		ResetSequenceInfo();
		SetThink(SpinThink);
		pev->nextthink=gpGlobals->time+.1;
	}
	void Precache( void )
	{
		PRECACHE_MODEL ("models/w_shield.mdl");
		PRECACHE_SOUND( "items/gunpickup2.wav" );
	}
	BOOL MyTouch( CBasePlayer *pPlayer )
	{
		if ((pPlayer->pev->armorvalue < pPlayer->pev->armortype) &&
			(pPlayer->pev->weapons & (1<<WEAPON_SUIT)))
		{
			int pct;
			char szcharge[64];

			pPlayer->pev->armorvalue += GetArmorValue();
			pPlayer->pev->armorvalue = min(pPlayer->pev->armorvalue,pPlayer->pev->armortype);

			EMIT_SOUND( pPlayer->edict(), CHAN_ITEM, "items/gunpickup2.wav", 1, ATTN_NORM );

			MESSAGE_BEGIN( MSG_ONE, gmsgItemPickup, NULL, pPlayer->pev );
				WRITE_STRING( STRING(pev->classname) );
			MESSAGE_END();

			
			// Suit reports new power level
			// For some reason this wasn't working in release build -- round it.
			pct = (int)( (float)(pPlayer->pev->armorvalue * 100.0) * (1.0/pPlayer->pev->armortype) + 0.5);
			pct = (pct / 5);
			if (pct > 0)
				pct--;
		
			sprintf( szcharge,"!HEV_%1dP", pct );
			
			//EMIT_SOUND_SUIT(ENT(pev), szcharge);
			pPlayer->SetSuitUpdate(szcharge, FALSE, SUIT_NEXT_IN_30SEC);
			return TRUE;		
		}
		return FALSE;
	}
	void EXPORT SpinThink(){
		StudioFrameAdvance();

		pev->nextthink=gpGlobals->time+.1;
	}
	void Materialize( void ){
		if ( pev->effects & EF_NODRAW )
		{
			// changing from invisible state to visible.
			EMIT_SOUND_DYN( ENT(pev), CHAN_WEAPON, "items/suitchargeok1.wav", 1, ATTN_NORM, 0, 150 );
			pev->effects &= ~EF_NODRAW;
			pev->effects |= EF_MUZZLEFLASH;
		}

		ResetSequenceInfo();
		SetTouch( ItemTouch );
		SetThink(SpinThink);
		pev->nextthink=gpGlobals->time+.1;
	}
};

LINK_ENTITY_TO_CLASS(item_armor1, CItemShieldMagic);

class CItemShieldMagic2 : public CItemShieldMagic{
	int GetArmorValue(){
		return(60);
	}
};

LINK_ENTITY_TO_CLASS(item_armor2, CItemShieldMagic2);

class CItemShieldMagic3 : public CItemShieldMagic{
	int GetArmorValue(){
		return(100);
	}
};
LINK_ENTITY_TO_CLASS(item_armor3, CItemShieldMagic3);


class CBaseTeamspawn : public CBaseToggle
{
public:
	void		Spawn();
	void		KeyValue( KeyValueData *pkvd );
	BOOL		IsTriggered( CBaseEntity *pEntity );
	void		Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value);
};

void CBaseTeamspawn::KeyValue( KeyValueData *pkvd )
{
	if (FStrEq(pkvd->szKeyName, "team_no")){
		pev->team=atoi(pkvd->szValue);
		switch(pev->team){
		case(1):
			g_iTeams|=1;
			break;
		case(2):
			g_iTeams|=2;
			break;
		case(3):
			g_iTeams|=4;
			break;
		case(4):
			g_iTeams|=8;
			break;
		}
		pkvd->fHandled = TRUE;
	}
	else if (FStrEq(pkvd->szKeyName, "playerclass")){
		pev->playerclass=atoi(pkvd->szValue);
		switch(pev->playerclass){
		case(1):
			g_iClass|=1;
			break;
		case(2):
			g_iClass|=2;
			break;
		case(3):
			g_iClass|=3;
			break;
		case(4):
			g_iClass|=4;
			break;
		case(5):
			g_iClass|=5;
			break;
		case(6):
			g_iClass|=6;
			break;
		case(7):
			g_iClass|=7;
			break;
		case(8):
			g_iClass|=8;
			break;
		case(9):
			g_iClass|=9;
			break;
		case(10):
			g_iClass|=10;
			break;
		}
		pkvd->fHandled=TRUE;
	}
	else
	{
		CBaseToggle::KeyValue( pkvd );
	}
}

void CBaseTeamspawn::Spawn(){
	pev->classname=MAKE_STRING("info_player_teamspawn");

	if(m_iGoalState==0)
		m_iGoalState=TFCGOAL_INACTIVE;
}

BOOL CBaseTeamspawn::IsTriggered( CBaseEntity *pEntity )
{
//	BOOL master = UTIL_IsMasterTriggered( pev->netname, pEntity );

//	return master;
	return TRUE;

	//TODO:Make this work
}

void CBaseTeamspawn::Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value){
	SUB_UseTargets(pActivator,useType,value);

	//HACK?
	m_iGoalState=TFCGOAL_INACTIVE;
}

LINK_ENTITY_TO_CLASS(info_player_teamspawn,CBaseTeamspawn);
LINK_ENTITY_TO_CLASS(i_p_t,CBaseTeamspawn);

/* *** TFC Stuff for Toggles *** */

static CBaseEntity* FindEntityByGoal(int goal){
	CBaseEntity* pEnt;
	CBaseEntity* pStart;
	pStart=NULL;

	if(goal==0)
		return NULL;

	pStart=UTIL_FindEntityByClassname(NULL,"info_tfgoal");
	pEnt=pStart;
	do{
		if(pEnt!=NULL && ((CBaseToggle*)pEnt)->m_iGoalNo==goal){
			return pEnt;
		}
		
		pEnt=UTIL_FindEntityByClassname(pEnt,"info_tfgoal");
	}while(pStart!=pEnt);

	pStart=UTIL_FindEntityByClassname(NULL,"item_tfgoal");
	pEnt=pStart;
	do{
		if(pEnt!=NULL && ((CBaseToggle*)pEnt)->m_iGoalNo==goal){
			return pEnt;
		}
		
		pEnt=UTIL_FindEntityByClassname(pEnt,"item_tfgoal");
	}while(pStart!=pEnt);

	return NULL;
}

BOOL CheckGroupStatus(int group,int state){
	CBaseEntity *pStart,*pEnt;

	pStart=UTIL_FindEntityByClassname(NULL,"info_tfgoal");
	pEnt=pStart;
	do{
		if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==group && ((CTFCGoal*)pEnt)->m_iGoalState!=state){
			return FALSE;
		}
		
		pEnt=UTIL_FindEntityByClassname(pEnt,"info_tfgoal");
	}while(pStart!=pEnt);

	pStart=UTIL_FindEntityByClassname(NULL,"item_tfgoal");
	pEnt=pStart;
	do{
		if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==group && ((CTFCGoal*)pEnt)->m_iGoalState!=state){
			return FALSE;
		}
		
		pEnt=UTIL_FindEntityByClassname(pEnt,"item_tfgoal");
	}while(pStart!=pEnt);

	return TRUE;
}

int CBaseToggle::UTIL_IsMasterTriggered(string_t sMaster, CBaseEntity *pActivator){	
	BOOL canGoState=TRUE;
	BOOL canGoGoal=TRUE;

	if(m_iGoalState==TFCGOAL_ACTIVE && m_flWait!=-1)
		InactivateGoal();

	if(m_iGoalState==TFCGOAL_ACTIVE && !(strcmp(STRING(pev->classname),"func_door")==0 || strcmp(STRING(pev->classname),"func_button")==0)){
		canGoState=FALSE;
	}

	if(m_iGoalState==TFCGOAL_REMOVED && m_iGoalActivation&TFCGOAL_ACTIVATION_TOUCH){
		canGoState=FALSE;
	}

	if(pActivator!=NULL){
		if(pev->team!=0 && pev->team!=pActivator->pev->team){
			canGoGoal=FALSE;
		}

		if(pev->playerclass!=0 && pActivator->IsPlayer()){
			CBasePlayer *pPlayer=(CBasePlayer*)pActivator;
		
			if(pPlayer->m_pClass!=NULL){
				int p=pPlayer->pev->playerclass;
				if(pev->playerclass==TFCCLASS_WHITE && p!=LIFE_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_RED && p!=FIRE_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_BLUE && p!=ICE_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_GREEN && p!=NATURE_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_YELLOW && p!=LIGHTNING_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_BLACK && p!=DEATH_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_BROWN && p!=EARTH_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_PURPLE && p!=WIND_CLASS)
					canGoGoal=FALSE;
				else if(pev->playerclass==TFCCLASS_ORANGE && p!=DRAGONWIZARD_CLASS)
					canGoGoal=FALSE;
			}
			else
				canGoState=FALSE;
		}
		else if(pev->playerclass!=0)
			canGoState=FALSE;

		if(m_iItemNeeded!=0 && pActivator->IsPlayer()){
			CBasePlayer *pPlayer=(CBasePlayer*)pActivator;

			CTFCGoal* item=pPlayer->m_pAttachedItem;

			if(item==NULL)
				canGoGoal=FALSE;
			else if(item->m_iGoalNo!=m_iItemNeeded)
				canGoGoal=FALSE;
		}
 		else if(m_iItemNeeded!=0 && !pActivator->IsPlayer()){
			canGoState=FALSE;
		}
	}

	if(m_iGoalIsActive!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iGoalIsActive);
		if(temp){
//			ALERT(at_console,"%d is at %d, should be 1\n",m_iGoalIsActive,temp->m_iGoalState);
			if(temp->m_iGoalState!=TFCGOAL_ACTIVE)
				canGoGoal=FALSE;
		}
	}
	if(m_iGoalIsInactive!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iGoalIsInactive);
		if(temp){
//			ALERT(at_console,"%d is at %d, should be 2\n",m_iGoalIsInactive,temp->m_iGoalState);
			if(temp->m_iGoalState!=TFCGOAL_INACTIVE)
				canGoGoal=FALSE;
		}
	}
	if(m_iGoalIsRemoved!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iGoalIsRemoved);
		if(temp){
//			ALERT(at_console,"%d is at %d, should be 2\n",m_iGoalIsRemoved,temp->m_iGoalState);
			if(temp->m_iGoalState!=TFCGOAL_REMOVED)
				canGoGoal=FALSE;
		}
	}	
	if(m_iHasAnyItemFromGroup!=0 && pActivator && pActivator->IsPlayer()){
		CBasePlayer *plr=(CBasePlayer*)pActivator;	
		if(plr->m_pAttachedItem==NULL || plr->m_pAttachedItem->m_iGroupNo!=m_iHasAnyItemFromGroup){
			canGoGoal=FALSE;
		}
	}
	if(m_iHasntAnyItemFromGroup!=0 && pActivator && pActivator->IsPlayer()){
		CBasePlayer *plr=(CBasePlayer*)pActivator;	
		if(plr->m_pAttachedItem!=NULL && plr->m_pAttachedItem->m_iGroupNo==m_iHasntAnyItemFromGroup){
			canGoGoal=FALSE;
		}
	}
	if(m_iGroupIsActive!=0 && CheckGroupStatus(m_iGroupIsActive,1)==FALSE)
		canGoGoal=FALSE;
	if(m_iGroupIsInactive!=0 && CheckGroupStatus(m_iGroupIsInactive,2)==FALSE)
		canGoGoal=FALSE;
	if(m_iGroupIsRemoved!=0 && CheckGroupStatus(m_iGroupIsRemoved,3)==FALSE)
		canGoGoal=FALSE;

	if (sMaster){
		edict_t *pentTarget = FIND_ENTITY_BY_TARGETNAME(NULL, STRING(sMaster));
	
		if ( !FNullEnt(pentTarget) ){
			CBaseEntity *pMaster = CBaseEntity::Instance(pentTarget);
			if ( pMaster && (pMaster->ObjectCaps() & FCAP_MASTER) )
				return pMaster->IsTriggered( pActivator );
		}
//		ALERT(at_console, "Master was null or not a master!\n");
	}

	if(FClassnameIs(pev,"item_tfgoal") && m_iGoalActivation&TFCITEM_ACTIVATION_REVERSE_AP)
		canGoGoal=!canGoGoal;
	if(!FClassnameIs(pev,"item_tfgoal") && m_iGoalActivation&TFCGOAL_ACTIVATION_REVERSE_AP)
		canGoGoal=!canGoGoal;

	//HACK:for library
	if(FStrEq(STRING(gpGlobals->mapname),"ww_library") && FStrEq(STRING(pev->targetname),"blue_on"))
		canGoGoal=TRUE;
	if(FStrEq(STRING(gpGlobals->mapname),"ww_library") && FStrEq(STRING(pev->targetname),"red_on"))
		canGoGoal=TRUE;

	if(!canGoState || !canGoGoal){
		if(!canGoGoal){
			CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iElseGoal);
			if(temp && pActivator!=NULL){
				temp->Use(pActivator,this,USE_TOGGLE,0);
			}
		}

		return 0;
	}
	else{
		return 1;
	}
}

extern int g_iTeamScore[5];
extern int gmsgTeamScore;

void CBaseToggle::DelayActivation(){
	CBaseEntity *pEnt=NULL;

	if(pev->euser1)
		pEnt=Instance(pev->euser1);

	SUB_UseTargets(pEnt,USE_TOGGLE,1);

	SetThink(NULL);
}

//WIZWARS:TFC
void CBaseToggle::SUB_UseTargets( CBaseEntity *pActivator, USE_TYPE useType, float value ){
	if(m_flDelayTime>0 && m_iGoalState!=TFCGOAL_WAITING){
		m_iGoalState=TFCGOAL_WAITING;
		if(pActivator)
			pev->euser1=pActivator->edict();
		SetThink(DelayActivation);
		pev->nextthink=gpGlobals->time+m_flDelayTime;
		return;
	}

//	ALERT(at_console,"GoalNo:%d\n",m_iGoalNo);
	if(m_iGoalState!=TFCGOAL_REMOVED && !FClassnameIs(pev,"item_tfgoal"))
		ActivateGoal();

	BOOL broadcast=TRUE;
	if(pActivator && pActivator->IsPlayer()){
		if(!FStringNull(m_szOwnersTeamBroadcast)){
			//ALERT(at_console,"owteam:%s\n",STRING(m_szOwnersTeamBroadcast));
			UTIL_CenterPrintTeam(m_iOwningTeam,STRING(m_szOwnersTeamBroadcast),STRING(pActivator->pev->netname));
			broadcast=FALSE;
		}
		if(!FStringNull(m_szNonOwnersTeamBroadcast)){
			//ALERT(at_console,"nonowteam:%s\n",STRING(m_szNonOwnersTeamBroadcast));
			UTIL_CenterPrintNotTeam(m_iOwningTeam,STRING(m_szNonOwnersTeamBroadcast),STRING(pActivator->pev->netname));
			broadcast=FALSE;
		}
		if(!FStringNull(m_szTeamBroadcast)){
			//ALERT(at_console,"team:%s\n",STRING(m_szTeamBroadcast));
			UTIL_CenterPrintTeam(pev->team,STRING(m_szTeamBroadcast),STRING(pActivator->pev->netname));
			broadcast=FALSE;
		}
		if(!FStringNull(m_szNonTeamBroadcast)){
			//ALERT(at_console,"nonteam:%s\n",STRING(m_szNonTeamBroadcast));
			UTIL_CenterPrintNotTeam(pev->team,STRING(m_szNonTeamBroadcast),STRING(pActivator->pev->netname));
			broadcast=FALSE;
		}
		if(!FStringNull(m_szAPSpeak)){
			edict_t *pClient;
			pClient=pActivator->edict();
			CLIENT_COMMAND(pClient,(char*)STRING(m_szAPSpeak));
		}
	}
	if(!FStringNull(m_szBroadcast) && broadcast){
		//ALERT(at_console,"broadcast:%s\n",STRING(m_szBroadcast));
		UTIL_CenterPrintAll(STRING(m_szBroadcast));
	}
	if(!FStringNull(m_szTeamSpeak)){
		for(int i=1;i<=gpGlobals->maxClients;i++){
			CBaseEntity *plr=UTIL_PlayerByIndex(i);
			if(plr && plr->pev->team==pev->team){
				edict_t *pClient;
				pClient=plr->edict();
				CLIENT_COMMAND(pClient,(char*)STRING(m_szTeamSpeak));
			}
		}

//		ALERT(at_console,"%s\n",STRING(m_szTeamSpeak));
	}
	if(!FStringNull(m_szNonTeamSpeak)){
		for(int i=1;i<=gpGlobals->maxClients;i++){
			CBaseEntity *plr=UTIL_PlayerByIndex(i);
			if(plr && plr->pev->team!=pev->team){
				edict_t *pClient;
				pClient=plr->edict();
				CLIENT_COMMAND(pClient,(char*)STRING(m_szNonTeamSpeak));
			}
		}

//		ALERT(at_console,"%s\n",STRING(m_szNonTeamSpeak));
	}

	//HACK:For Library
	if(FStrEq(STRING(gpGlobals->mapname),"ww_library") && FStrEq(STRING(pev->targetname),"blue_on"))
		UTIL_CenterPrintAll("The Blue Team has the Tome!");
	if(FStrEq(STRING(gpGlobals->mapname),"ww_library") && FStrEq(STRING(pev->targetname),"red_on"))
		UTIL_CenterPrintAll("The Red Team has the Tome!");

	bool scoreChanged=FALSE;

	for(int x=1;x<=4;x++){
		if(m_iTeamPoints[x]!=0){
			g_iTeamScore[x]+=m_iTeamPoints[x];
			scoreChanged=TRUE;
		}
	}

	if(scoreChanged){
		for(int x=1;x<=4;x++){
			MESSAGE_BEGIN( MSG_ALL, gmsgTeamScore, NULL);
				if(x==1)
					WRITE_STRING("blue");
				else if(x==2)
					WRITE_STRING("red");
				else if(x==3)
					WRITE_STRING("yellow");
				else
					WRITE_STRING("green");
	
				WRITE_SHORT(g_iTeamScore[x]);
				WRITE_SHORT(0);
			MESSAGE_END();
		}
	}

	DoGoalWork(pActivator);
	
	DoGroupWork(pActivator);

	if(m_iGoalEffects>1){
		for ( int i = 1; i <= gpGlobals->maxClients; i++ ){
			CBaseEntity *plr = UTIL_PlayerByIndex( i );
//			ALERT(at_console,"TargetName:%s on %i\n",STRING(pev->targetname),i);

			if( plr && plr->IsPlayer() && IsAffected((CBasePlayer*)plr,pActivator)){
				AffectPlayer((CBasePlayer*)plr);
			}
		}
	}
	else if(pActivator && pActivator->IsPlayer())
		AffectPlayer((CBasePlayer*)pActivator);

	if(m_iGoalResult&TFCGOAL_RESULT_DESTROYPLANTS){
		CBaseEntity *pEnt=NULL;
		
		while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"monster_thornbush"))!=NULL)
			pEnt->TakeDamage(VARS(ENT(0)),VARS(ENT(0)),1000,DMG_CRUSH);

		pEnt=NULL;

		while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"beanstalk"))!=NULL)
			pEnt->TakeDamage(VARS(ENT(0)),VARS(ENT(0)),1000,DMG_CRUSH);
	}

	if(m_iGoalResult&TFCGOAL_RESULT_ENDGAME){
		g_pGameRules->EndMultiplayerGame();
	}

	if(FClassnameIs(pev,"info_tfgoal"))
		((CTFCGoal*)this)->SetupRespawn();

	CBaseDelay::SUB_UseTargets(pActivator,useType,value);
}

void CTFCGoal::SetupRespawn(){
	if(m_iGoalResult&TFCGOAL_RESULT_SINGLE){
		RemoveGoal();
	}

	if(m_flSearchTime!=0){
		InactivateGoal();
		SetThink(((CTFCTimer*)this)->TimerThink);
		pev->nextthink=gpGlobals->time+m_flSearchTime;
		return;
	}

	if(m_flWait>0){
		RemoveGoal();
		ActivateGoal();
		pev->nextthink=gpGlobals->time+m_flWait;
		SetThink(DoRespawn);
		return;
	}
	else if (m_flWait==-1)
		return;

	InactivateGoal();
}

extern void respawn(entvars_t *pev, BOOL fCopyCorpse);
void CBaseToggle::AffectPlayer(CBasePlayer *pPlayer){
	if(pPlayer==NULL || pPlayer->m_pClass==NULL || pPlayer->IsObserver() || !pPlayer->IsAlive())
		return;

	if(pev->message){
		ClientPrint(pPlayer->pev,HUD_PRINTCENTER,STRING(pev->message));
	}

	pPlayer->AddPoints(pev->frags,TRUE);
	pPlayer->GiveAmmo(m_iCells,"uranium",URANIUM_MAX_CARRY);

	if(pev->health>0 && strcmp(STRING(pev->classname),"func_button")!=0 && strcmp(STRING(pev->classname),"func_door")!=0)
		pPlayer->TakeHealth(pev->health,DMG_GENERIC);
	else if(pev->health<0){
		pPlayer->TakeDamage(VARS(ENTINDEX(0)),pPlayer->pev,-(pev->health),DMG_GENERIC);
	}

	if(!FStringNull(pev->noise))
		EMIT_SOUND(ENT(pPlayer->pev),CHAN_ITEM,STRING(pev->noise),1,ATTN_NORM);

	if(m_iGoalResult&TFCGOAL_RESULT_RESETSPY &&
		pPlayer->m_pClass &&
		pPlayer->pev->playerclass==ICE_CLASS){
		((CIceWizard*)pPlayer->m_pClass)->ResetDisguise();
	}

	if(m_iGoalResult&TFCGOAL_RESULT_RESPAWN){
		pPlayer->PackDeadPlayerItems();
		respawn(pPlayer->pev,FALSE);
	}

	if(m_iArmor>0)
		pPlayer->pev->armorvalue+=m_iArmor;
	if(pPlayer->pev->armorvalue>pPlayer->pev->armortype)
		pPlayer->pev->armorvalue=pPlayer->pev->armortype;

	if(m_iGrenades>=0)
		pPlayer->GiveAmmo(m_iGrenades,"ARgrenades",4);

	if(m_flInvincibleTime>0)
		pPlayer->m_flInvincibleTime=gpGlobals->time+m_flInvincibleTime;

	if(m_flSuperDamageTime>0)
		pPlayer->m_flSuperDamageTime=gpGlobals->time+m_flSuperDamageTime;

	if(m_iItems!=0){
		CTFCItem *temp=(CTFCItem*)FindEntityByGoal(m_iItems);

		if(temp){
			temp->AttachToPlayer(pPlayer);
		}
	}

	//WIZWARS:HACK:for ww_roc2 map
	if(FStrEq("gaswarnb",STRING(pev->targetname))){
		pPlayer->TakeDamage(VARS(ENTINDEX(0)),pPlayer->pev,9999,DMG_GENERIC);
	}

	if(m_iItemToRemove!=0){
		CTFCItem* item=pPlayer->m_pAttachedItem;

		if(item!=NULL && item->m_iGoalNo==m_iItemToRemove){
			item->DropFromPlayer(1);

			UTIL_CenterPrintTeam(pev->team,STRING(m_szNonTeamItemCaptured),STRING(pPlayer->pev->netname));
			UTIL_CenterPrintNotTeam(pev->team,STRING(m_szTeamItemCaptured),STRING(pPlayer->pev->netname));
		}
	}

	if(m_iRemoveAnyItemFromGroup!=0){
		if(pPlayer->m_pAttachedItem && pPlayer->m_pAttachedItem->m_iGroupNo==m_iRemoveAnyItemFromGroup){
			CTFCItem *ent=pPlayer->m_pAttachedItem;
			ent->DropFromPlayer(1);
		}
	}
}

int CBaseToggle::IsAffected(CBasePlayer *plr,CBaseEntity *pActivator){
	if(plr->m_pClass==NULL)
		return FALSE;

	if(m_iGoalEffects&TFCGOAL_EFFECT_SAME_ENVIRONMENT && plr->pev->waterlevel!=pev->waterlevel)
		return FALSE;

	if(m_flGoalRadius!=0){
		if((pev->origin-plr->pev->origin).Length()>=m_flGoalRadius){
			return FALSE;
		}
	}

	if(m_iGoalEffects&TFCGOAL_EFFECT_AP && plr==pActivator)
		return TRUE;

	if(m_iGoalEffects&TFCGOAL_EFFECT_AP_TEAM && pActivator && plr->pev->team==pActivator->pev->team)
		return TRUE;

	if(m_iGoalEffects&TFCGOAL_EFFECT_NOT_AP_TEAM && pActivator && plr->pev->team!=pActivator->pev->team)
		return TRUE;

	if(m_iGoalEffects&TFCGOAL_EFFECT_NOT_AP && pActivator && plr!=pActivator)
		return TRUE;

	if(m_iAffectAPTeam && pActivator && plr->pev->team==pActivator->pev->team)
		return TRUE;

	if(m_iAffectNotAPTeam && pActivator && plr->pev->team!=pActivator->pev->team)
		return TRUE;

	return FALSE;
}

void CBaseToggle::DoGoalWork(CBaseEntity *pActivator){
	if(m_iActivateGoal!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iActivateGoal);
		if(temp){
//			ALERT(at_console,"Activating Goal %d\n",m_iActivateGoal);
			temp->ActivateGoal();
			temp->Use(pActivator,this,USE_TOGGLE,0);
		}
	}
	if(m_iInactivateGoal!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iInactivateGoal);
		if(temp){
//			ALERT(at_console,"Inactivating Goal %\n",m_iInactivateGoal);
			if(temp->m_iGoalState!=TFCGOAL_REMOVED)
				temp->InactivateGoal();
		}
	}
	if(m_iRemoveGoal!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iRemoveGoal);
		if(temp){
//			ALERT(at_console,"Removing Goal %d\n",m_iRemoveGoal);
			temp->RemoveGoal();
		}
	}
	if(m_iRestoreGoal!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iRestoreGoal);
		if(temp){
//			ALERT(at_console,"Restoring Goal %d\n",m_iRestoreGoal);
			temp->RestoreGoal();
		}
	}
	if(m_iItemToReturn!=0){
		CTFCItem *temp=(CTFCItem*)FindEntityByGoal(m_iItemToReturn);
		if(temp){
//			ALERT(at_console,"Returning Item %d\n",m_iItemToReturn);
			if(m_iGoalState==TFCGOAL_ACTIVE)
				temp->DropFromPlayer(1);
			
			temp->ReturnItem();
		}
	}
	if(m_iRemoveSpawnpoint!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iRemoveSpawnpoint);
		if(temp){
			temp->m_iGoalState=TFCGOAL_REMOVED;
		}
	}
	if(m_iRestoreSpawnpoint!=0){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(m_iRestoreSpawnpoint);
		if(temp){
			temp->InactivateGoal();
		}
	}
}

void CBaseToggle::DoGroupWork(CBaseEntity *pActivator){
	if(m_iRestoreGroupNo!=0){
		CBaseEntity *pStart,*pEnt;

		pStart=UTIL_FindEntityByClassname(NULL,"info_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iRestoreGroupNo){
				((CTFCGoal*)pEnt)->RestoreGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"info_tfgoal");
		}while(pStart!=pEnt);

		pStart=UTIL_FindEntityByClassname(NULL,"item_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iRestoreGroupNo){
				((CTFCGoal*)pEnt)->RestoreGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"item_tfgoal");
		}while(pStart!=pEnt);
	}
	if(m_iActivateGroupNo!=0){
		CBaseEntity *pStart,*pEnt;

		pStart=UTIL_FindEntityByClassname(NULL,"info_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iActivateGroupNo){
				((CTFCGoal*)pEnt)->ActivateGoal();
					pEnt->Use(pActivator,this,USE_TOGGLE,0);
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"info_tfgoal");
		}while(pStart!=pEnt);

		pStart=UTIL_FindEntityByClassname(NULL,"item_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iActivateGroupNo){
				((CTFCGoal*)pEnt)->ActivateGoal();
					pEnt->Use(pActivator,this,USE_TOGGLE,0);
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"item_tfgoal");
		}while(pStart!=pEnt);
	}
	if(m_iInactivateGroupNo!=0){
		CBaseEntity *pStart,*pEnt;

		pStart=UTIL_FindEntityByClassname(NULL,"info_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iInactivateGroupNo){
				if(((CTFCGoal*)pEnt)->m_iGoalState!=TFCGOAL_REMOVED)
					((CTFCGoal*)pEnt)->InactivateGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"info_tfgoal");
		}while(pStart!=pEnt);

		pStart=UTIL_FindEntityByClassname(NULL,"item_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iInactivateGroupNo){
				if(((CTFCGoal*)pEnt)->m_iGoalState!=TFCGOAL_REMOVED)
					((CTFCGoal*)pEnt)->InactivateGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"item_tfgoal");
		}while(pStart!=pEnt);
	}
	if(m_iRemoveGroupNo!=0){
		CBaseEntity *pStart,*pEnt;

		pStart=UTIL_FindEntityByClassname(NULL,"info_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iRemoveGroupNo){
				if(((CTFCGoal*)pEnt)->m_iGoalState!=TFCGOAL_REMOVED)
					((CTFCGoal*)pEnt)->RemoveGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"info_tfgoal");
		}while(pStart!=pEnt);

		pStart=UTIL_FindEntityByClassname(NULL,"item_tfgoal");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iRemoveGroupNo){
				if(((CTFCGoal*)pEnt)->m_iGoalState!=TFCGOAL_REMOVED)
					((CTFCGoal*)pEnt)->RemoveGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"item_tfgoal");
		}while(pStart!=pEnt);
	}
	if(m_iRemoveSpawngroup){
		CBaseEntity *pStart,*pEnt;

//		ALERT(at_console,"Removing spawngroup %d\n",m_iRemoveSpawngroup);

		pStart=UTIL_FindEntityByClassname(NULL,"info_player_teamspawn");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iRemoveSpawngroup){
				((CBaseToggle*)pEnt)->RemoveGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"info_player_teamspawn");
		}while(pStart!=pEnt);
	}
	if(m_iRestoreSpawngroup){
		CBaseEntity *pStart,*pEnt;

//		ALERT(at_console,"Restoring spawngroup %d\n",m_iRestoreSpawngroup);

		pStart=UTIL_FindEntityByClassname(NULL,"info_player_teamspawn");
		pEnt=pStart;
		do{
			if(pEnt!=NULL && ((CTFCGoal*)pEnt)->m_iGroupNo==m_iRestoreSpawngroup){
				((CBaseToggle*)pEnt)->RestoreGoal();
			}
			
			pEnt=UTIL_FindEntityByClassname(pEnt,"info_player_teamspawn");
		}while(pStart!=pEnt);
	}
}

void CBaseToggle::ActivateGoal(){
	m_iGoalState=TFCGOAL_ACTIVE;
}

void CBaseToggle::InactivateGoal(){
	if(m_iGoalState==TFCGOAL_ACTIVE){
		m_iGoalState=TFCGOAL_INACTIVE;
	}
}

void CBaseToggle::RemoveGoal(){
	m_iGoalState=TFCGOAL_REMOVED;
	pev->solid=SOLID_NOT;

	//ALERT(at_console,"Removing goal:%d\n",m_iGoalNo);

	pev->effects|=EF_NODRAW;
}

void CBaseToggle::RestoreGoal(){
	m_iGoalState=TFCGOAL_INACTIVE;
	pev->solid=SOLID_TRIGGER;

	//ALERT(at_console,"Restoring goal:%d\n",m_iGoalNo);

	if(m_flSearchTime)
		pev->nextthink=gpGlobals->time+m_flSearchTime;
	
	pev->effects&=~EF_NODRAW;
	if(*STRING(pev->model)=='*'){
		if(CVAR_GET_FLOAT("showtriggers")==0)
			SetBits(pev->effects,EF_NODRAW);
	}
}

void CBaseToggle::KeyValue(KeyValueData *pkvd){
	if(FStrEq(pkvd->szKeyName,"team_no")){
		pev->team=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"goal_state")){
		m_iGoalState=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"ammo_cells")||
			FStrEq(pkvd->szKeyName,"ammo_shells")||
			FStrEq(pkvd->szKeyName,"ammo_nails")||
			FStrEq(pkvd->szKeyName,"a_c")||
			FStrEq(pkvd->szKeyName,"a_s")||
			FStrEq(pkvd->szKeyName,"a_r")||
			FStrEq(pkvd->szKeyName,"a_n")){
		m_iCells=max(atoi(pkvd->szValue),m_iCells);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"ammo_rockets")){
		m_iArmor=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"no_grenades_1")){
		m_iGrenades=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"pausetime")){
		m_flPauseTime=atof(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"delay_time")){
		m_flDelayTime=atof(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"goal_activation")||
			FStrEq(pkvd->szKeyName,"g_a")){
		m_iGoalActivation=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if (FStrEq(pkvd->szKeyName, "team_no")){
		pev->team=atoi(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else if (FStrEq(pkvd->szKeyName, "owned_by")){
		m_iOwningTeam=atoi(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"goal_no")){
		m_iGoalNo=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"goal_result")){
		m_iGoalResult=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"items_allowed")){
		m_iItemNeeded=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"axhitme")){
		m_iItemToRemove=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"return_item_no")){
		m_iItemToReturn=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"broadcast")||
			FStrEq(pkvd->szKeyName,"n_b")||
			FStrEq(pkvd->szKeyName,"b_b")){
		m_szBroadcast=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"netname_team_broadcast")||
			FStrEq(pkvd->szKeyName,"team_broadcast")){
		m_szTeamBroadcast=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"netname_non_team_broadcast")||
		FStrEq(pkvd->szKeyName,"non_team_broadcast")){
		m_szNonTeamBroadcast=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"netname_owners_team_broadcast")){
		m_szOwnersTeamBroadcast=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"netname_non_owners_team_broadcast")){
		m_szNonOwnersTeamBroadcast=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"team_drop")||
		FStrEq(pkvd->szKeyName,"netname_team_drop")){
		m_szTeamDrop=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"non_team_drop")||
		FStrEq(pkvd->szKeyName,"netname_non_team_drop")){
		m_szNonTeamDrop=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"noise4")){
		m_szNonTeamItemReturned=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"b_o")){
		m_szTeamItemCaptured=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"b_t")){
		m_szNonTeamItemCaptured=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"goal_effects")||
		FStrEq(pkvd->szKeyName,"g_e")){
		if((m_iGoalEffects==0 || m_iGoalEffects==1) && atoi(pkvd->szValue)!=0)
			m_iGoalEffects=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"increase_team1")){
		m_iTeamPoints[1]=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"increase_team2")){
		m_iTeamPoints[2]=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"increase_team3")){
		m_iTeamPoints[3]=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"increase_team4")){
		m_iTeamPoints[4]=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"activate_goal_no")){
		m_iActivateGoal=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"inactivate_goal_no")){
		m_iInactivateGoal=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"remove_goal_no")||
		FStrEq(pkvd->szKeyName,"rv_g")){
		m_iRemoveGoal=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"restore_goal_no")||
		FStrEq(pkvd->szKeyName,"rs_g")){
		m_iRestoreGoal=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"if_goal_is_active")){
		m_iGoalIsActive=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"if_goal_is_inactive")){
		m_iGoalIsInactive=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"if_goal_is_removed")){
		m_iGoalIsRemoved=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"else_goal")){
		m_iElseGoal=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"items")){
		m_iItems=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"team_speak")){
		char temp[128];
		strcpy(temp,"speak \"");
		strcat(temp,pkvd->szValue);
		strcat(temp,"\"\n");
		m_szTeamSpeak=ALLOC_STRING(temp);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"non_team_speak")){
		m_szNonTeamSpeak=ALLOC_STRING(pkvd->szValue);
		char temp[128];
		strcpy(temp,"speak \"");
		strcat(temp,pkvd->szValue);
		strcat(temp,"\"\n");
		m_szNonTeamSpeak=ALLOC_STRING(temp);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"AP_speak")){
		char temp[128];
		strcpy(temp,"speak \"");
		strcat(temp,pkvd->szValue);
		strcat(temp,"\"\n");
		m_szAPSpeak=ALLOC_STRING(temp);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"maxammo_shells")){
		if(atoi(pkvd->szValue))
			m_iAffectAPTeam=TRUE;
		else
			m_iAffectAPTeam=FALSE;
		pkvd->fHandled = TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"maxammo_nails")){
		if(atoi(pkvd->szValue))
			m_iAffectNotAPTeam=TRUE;
		else
			m_iAffectNotAPTeam=FALSE;
		pkvd->fHandled = TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"invincible_finished")){
		m_flInvincibleTime=atof(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"super_damage_finished")){
		m_flSuperDamageTime=atof(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"team_str_home")){
		m_szTeamStrHome=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"team_str_moved")){
		m_szTeamStrMoved=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"team_str_carried")){
		m_szTeamStrCarried=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"non_team_str_home")){
		m_szNonTeamStrHome=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"non_team_str_moved")){
		m_szNonTeamStrMoved=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"non_team_str_carried")||
		FStrEq(pkvd->szKeyName,"n_t_s_c")){
		m_szNonTeamStrCarried=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"group_no")){
		m_iGroupNo=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"all_active")){
		m_iAllActive=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"activate_group_no")||
		FStrEq(pkvd->szKeyName,"a_g_n")){
		m_iActivateGroupNo=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"inactivate_group_no")||
		FStrEq(pkvd->szKeyName,"i_g_n")){
		m_iInactivateGroupNo=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"restore_group_no")||
		FStrEq(pkvd->szKeyName,"rs_gr")){
		m_iRestoreGroupNo=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"remove_group_no")||
		FStrEq(pkvd->szKeyName,"rv_gr")){
		m_iRemoveGroupNo=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"has_item_from_group")||
		FStrEq(pkvd->szKeyName,"h_i_g")){
		m_iHasAnyItemFromGroup=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"hasnt_item_from_group")||
		FStrEq(pkvd->szKeyName,"h_i_g")){
		m_iHasntAnyItemFromGroup=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"remove_item_group")||
		FStrEq(pkvd->szKeyName,"r_i_g")){
		m_iRemoveAnyItemFromGroup=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"t_length")){
		m_flGoalRadius=atof(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"if_group_is_active")){
		m_iGroupIsActive=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"if_group_is_inactive")){
		m_iGroupIsInactive=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"if_group_is_removed")){
		m_iGroupIsRemoved=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"remove_spawngroup")||
		FStrEq(pkvd->szKeyName,"rv_s_h")){
		m_iRemoveSpawngroup=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"restore_spawngroup")||
		FStrEq(pkvd->szKeyName,"rs_s_h")){
		m_iRestoreSpawngroup=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"remove_spawnpoint")){
		m_iRemoveSpawnpoint=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"restore_spawnpoint")){
		m_iRestoreSpawnpoint=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"teamcheck")){
		m_szTeamcheck=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else if(FStrEq(pkvd->szKeyName,"owned_by_teamcheck")){
		m_szOwnedByTeamcheck=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}

	else if (FStrEq(pkvd->szKeyName, "lip"))
	{
		m_flLip = atof(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else if (FStrEq(pkvd->szKeyName, "wait"))
	{
		m_flWait = atof(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else if (FStrEq(pkvd->szKeyName, "master"))
	{
		m_sMaster = ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else if (FStrEq(pkvd->szKeyName, "distance"))
	{
		m_flMoveDistance = atof(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else
		CBaseDelay::KeyValue( pkvd );
}

/* *** CTFCGoal *** */

void CTFCGoal::KeyValue(KeyValueData *pkvd){
	if(FStrEq(pkvd->szKeyName,"mdl")){
		pev->model=ALLOC_STRING(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else CBaseToggle::KeyValue(pkvd);
}

void CTFCGoal :: Precache(){
	if(!FStringNull(pev->model)){
		PRECACHE_MODEL((char*)STRING(pev->model));
	}

	char* szSoundFile = (char*) STRING(pev->noise);

	if ( !FStringNull( pev->noise ) && strlen( szSoundFile ) > 1 ){
		if (*szSoundFile != '!')
			PRECACHE_SOUND(szSoundFile);
	}

	PRECACHE_SOUND("items/itembk2.wav");
}

void CTFCGoal::GenericSpawn(){
	Precache();

	SET_MODEL(edict(),STRING(pev->model));
	if(*STRING(pev->model)=='*'){
		if(CVAR_GET_FLOAT("showtriggers")==0)
			SetBits( pev->effects, EF_NODRAW );
	}
	else{
		UTIL_SetSize(pev,Vector(-16,-16,0),Vector(16,16,32));
	}

	if(m_flPauseTime==0)
		m_flPauseTime=m_flWait;

	if(m_flWait==0)
		m_flWait=m_flPauseTime;

	if(m_iGoalState==0)
		m_iGoalState=TFCGOAL_INACTIVE;

	UTIL_SetOrigin(pev,pev->origin);
}

void CTFCGoal :: Spawn(){
	pev->solid=SOLID_TRIGGER;

	GenericSpawn();

	if(FClassnameIs(pev,"i_t_g"))
		pev->classname=MAKE_STRING("info_tfgoal");

	StartGoal();
}
LINK_ENTITY_TO_CLASS(info_tfgoal,CTFCGoal);
LINK_ENTITY_TO_CLASS(i_t_g,CTFCGoal);

//LINK_ENTITY_TO_CLASS(info_areadef,CTFCGoal);
//LINK_ENTITY_TO_CLASS(func_nobuild,CTFCGoal);
//LINK_ENTITY_TO_CLASS(func_nogrenades,CTFCGoal);

void CTFCGoal::StartGoal(){
	pev->nextthink=gpGlobals->time+.2;

	SetThink(PlaceGoal);

	if(m_iGoalState==TFCGOAL_REMOVED)
		RemoveGoal();
}

void CTFCGoal::PlaceGoal(){
	//WIZWARS:HACK:pev->model?
	if(m_iGoalActivation&TFCGOAL_ACTIVATION_TOUCH && pev->model)
		SetTouch(GoalTouch);

	pev->classname=MAKE_STRING("info_tfgoal");

	pev->movetype=MOVETYPE_NONE;
	pev->velocity=Vector(0,0,0);
	pev->oldorigin=pev->origin;

	SetThink(NULL);
}

void CTFCGoal::GoalTouch(CBaseEntity* pEnt){
	if(!FClassnameIs(pEnt->pev,"player"))
		return;

	if(!UTIL_IsMasterTriggered(m_sMaster,pEnt))
		return;

	Use(pEnt,this,USE_TOGGLE,0);
}

void CTFCGoal::DoRespawn(){
	RestoreGoal();
	InactivateGoal();
}

void CTFCGoal::Use(CBaseEntity *pActivate,CBaseEntity *pCaller,USE_TYPE useType,float value){
	//ALERT(at_console,"Using: %s\n",STRING(pev->targetname));

	if(UTIL_IsMasterTriggered(m_sMaster,pActivate))
		SUB_UseTargets(pActivate,USE_TOGGLE,0);
}

/* *** CTFCItem *** */

void CTFCItem::Spawn(){
	pev->solid=SOLID_TRIGGER;

	GenericSpawn();

	if(m_flPauseTime==0)
		m_flPauseTime=60;

	StartItem();
}
LINK_ENTITY_TO_CLASS(item_tfgoal,CTFCItem);

void CTFCItem::StartItem(){
	pev->nextthink=gpGlobals->time+.2;

	SetThink(PlaceItem);
	SetTouch(ItemTouch);

	if(m_iGoalState==TFCGOAL_REMOVED)
		RemoveGoal();
}

void CTFCItem::PlaceItem(){
	pev->movetype=MOVETYPE_NONE;
	
	pev->velocity=Vector(0,0,0);
	pev->oldorigin=pev->origin;

	SetTouch(ItemTouch);

	if(m_iGoalActivation&TFCGOAL_RESULT_ITEMGLOWS || m_iGoalActivation&TFCITEM_ACTIVATION_CANCARRY){
		switch(m_iOwningTeam){
			case(1):{
				pev->rendercolor.z=255;
				break;
			}
			case(2):{
				pev->rendercolor.x=255;
				break;
			}
			case(3):{
				pev->rendercolor.x=128;
				pev->rendercolor.y=255;
			}
			default:
				pev->rendercolor.y=255;
		}
		
		pev->renderfx=kRenderFxGlowShell;
	}

	if(m_flDelayTime!=0 && m_flPauseTime==0)
		m_flPauseTime=m_flDelayTime;
}

EXPORT void CTFCItem::ItemTouch(CBaseEntity *pOther){
	if(!FClassnameIs(pOther->pev,"player"))
		return;

	if(pOther->pev->health<=0)
		return;
	
	if(!UTIL_IsMasterTriggered(m_sMaster,pOther))
		return;

	AttachToPlayer((CBasePlayer*)pOther);
	m_iGoalState=TFCGOAL_ACTIVE;
}

extern int gmsgStatusIcon;
void CTFCItem::AttachToPlayer ( CBasePlayer *pPlayer ){
		if(m_iItems&TFCGOAL_HUD_YELLOW){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_yellow");
			WRITE_BYTE(255);
			WRITE_BYTE(255);
			WRITE_BYTE(0);
		MESSAGE_END();
		}
	if(m_iItems&TFCGOAL_HUD_GREEN){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_green");
			WRITE_BYTE(0);
			WRITE_BYTE(255);
			WRITE_BYTE(0);
		MESSAGE_END();
		}
	if(m_iItems&TFCGOAL_HUD_BLUE){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_blue");
			WRITE_BYTE(255);
			WRITE_BYTE(0);
			WRITE_BYTE(255);
		MESSAGE_END();
	}
	if(m_iItems&TFCGOAL_HUD_RED){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_red");
			WRITE_BYTE(255);
			WRITE_BYTE(0);
			WRITE_BYTE(0);
		MESSAGE_END();
	}
	if(m_iItems&TFCGOAL_HUD_INVIS){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_invis");
			WRITE_BYTE(255);
			WRITE_BYTE(255);
			WRITE_BYTE(255);
		MESSAGE_END();
	}
	if(m_iItems&TFCGOAL_HUD_INVUN){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_invun");
			WRITE_BYTE(255);
			WRITE_BYTE(255);
			WRITE_BYTE(255);
		MESSAGE_END();
	}
	if(m_iItems&TFCGOAL_HUD_SUIT){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_suit");
			WRITE_BYTE(255);
			WRITE_BYTE(255);
			WRITE_BYTE(255);
		MESSAGE_END();
	}
	if(m_iItems&TFCGOAL_HUD_QUAD){
		MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
			WRITE_BYTE(TRUE);
			WRITE_STRING("item_quad");
			WRITE_BYTE(255);
			WRITE_BYTE(255);
			WRITE_BYTE(255);
		MESSAGE_END();
	}

	if(m_iGoalActivation&TFCITEM_ACTIVATION_SLOW)
		g_engfuncs.pfnSetClientMaxspeed(pPlayer->edict(),pPlayer->m_pClass->PlayerSpeed()/2);

	if (FStrEq(STRING(pev->model), "models/keycard.mdl")){
		pev->sequence=CARRIED;
		ResetSequenceInfo();
		SetThink(SpinThink);
	}
	else{
		pev->sequence=2;
	}

	pev->movetype = MOVETYPE_FOLLOW;
	pev->aiment = pPlayer->edict();
	pev->owner = pPlayer->edict();
	pPlayer->m_pAttachedItem=this;

	SetTouch( NULL );

	SUB_UseTargets(pPlayer,USE_TOGGLE,0);
	//HACK:ItemGroupWork?
}

void CTFCItem::SpinThink(void){
	StudioFrameAdvance();
}

void CTFCItem::DropFromPlayer(int method){
	int m_szOwnerName;

	//HACK:For ww_castle
	if(FStrEq(STRING(gpGlobals->mapname),"ww_castle") && m_iGoalNo==1)
		m_iGoalActivation=12;

	if (FStrEq(STRING(pev->model), "models/keycard.mdl")){
		pev->sequence=NOT_CARRIED;
		ResetSequenceInfo();
		}
	else{
		pev->sequence=0;
		}

	if(pev->owner!=NULL){
		CBasePlayer* pPlayer=(CBasePlayer*)Instance(pev->owner);
		if(pPlayer){
			if(m_iItems&TFCGOAL_HUD_BLUE){
				MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
					WRITE_BYTE(FALSE);
					WRITE_STRING("item_blue");
					WRITE_BYTE(255);
					WRITE_BYTE(0);
					WRITE_BYTE(255);
				MESSAGE_END();
			}
			if(m_iItems&TFCGOAL_HUD_RED){
				MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
					WRITE_BYTE(FALSE);
					WRITE_STRING("item_red");
					WRITE_BYTE(255);
					WRITE_BYTE(0);
					WRITE_BYTE(0);
				MESSAGE_END();
			}
			if(m_iItems&TFCGOAL_HUD_INVIS){
				MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
					WRITE_BYTE(FALSE);
					WRITE_STRING("item_invis");
					WRITE_BYTE(255);
					WRITE_BYTE(255);
					WRITE_BYTE(255);
				MESSAGE_END();
			}
			if(m_iItems&TFCGOAL_HUD_INVUN){
				MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
					WRITE_BYTE(FALSE);
					WRITE_STRING("item_invun");
					WRITE_BYTE(255);
					WRITE_BYTE(255);
					WRITE_BYTE(255);
				MESSAGE_END();
			}
			if(m_iItems&TFCGOAL_HUD_SUIT){
				MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
					WRITE_BYTE(FALSE);
					WRITE_STRING("item_suit");
					WRITE_BYTE(255);
					WRITE_BYTE(255);
					WRITE_BYTE(255);
				MESSAGE_END();
			}
			if(m_iItems&TFCGOAL_HUD_QUAD){
				MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,pPlayer->pev);
					WRITE_BYTE(FALSE);
					WRITE_STRING("item_quad");
					WRITE_BYTE(255);
					WRITE_BYTE(255);
					WRITE_BYTE(255);
				MESSAGE_END();
			}
			
			pPlayer->m_pAttachedItem=NULL;

			UTIL_MakeVectors( pPlayer->pev->v_angle );
			pev->velocity=pPlayer->pev->velocity + gpGlobals->v_forward * 400 + gpGlobals->v_up*50;

			UTIL_CenterPrintTeam(pev->team,STRING(m_szNonTeamDrop),STRING(pPlayer->pev->netname));
			UTIL_CenterPrintNotTeam(pev->team,STRING(m_szTeamDrop),STRING(pPlayer->pev->netname));

			if(m_iGoalActivation&TFCITEM_ACTIVATION_SLOW)
				g_engfuncs.pfnSetClientMaxspeed(pPlayer->edict(),pPlayer->m_pClass->PlayerSpeed());

			m_szOwnerName=pPlayer->pev->netname;
		}
	}

	pev->owner=NULL;
	pev->aiment=NULL;
	pev->movetype=MOVETYPE_NONE;
	pev->angles.x=0;

	if(method==0){
		if(m_szOwnerName){
			UTIL_CenterPrintTeam(m_iOwningTeam,STRING(m_szTeamDrop),STRING(m_szOwnerName));
			UTIL_CenterPrintNotTeam(m_iOwningTeam,STRING(m_szNonTeamDrop),STRING(m_szOwnerName));
		}
		else{
			UTIL_CenterPrintTeam(m_iOwningTeam,STRING(m_szTeamDrop));
			UTIL_CenterPrintNotTeam(m_iOwningTeam,STRING(m_szNonTeamDrop));
		}

		if(m_iGoalActivation&TFCITEM_ACTIVATION_RETURN_DROP){
			SetThink(ReturnItem);
			pev->nextthink=gpGlobals->time+0.5;
			return;
		}
		else if(m_iGoalActivation&TFCITEM_ACTIVATION_DROP){
			DropItem();
			return;
		}
		else{
			RemoveGoal();
			return;
		}
	}
	if(method==1){
		if(m_iGoalActivation&TFCITEM_ACTIVATION_RETURN_GOAL){
			SetThink(ReturnItem);
			pev->nextthink=gpGlobals->time+0.5;
			return;
		}
		else{
			RemoveGoal();
			return;
		}
	}
}

void CTFCItem::DropItem(){
	m_iGoalState=TFCGOAL_INACTIVE;
	pev->movetype=MOVETYPE_TOSS;
	pev->gravity=1;
	UTIL_SetOrigin(pev,pev->origin);
	pev->velocity.z=-10;

	SetTouch(NULL);
	SetThink(DropThink);
	pev->nextthink=gpGlobals->time+1;
}

void CTFCItem::DropThink(){
	SetTouch(ItemTouch);

	if(m_flPauseTime!=0){
		pev->nextthink=gpGlobals->time+m_flPauseTime;

		SetThink(RemoveItem);
	}
}

void CTFCItem::RemoveItem(){
	if(m_iGoalState==TFCGOAL_ACTIVE)
		return;

	if(m_iGoalActivation&TFCITEM_ACTIVATION_RETURN_REMOVE){
		UTIL_SetOrigin(pev,pev->oldorigin);

		CheckGoalReturn();

		if(pev->noise3!=0 || m_szNonTeamItemReturned!=0){
			UTIL_CenterPrintTeam(m_iOwningTeam,STRING(pev->noise3));
			UTIL_CenterPrintNotTeam(m_iOwningTeam,STRING(m_szNonTeamItemReturned));
		}
	}
}

void CTFCItem::CheckGoalReturn(){
	if(pev->impulse){
		CBaseToggle *temp=(CBaseToggle*)FindEntityByGoal(pev->impulse);
		if(temp){
			temp->Use(this,this,USE_TOGGLE,0);
		}
	}
}

void CTFCItem::ReturnItem(){
	RestoreGoal();
	
	pev->movetype=MOVETYPE_NONE;
	SetTouch(ItemTouch);
	UTIL_SetOrigin(pev,pev->oldorigin);

	EMIT_SOUND(edict(),CHAN_VOICE,"items/itembk2.wav",1.0,ATTN_NORM);

	CheckGoalReturn();
}

void CTFCItem::Use(CBaseEntity *pActivate,CBaseEntity *pCaller,USE_TYPE useType,float value){
	CTFCGoal::Use(pActivate,pCaller,useType,value);
}

/* *** CTFCTimer *** */

void CTFCTimer::Spawn(){
	pev->solid=SOLID_NOT;

	GenericSpawn();

	if(FClassnameIs(pev,"i_t_t"))
		pev->classname=MAKE_STRING("info_tfgoal_timer");

	StartTimer();
}
LINK_ENTITY_TO_CLASS(info_tfgoal_timer,CTFCTimer);
LINK_ENTITY_TO_CLASS(i_t_t,CTFCTimer);

void CTFCTimer::KeyValue(KeyValueData *pkvd){
	if(FStrEq(pkvd->szKeyName,"search_time")){
		m_flSearchTime=atof(pkvd->szValue);
		pkvd->fHandled = TRUE;
	}
	else CTFCGoal::KeyValue(pkvd);
}

void CTFCTimer::StartTimer(){
	pev->nextthink=gpGlobals->time+.2;

	SetThink(PlaceTimer);

	if(m_iGoalState==TFCGOAL_REMOVED)
		RemoveGoal();
}

void CTFCTimer::PlaceTimer(){
	SetThink(TimerThink);
	pev->nextthink=gpGlobals->time+m_flSearchTime;

	pev->classname=MAKE_STRING("info_tfgoal");

	pev->movetype=MOVETYPE_NONE;
	pev->velocity=Vector(0,0,0);
	pev->oldorigin=pev->origin;
}

void CTFCTimer::TimerThink(){
	if(m_iGoalState!=TFCGOAL_REMOVED){
		Use(this,this,USE_TOGGLE,0);

		InactivateGoal();
		SetThink(TimerThink);
		pev->nextthink=gpGlobals->time+m_flSearchTime;
	}
}

void CTFCTimer::Use(CBaseEntity *pActivate,CBaseEntity *pCaller,USE_TYPE useType,float value){
	if(UTIL_IsMasterTriggered(m_sMaster,pActivate)){
		SUB_UseTargets(pActivate,USE_TOGGLE,0);
	}
}

/* *** CTFCTeamcheck *** */

void CTFCTeamcheck::Spawn(){
	CPointEntity::Spawn();
	
	SetThink(ModifyTeamchecks);
	pev->nextthink=gpGlobals->time+0.2;
}
LINK_ENTITY_TO_CLASS(info_tf_teamcheck,CTFCTeamcheck);

void CTFCTeamcheck::KeyValue(KeyValueData *pkvd){
	if(FStrEq(pkvd->szKeyName,"team_no")){
		pev->team=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else
		CPointEntity::KeyValue(pkvd);
}

void CTFCTeamcheck::ModifyTeamchecks(){
	CBaseToggle *pEnt=NULL;

	while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"info_player_teamspawn"))!=NULL){
		if(pEnt->m_szTeamcheck && FStrEq(STRING(pEnt->m_szTeamcheck),STRING(pev->targetname))){
			pEnt->pev->team=pev->team;
			SetBits(g_iTeams,pev->team);
		}
		if(pEnt->m_szOwnedByTeamcheck && FStrEq(STRING(pEnt->m_szOwnedByTeamcheck),STRING(pev->targetname))){
			pEnt->m_iOwningTeam=pev->team;
		}
	}

	pEnt=NULL;

	while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"monster_turret"))!=NULL){
		if(pEnt->m_szTeamcheck && FStrEq(STRING(pEnt->m_szTeamcheck),STRING(pev->targetname))){
			pEnt->pev->team=pev->team;
		}
		if(pEnt->m_szOwnedByTeamcheck && FStrEq(STRING(pEnt->m_szOwnedByTeamcheck),STRING(pev->targetname))){
			pEnt->m_iOwningTeam=pev->team;
		}
	}

	pEnt=NULL;

	while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"monster_miniturret"))!=NULL){
		if(pEnt->m_szTeamcheck && FStrEq(STRING(pEnt->m_szTeamcheck),STRING(pev->targetname))){
			pEnt->pev->team=pev->team;
		}
		if(pEnt->m_szOwnedByTeamcheck && FStrEq(STRING(pEnt->m_szOwnedByTeamcheck),STRING(pev->targetname))){
			pEnt->m_iOwningTeam=pev->team;
		}
	}

	pEnt=NULL;

	while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"info_tfgoal"))!=NULL){
		if(pEnt->m_szTeamcheck && FStrEq(STRING(pEnt->m_szTeamcheck),STRING(pev->targetname))){
			pEnt->pev->team=pev->team;
		}
		if(pEnt->m_szOwnedByTeamcheck && FStrEq(STRING(pEnt->m_szOwnedByTeamcheck),STRING(pev->targetname))){
			pEnt->m_iOwningTeam=pev->team;
		}
	}

	while((pEnt=(CBaseToggle*)UTIL_FindEntityByClassname(pEnt,"item_tfgoal"))!=NULL){
		if(pEnt->m_szTeamcheck && FStrEq(STRING(pEnt->m_szTeamcheck),STRING(pev->targetname))){
			pEnt->pev->team=pev->team;
		}
		if(pEnt->m_szOwnedByTeamcheck && FStrEq(STRING(pEnt->m_szOwnedByTeamcheck),STRING(pev->targetname))){
			pEnt->m_iOwningTeam=pev->team;
		}
	}

	SetThink(NULL);
}

/* *** CTFCTeamset *** */

void CTFCTeamset::Spawn(){
	CPointEntity::Spawn();
}
LINK_ENTITY_TO_CLASS(info_tf_teamset,CTFCTeamset);

void CTFCTeamset::KeyValue(KeyValueData *pkvd){
	CPointEntity::KeyValue(pkvd);
}

void CTFCTeamset::Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value){
	CBaseEntity *pEnt=NULL;

	pEnt=UTIL_FindEntityByTargetname(pEnt,STRING(pev->target));

	if(pEnt){
		if(pEnt->pev->team==1)
			pEnt->pev->team=2;
		else
			pEnt->pev->team=1;

		((CTFCTeamcheck*)pEnt)->ModifyTeamchecks();
	}
}

/* *** CDragonriderSpawn *** */

#include "monsters/dragon.h"

class CDragonriderSpawn:public CBaseTeamspawn{
public:
	void Precache(){
		CBaseTeamspawn::Precache();
	}

	void Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value){
		CBaseTeamspawn::Use(pActivator,pCaller,useType,value);

		if(pActivator->IsPlayer() && pActivator->IsAlive()){
			SetThink(GiveDragon);
			m_pPlayer=(CBasePlayer*)pActivator;
			pev->nextthink=gpGlobals->time+.1;
		}
	}

	void EXPORT GiveDragon(){
		if(m_pPlayer->IsPlayer() && m_pPlayer->IsAlive() && m_pPlayer->m_hMounted==NULL){
			CDragon *pDragon;
			
			pDragon=(CDragon*)Create("monster_dragon",pev->origin,pev->angles,edict());
			pDragon->pev->team=pev->team;
			pDragon->pev->iuser1=FALSE;
			pDragon->pev->iuser2=TRUE;
			pDragon->Mount(m_pPlayer);
		}
	}

	CBasePlayer* m_pPlayer;
};

LINK_ENTITY_TO_CLASS(info_dragonrider_spawn,CDragonriderSpawn);

/* *** WWDetect *** */

class CWWDetect : public CPointEntity{
	void KeyValue(KeyValueData *pkvd){
		if(FStrEq(pkvd->szKeyName,"team1_max")){
			g_iMaxOnTeam[1]=atoi(pkvd->szValue);
		
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team2_max")){
			g_iMaxOnTeam[2]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team3_max")){
			g_iMaxOnTeam[3]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team4_max")){
			g_iMaxOnTeam[4]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team1_allies")){
			g_iTeamAllies[1]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team2_allies")){
			g_iTeamAllies[2]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team3_allies")){
			g_iTeamAllies[3]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team4_allies")){
			g_iTeamAllies[4]=atoi(pkvd->szValue);

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team0_lives")){
			g_iTeamLives[0]=atoi(pkvd->szValue);
			if(g_iTeamLives[0]==0)
				g_iTeamLives[0]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team1_lives")){
			g_iTeamLives[1]=atoi(pkvd->szValue);
			if(g_iTeamLives[1]==0)
				g_iTeamLives[1]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team2_lives")){
			g_iTeamLives[2]=atoi(pkvd->szValue);
			if(g_iTeamLives[2]==0)
				g_iTeamLives[2]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team3_lives")){
			g_iTeamLives[3]=atoi(pkvd->szValue);
			if(g_iTeamLives[3]==0)
				g_iTeamLives[3]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team4_lives")){
			g_iTeamLives[4]=atoi(pkvd->szValue);
			if(g_iTeamLives[4]==0)
				g_iTeamLives[4]=-1;

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status1")){
			g_iItemStatus[1]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status2")){
			g_iItemStatus[2]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status3")){
			g_iItemStatus[3]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"display_item_status4")){
			g_iItemStatus[4]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team_str_home")){
			g_szTeamStrHome=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team_str_moved")){
			g_szTeamStrMoved=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team_str_carried")){
			g_szTeamStrCarried=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"non_team_str_home")){
			g_szNonTeamStrHome=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"non_team_str_moved")){
			g_szNonTeamStrMoved=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"non_team_str_carried") || FStrEq(pkvd->szKeyName,"n_t_s_c")){
			g_szNonTeamStrCarried=ALLOC_STRING(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"conclave_team0")){
			g_pClassLimits->SetConclaveLimits(0,atoi(pkvd->szValue));
		
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"conclave_team1")){
			g_pClassLimits->SetConclaveLimits(1,atoi(pkvd->szValue));
		
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"conclave_team2")){
			g_pClassLimits->SetConclaveLimits(2,atoi(pkvd->szValue));

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"conclave_team3")){
			g_pClassLimits->SetConclaveLimits(3,atoi(pkvd->szValue));

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"conclave_team4")){
			g_pClassLimits->SetConclaveLimits(4,atoi(pkvd->szValue));

			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"class_team0")){
			unsigned int x=65535;
			unsigned int y=atoi(pkvd->szValue);

			y=y<<1;

			if(y!=0){
				y=~y;
				x=x&y;

				g_pClassLimits->SetClassLimits(0,x);
			}
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"class_team1")){
			unsigned int x=65535;
			unsigned int y=atoi(pkvd->szValue);

			y=y<<1;

			if(y!=0){
				y=~y;
				x=x&y;

				g_pClassLimits->SetClassLimits(1,x);
			}
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"class_team2")){
			unsigned int x=65535;
			unsigned int y=atoi(pkvd->szValue);

			y=y<<1;

			if(y!=0){
				y=~y;
				x=x&y;

				g_pClassLimits->SetClassLimits(2,x);
			}
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"class_team3")){
			unsigned int x=65535;
			unsigned int y=atoi(pkvd->szValue);

			y=y<<1;

			if(y!=0){
				y=~y;
				x=x&y;

				g_pClassLimits->SetClassLimits(3,x);
			}
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"class_team4")){
			unsigned int x=65535;
			unsigned int y=atoi(pkvd->szValue);

			y=y<<1;

			if(y!=0){
				y=~y;
				x=x&y;

				g_pClassLimits->SetClassLimits(4,x);
			}
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team0_min")){
			g_iMinForTeam[0]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team1_min")){
			g_iMinForTeam[1]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team2_min")){
			g_iMinForTeam[2]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team3_min")){
			g_iMinForTeam[3]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else if(FStrEq(pkvd->szKeyName,"team4_min")){
			g_iMinForTeam[4]=atoi(pkvd->szValue);
			pkvd->fHandled=TRUE;
		}
		else
			CPointEntity::KeyValue(pkvd);
	}

	void Spawn(void){
		Precache();
	}
};		
LINK_ENTITY_TO_CLASS(info_wwdetect, CWWDetect);

class CAreaMarker:public CPointEntity{
};
LINK_ENTITY_TO_CLASS(info_areamarker,CAreaMarker);