#ifndef GOLEM_H_4342_DDEDDS
#define GOLEM_H_4342_DDEDDS

#include	"extdll.h"
#include	"util.h"
#include	"cbase.h"
#include	"gamerules.h"


/* CGolemPart */
class CGolemPart : public CBaseToggle{
public:
	virtual void Spawn(){
		pev->solid=SOLID_BSP;
		pev->movetype=MOVETYPE_PUSH;

		UTIL_SetOrigin(pev, pev->origin);
		UTIL_SetSize (pev, pev->mins, pev->maxs);
		SET_MODEL(edict(),STRING(pev->model));

		SetBlocked(PartBlocked);
	}
	virtual void EXPORT MoveThink(){}
	void SetBody(CBaseEntity *pEnt){
		m_hBody=pEnt;
	}
	virtual void EXPORT PartBlocked(CBaseEntity *pOther){
		if(m_hBody)
			((CGolemPart*)(CBaseEntity*)m_hBody)->PartBlocked(pOther);
	}

	EHANDLE m_hBody;
	Vector m_vecVelocity;
};

/* CGolem */
class CGolem : public CGolemPart{
public:
	void Spawn();
	void KeyValue(KeyValueData *pkvd);
	void FindParts();
	void MoveVector(Vector pos);
	void MoveDone();
	void RealignParts();
	virtual void EXPORT Blocked(CBaseEntity *pOther);
	virtual void EXPORT PartBlocked(CBaseEntity *pOther);
	void SetFloor(float floor,int leg);
	void EXPORT MoveThink();
	void Walk();
	void Left();
	void Right();
	void Attack(CBaseEntity *pUser);
	void Stop();
	void Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value){
		pev->angles=m_vecInitialAngles;
		UTIL_SetOrigin(pev,m_vecInitialOrigin);

		RealignParts();
	}
	int IsWalking(){
		return (m_iAction==1 || m_iAction==2 || m_iAction==3 || m_iAction==4);
	}
	void Precache(){
		PRECACHE_SOUND((char*)STRING(m_iUpSound));
		PRECACHE_SOUND((char*)STRING(m_iDownSound));
	}
	int NumberOfParts(){
		return m_iParts;
	}
	EHANDLE GetPartNumber(int i){
		return m_hParts[i];
	}
	BOOL _Traced;
	Vector m_vecGolemBase;
	Vector m_vecOrgBase;

private:
	char m_szParts[32][64];
	int m_iParts;
	Vector m_vecPartOffsets[32];
	EHANDLE m_hParts[32];
	int m_iLeftLeg,m_iRightLeg,m_iLeftArm,m_iRightArm;
	float m_flFloor[2];
	float m_flNextAction;
	int m_iAction;
	int m_iStop;
	float m_flStepHeight;
	float m_flStepLength;
	float m_flStepTime;
	float m_flTurnSpeed;
	Vector m_vecOffset;
	Vector m_vecInitialOrigin;
	Vector m_vecInitialAngles;
	int m_iUpSound;
	int m_iDownSound;
	float m_flFloatCheckTime;
	CBaseEntity *pAttacker;
};
#endif