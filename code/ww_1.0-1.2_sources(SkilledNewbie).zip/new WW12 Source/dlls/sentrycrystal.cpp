/*
	SentryCrystal.cpp
	By: Alan Fischer
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "tfcentities.h"

// Define all constants here
#define SENTRYCRYSTAL_DAMAGE				70
#define SENTRYCRYSTAL_BOLT_LIFE				2
#define SENTRYCRYSTAL_BOLT_WIDTH			20
#define SENTRYCRYSTAL_BOLT_NOISE			30
#define SENTRYCRYSTAL_BOLT_BRIGHTNESS		255

class CSentryCrystal : public CBaseMonster
{
public:
	void Spawn( void );
	void Precache( void );
	void EXPORT WatchOut();
	void KeyValue(KeyValueData *pkvd);
	int IRelationship(CBaseEntity *pTarget);

	Vector		vecToEnemy;

	int m_iRed;
	int m_iGreen;
	int m_iBlue;

	int m_iOrientation;
};

LINK_ENTITY_TO_CLASS(monster_turret,CSentryCrystal );
LINK_ENTITY_TO_CLASS(monster_miniturret,CSentryCrystal);

void CSentryCrystal::WatchOut(){
	if ( m_hEnemy != NULL && FVisible( m_hEnemy ) && m_hEnemy->pev->takedamage && m_hEnemy->IsAlive()){
		//Shoot at the enemy
		if(pev->dmgtime<=gpGlobals->time){
			
			MESSAGE_BEGIN( MSG_PAS, SVC_TEMPENTITY, pev->origin );
				WRITE_BYTE( TE_BEAMPOINTS ); 
				WRITE_COORD( pev->origin.x ); 
				WRITE_COORD( pev->origin.y ); 
				WRITE_COORD( pev->origin.z ); 
				WRITE_COORD( m_hEnemy->pev->origin.x ); 
				WRITE_COORD( m_hEnemy->pev->origin.y ); 
				WRITE_COORD( m_hEnemy->pev->origin.z ); 
				WRITE_SHORT( g_sModelIndexBubbles ); // Beam sprite index. 
				WRITE_BYTE( 0 ); // Starting frame 
				WRITE_BYTE( 0 ); // Framerate 
				WRITE_BYTE( SENTRYCRYSTAL_BOLT_LIFE ); // How long the beam stays on. 
				WRITE_BYTE( SENTRYCRYSTAL_BOLT_WIDTH ); 
				WRITE_BYTE( SENTRYCRYSTAL_BOLT_NOISE ); // Noise 
				WRITE_BYTE( m_iRed ); 
				WRITE_BYTE( m_iGreen ); 
				WRITE_BYTE( m_iBlue ); 
				WRITE_BYTE( SENTRYCRYSTAL_BOLT_BRIGHTNESS ); 
				WRITE_BYTE( 0 ); // Speed, sort of.
			MESSAGE_END( );

			int temp=pev->team;
			pev->team=0;

			m_hEnemy->TakeDamage(pev,pev,SENTRYCRYSTAL_DAMAGE,DMG_SHOCK);

			pev->team=temp;

			m_hEnemy->pev->velocity=m_hEnemy->pev->velocity+Vector(RANDOM_FLOAT(-100,100),RANDOM_FLOAT(-100,100),RANDOM_FLOAT(-100,100));
			
			pev->dmgtime=gpGlobals->time+.25;
		}
	}

	else{//Find something else
		Look( 782 );
		m_hEnemy = BestVisibleEnemy( );
	}

	pev->nextthink = gpGlobals->time + 0.1;
}

void CSentryCrystal :: Spawn( void )
{
	Precache( );

	pev->movetype = MOVETYPE_NOCLIP;
	pev->flags |= FL_MONSTER;
	pev->takedamage = DAMAGE_NO;

	m_flFieldOfView=VIEW_FIELD_FULL;

	pev->solid = SOLID_BBOX;
	pev->nextthink = gpGlobals->time + 0.1;
	UTIL_SetOrigin( pev, pev->origin );
	SET_MODEL(ENT(pev), "models/sentrycrystal.mdl");

	SetThink(WatchOut);
	SetTouch(NULL);

	ResetSequenceInfo();

	m_iRed=0;
	m_iGreen=0;
	m_iBlue=0;

	if(pev->team==2)
		m_iRed=255;
	else if(pev->team==1)
		m_iBlue=255;
	else if(pev->team==3){
		m_iGreen=255;
		m_iRed=128;
	}
	else if(pev->team==4)
		m_iGreen=255;


	if(m_iOrientation==0){
		pev->angles=UTIL_VecToAngles(Vector(0,0,1));
		pev->origin.z+=16;
	}
	else{
		pev->angles=UTIL_VecToAngles(Vector(0,0,-1));
		pev->origin.z-=16;
	}

	UTIL_SetOrigin(pev,pev->origin);
	
	pev->nextthink=gpGlobals->time+.3;
}

void CSentryCrystal :: Precache( void )
{
	PRECACHE_MODEL("models/sentrycrystal.mdl");
}

void CSentryCrystal :: KeyValue(KeyValueData *pkvd){
	if(FStrEq(pkvd->szKeyName,"orientation")){
		m_iOrientation=atoi(pkvd->szValue);
		pkvd->fHandled=TRUE;
	}
	else
		CBaseMonster::KeyValue(pkvd);
}

extern int g_iTeams;
int CSentryCrystal::IRelationship(CBaseEntity *pTarget){
	if(g_iTeams==0)
		return R_AL;

	if(pTarget->pev->owner == pev->owner)
		return R_AL;

	if(!pTarget->IsPlayer())
		return R_AL;
	
	if(pTarget->pev->team==pev->team && (m_iGoalActivation&TFCGOAL_ACTIVATION_REVERSE_AP)==0)
		return R_NM;
	else if(pTarget->pev->team!=pev->team && (m_iGoalActivation&TFCGOAL_ACTIVATION_REVERSE_AP)!=0)
		return R_NM;
	
	return R_NO;
}