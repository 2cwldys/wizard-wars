/*
	Beanstalk.cpp
	By: Alan Fischer
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "beanstalk.h"

#define BEANSTALK_HEALTH				200
#define BEANSTALK_HEALTHTIME			1

TYPEDESCRIPTION	CBeanstalk::m_SaveData[] = 
{
	DEFINE_FIELD( CBeanstalk, m_hOwner, FIELD_EHANDLE ),
	DEFINE_FIELD( CBeanstalk, m_hNextStalk, FIELD_EHANDLE ),
};
IMPLEMENT_SAVERESTORE( CBeanstalk, CBaseMonster );

void CBeanstalk :: Spawn( void )
{
	Precache( );

	pev->renderamt=0;
	pev->rendermode=kRenderTransColor;

	SET_MODEL(ENT(pev), "models/beanstalk.mdl");

	pev->movetype = MOVETYPE_NONE;
	pev->takedamage = DAMAGE_YES;
	pev->max_health = BEANSTALK_HEALTH;
	pev->health = pev->max_health;
	pev->frame=254; //It'll act like a ladder

	ResetSequenceInfo( );

	UTIL_SetSize(pev, Vector( -18, -18, 0), Vector(18, 18, 45));

	//If pev->owner is not NULL, you can't climb it
	if(pev->owner){
		CBasePlayer* player=(CBasePlayer*)Instance(pev->owner);

		m_hOwner=player;
		pev->owner=NULL;
	}

	//Make it solid
	pev->solid = SOLID_BBOX;
	UTIL_SetOrigin( pev, pev->origin );

	SetThink(StalkThink);

	m_flNextHealthGain=0;
	
	pev->nextthink = gpGlobals->time + 0.1;
}

EXPORT void CBeanstalk::StalkThink(){
	if(pev->renderamt<255){
		if(m_flFadeInTime<=gpGlobals->time){
			pev->renderamt=pev->renderamt+10;
			if(pev->renderamt>=255){
				pev->renderamt=255;
				pev->rendermode=kRenderNormal;
				pev->frame=254;
			}
			m_flFadeInTime=gpGlobals->time+.1;
		}
	}

	//Gain some health
	if(m_flNextHealthGain<=gpGlobals->time){
		int health=((float)Illumination()/255.0)*20;

		TakeHealth(min(health,pev->max_health),DMG_GENERIC);
		m_flNextHealthGain=gpGlobals->time+BEANSTALK_HEALTHTIME;
	}

	pev->nextthink = gpGlobals->time + 0.1;
}

void CBeanstalk::Killed(entvars_t *pevAttacker, int iGib){
	CBasePlayer* pPlayer=NULL;
	
	if(m_hOwner!=NULL)
		pPlayer=(CBasePlayer*)(CBaseEntity*)m_hOwner;
	
	if(pPlayer && pPlayer->m_pClass!=NULL)
		((CNatureWizard*)pPlayer->m_pClass)->RemoveAllStalks();
	else
		RemoveMe();
}

void CBeanstalk::RemoveMe(){
	if(m_hNextStalk)
		((CBeanstalk*)(CBaseEntity*)m_hNextStalk)->RemoveMe();

	UTIL_Remove(this);
}

void CBeanstalk :: Precache( void )
{
	PRECACHE_MODEL("models/beanstalk.mdl");
}

LINK_ENTITY_TO_CLASS( beanstalk, CBeanstalk );