/*START:WIZWARS
	wizardclasses.cpp : represent character classes

	By: Alan Fischer

	Thanks to : Blake Grant for the idea and some basic code

	For the WizWars mod
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "soundent.h"
#include "decals.h"
#include "gamerules.h"

#include "wizwarsgrenades.h"
#include "thornbush.h"
#include "tfcentities.h"
#include "beanstalk.h"
#include "shake.h"
#include "enginecallback.h"

#include "wizardwarsdefs.h"

#define DEATHWIZARD_SPECIAL_COST 25
#define FIREWIZARD_SPECIAL_COST 100
#define WINDWIZARD_SPECIAL_COST 10
#define LIFEWIZARD_SPECIAL_COST 25
#define EARTHWIZARD_SPECIAL_COST 20
#define WINDWIZARD_SPECIAL_DELAY 5
#define NATUREWIZARD_SEARCHRADIUS 300
#define DRAGONWIZARD_SPECIAL_LIFE 40
#define DRAGONWIZARD_SPECIAL_COST 100
#define DRAGONWIZARD_SPECIAL_STRENGTH 600

#define BEAR_SPEED .54

extern int gmsgVGUIMenu;
extern ClassLimits *g_pClassLimits;

ClassLimits::ClassLimits(){
	for(int y=0;y<5;y++){
		m_iClassLimits[y]=65535-512;
	}
}

CBaseClass::CBaseClass(CBasePlayer *pPlayer){
	m_iGrenadeArmed=FALSE;
	m_pPlayer=pPlayer;
	m_flPlayerStopTime=0;
	m_iPlayerStopped=FALSE;

	m_iClassNumber=0;
}
CBaseClass * CBaseClass::GetNumberedClass(CBasePlayer *pPlayer,int number){
	switch(number){
		case(LIFE_CLASS):{
			return(new CLifeWizard(pPlayer));
			break;
		  }
		case(FIRE_CLASS):{
			return(new CFireWizard(pPlayer));
			break;
		}
		case(ICE_CLASS):{
			return(new CIceWizard(pPlayer));
			break;
		}
		case(NATURE_CLASS):{
			return(new CNatureWizard(pPlayer));
			break;
		}
		case(LIGHTNING_CLASS):{
			return(new CLightningWizard(pPlayer));
			break;
		}
		case(DEATH_CLASS):{
			return(new CDeathWizard(pPlayer));
			break;
		}
		case(EARTH_CLASS):{
			return(new CEarthWizard(pPlayer));
			break;
		}
		case(WIND_CLASS):{
			return(new CWindWizard(pPlayer));
			break;
		}
		case(ARCHMAGE_CLASS):{
			return(new CArchMage(pPlayer));
			break;
		}
		case(DRAGONWIZARD_CLASS):{
			return(new CDragonWizard(pPlayer));
			break;
		}
	}

	return GetRandomClass(pPlayer);
}
char * CBaseClass::GetWizardName(int num){
	return ClassNames[num];
}
char * CBaseClass::GetWizardModel(int num){
	return ModelNames[num];
}
CBaseClass * CBaseClass::GetRandomClass(CBasePlayer *pPlayer){
	//Build up available class list
	int validOptions[MAX_CLASSES];
	int z=0;

	for(unsigned int x=0;x<MAX_CLASSES;x++){
		if(g_pClassLimits->IsValidClass(pPlayer->pev->team,x)){
			validOptions[z]=x;
			z++;
		}
	}

	return GetNumberedClass(pPlayer,validOptions[RANDOM_LONG(0,z)]);
}
char * CBaseClass::GetModelName(){
	return ModelNames[m_iClassNumber];
}
void CBaseClass::Equip(){
	CBaseClass::GiveSpells();
	
	m_pPlayer->GiveAmmo( URANIUM_MAX_CARRY, "uranium", URANIUM_MAX_CARRY );
	m_pPlayer->GiveAmmo(4,"ARgrenades",4);
	m_pPlayer->pev->armorvalue=m_iMaxArmor;
	m_pPlayer->pev->armortype=m_iMaxArmor;

	m_iGrenadeArmed=FALSE;

	g_engfuncs.pfnSetClientMaxspeed( ENT( m_pPlayer->pev ), PlayerSpeed() );
}
int CBaseClass::PlayerSpeed(){
	return(m_flPlayerSpeed*CVAR_GET_FLOAT("sv_maxspeed"));
}
void CBaseClass::Think(){
	if(m_iGrenadeArmed&&m_flGrenadeTime<gpGlobals->time){//BOOM!  It went off in your hand... :O
		m_flGrenadeTime-=.1;
		TossGrenade();
	}
	else if(m_iForceGrenadeToss&&m_flGrenadeTime-gpGlobals->time<=2.5){//Toss it if he tried to throw it too early
		m_iForceGrenadeToss=FALSE;
		TossGrenade();
	}

	if(m_flPlayerStopTime>gpGlobals->time){
		m_pPlayer->pev->velocity.x=0;
		m_pPlayer->pev->velocity.y=0;
	}
	else if(m_iPlayerStopped==TRUE){
		g_engfuncs.pfnSetClientMaxspeed( ENT( m_pPlayer->pev ), PlayerSpeed() );
		m_iPlayerStopped=FALSE;
	}
}
void CBaseClass::ArmGrenade(){
	int ammoIndex=m_pPlayer->GetAmmoIndex("ARgrenades");
	
	if(m_iGrenadeArmed==FALSE && m_pPlayer->m_rgAmmo[ammoIndex]>0){
		m_pPlayer->m_rgAmmo[ammoIndex]--;
		m_iGrenadeArmed=TRUE;
		m_iForceGrenadeToss=FALSE;
		m_flGrenadeTime=gpGlobals->time+3;

		EMIT_SOUND_DYN(ENT(m_pPlayer->pev),CHAN_ITEM,"items/gunpickup3.wav",1,ATTN_NORM,0,150);
	}
}
void CBaseClass::TossGrenade(){
	if(m_pPlayer!=NULL&&m_iGrenadeArmed==TRUE){

		if(m_flGrenadeTime-gpGlobals->time>2.5){//Tried to throw it too early
			m_iForceGrenadeToss=TRUE;
			return;
		}

		Vector angThrow = m_pPlayer->pev->v_angle + m_pPlayer->pev->punchangle;

		if (angThrow.x < 0)
			angThrow.x = -10 + angThrow.x * ((90 - 10) / 90.0);
		else
			angThrow.x = -10 + angThrow.x * ((90 + 10) / 90.0);

		float flVel = (90 - angThrow.x) * 4;
		if (flVel > 500)
			flVel = 500;

		UTIL_MakeVectors( angThrow );

		Vector vecSrc = m_pPlayer->pev->origin + m_pPlayer->pev->view_ofs + gpGlobals->v_forward * 16;
		Vector vecThrow = gpGlobals->v_forward * flVel *1.25;

		MakeGrenade(vecSrc,vecThrow);
		m_iGrenadeArmed=FALSE;
	}
}
void CBaseClass::StopForTime(float time){
	g_engfuncs.pfnSetClientMaxspeed(ENT(m_pPlayer->pev),-1);
	m_pPlayer->pev->velocity.x=0;
	m_pPlayer->pev->velocity.y=0;
	m_flPlayerStopTime=gpGlobals->time+time;
	m_iPlayerStopped=TRUE;
}
void CBaseClass::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CGrenade *pGrenade=CGrenade::ShootTimed(m_pPlayer->pev,vecSrc,vecThrow,m_flGrenadeTime-gpGlobals->time);
}
void CBaseClass::DoSpecial(int slot){
	UTIL_SayText("SPECIAL HERE",m_pPlayer);
}
void CBaseClass::StatusReport(char *c){
	char text[80];

	if(m_pPlayer->m_iLives!=-1){
		sprintf(text," Lives:%d",m_pPlayer->m_iLives);
		strcat(c,text);
	}
}
void CBaseClass::SetTeamColor(int team){
	m_pPlayer->pev->skin=team;
}
void CBaseClass::GiveSpells(){
}
int CBaseClass::UpdateStatusBar(CBaseEntity *pEntity,char *buffer){
	if(pEntity->IsPlayer() && !(pEntity->pev->effects&EF_NODRAW) && ((CBasePlayer*)pEntity)->m_pClass!=NULL){
		if(m_pPlayer->IRelationship(pEntity)<0){
			int health=((float)pEntity->pev->health/(float)pEntity->pev->max_health)*100.0;
			int armor=((float)pEntity->pev->armorvalue/(float)pEntity->pev->armortype)*100.0;
			sprintf(buffer,"%c(Friend) %s Health: %d%%%% Armor: %d%%%%",2,STRING(pEntity->pev->netname),health,armor);
		}
		else{
			if(pEntity->IsPlayer() && pEntity->pev->playerclass==ICE_CLASS){
				CBasePlayer* pl=((CBasePlayer*)pEntity);
				CIceWizard* bw=((CIceWizard*)pl->m_pClass);

				if(bw->m_iIsInvisible==TRUE && pEntity->pev->renderamt<20){
					sprintf(buffer,"");
					return 1;
				}

				if(m_pPlayer->pev->team!=0 && bw->m_iDisguisedTeam==m_pPlayer->pev->team){
					sprintf(buffer,"%c(friend) %s",2,bw->m_szDisguisedName);
					return 1;
				}
			}

			sprintf(buffer,"%c(Foe) %s",2,STRING(pEntity->pev->netname));
		}

		return 1;
	}
	if(FClassnameIs(pEntity->pev,"monster_thornbush")){
		CThornbush* tb=(CThornbush*)pEntity;
		if(m_pPlayer->IRelationship(pEntity)<0){
			sprintf(buffer,"(friend)%s's Thornplant",STRING(tb->m_hOwner->pev->netname));
		}
		else{
			sprintf(buffer,"(foe)%s's Thornplant",STRING(tb->m_hOwner->pev->netname));
		}

		return 1;
	}

	return 0;
}
void CBaseClass::Remove(){
}


DLL_GLOBAL short g_sSacrificeSprite;

CLifeWizard::CLifeWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.75;
	m_iMaxHealth=75;
	m_iMaxArmor=80;

	m_flNextHealthGain=0;

	m_iClassNumber=LIFE_CLASS;
}
void CLifeWizard::Equip(){
	GiveSpells();

	m_iMadeSoul=0;
	m_iSacrificeKill=0;

	CBaseClass::Equip();
}
void CLifeWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_doublemagicmisslespell");
	m_pPlayer->GiveNamedItem("weapon_whiterayspell");
	m_pPlayer->GiveNamedItem("weapon_forcespell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
}
void CLifeWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_healhurtsatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CLifeWizard::Think(){
	if(m_flNextHealthGain<=gpGlobals->time && m_pPlayer->IsAlive()){
		m_flNextHealthGain=gpGlobals->time+5;
		m_pPlayer->TakeHealth(4,DMG_GENERIC);
		m_pPlayer->m_bitsDamageType=0;
	}

	if(m_pPlayer->pev->health<=0 && m_iMadeSoul==0){
		m_iMadeSoul=1;

		CBaseEntity *pEnt=CBaseEntity::Create("lifesoul",m_pPlayer->pev->origin,m_pPlayer->pev->angles,m_pPlayer->edict());
	}


	CBaseClass::Think();
}
void CLifeWizard::DoSpecial(int slot){
	switch(slot){
		case(1):{
			if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<LIFEWIZARD_SPECIAL_COST){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
				return;
			}
			if(!m_pPlayer->IsAlive()){
				return;
			}

			m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=LIFEWIZARD_SPECIAL_COST;

			m_iSacrificeKill=1;
			m_pPlayer->TakeDamage(m_pPlayer->pev,m_pPlayer->pev,1000,DMG_CRUSH);
			m_iSacrificeKill=0;

			MESSAGE_BEGIN(MSG_PVS,SVC_TEMPENTITY,m_pPlayer->pev->origin);
				WRITE_BYTE(TE_BEAMTORUS);
				WRITE_COORD(m_pPlayer->pev->origin.x);
				WRITE_COORD(m_pPlayer->pev->origin.y);
				WRITE_COORD(m_pPlayer->pev->origin.z);
				WRITE_COORD(m_pPlayer->pev->origin.x);
				WRITE_COORD(m_pPlayer->pev->origin.y);
				WRITE_COORD(m_pPlayer->pev->origin.z+300);
	 			WRITE_SHORT(g_sModelIndexSmoke);
				WRITE_BYTE(0); // startframe
				WRITE_BYTE(0); // framerate
				WRITE_BYTE(8); // life
				WRITE_BYTE(20);  // width
				WRITE_BYTE(20);   // noise
				WRITE_BYTE(0);   // r, g, b
				WRITE_BYTE(0);   // r, g, b
				WRITE_BYTE(255);   // r, g, b
				WRITE_BYTE(255);	// brightness
				WRITE_BYTE(1);		// speed
			MESSAGE_END();


			CBaseEntity *pEntity=NULL;
			// iterate on all entities in the vicinity.
			while ((pEntity = UTIL_FindEntityInSphere( pEntity, m_pPlayer->pev->origin, 250 )) != NULL){
				//Don't hit yourself, or your teammates
				if(pEntity->IsPlayer()&&m_pPlayer->IRelationship(pEntity)<0&&pEntity!=m_pPlayer){
					pEntity->TakeHealth(300,DMG_GENERIC);
					pEntity->pev->armorvalue=pEntity->pev->armortype;

					if(((CBasePlayer*)pEntity)->m_bitsDamageType&DMG_POISON){
						m_pPlayer->pev->frags++;
						((CBasePlayer*)pEntity)->m_bitsDamageType=0;
					}
				}
				else if(m_pPlayer->IRelationship(pEntity)>0){
					UTIL_ScreenFade(pEntity,Vector(255,255,255),2,2,255,FFADE_IN);
					pEntity->pev->armorvalue=pEntity->pev->armorvalue/2;

					if(pEntity->pev->health>1)
						pEntity->pev->health=pEntity->pev->health/2;
				}
			}
			m_pPlayer->AddPoints(1,1);
			break;
		}
		case(2):{
			break;
		}
	}
}
int CLifeWizard::UpdateStatusBar(CBaseEntity *pEntity,char *buffer){
	if(pEntity->pev->takedamage!=DAMAGE_NO){
		if(pEntity->IsPlayer()){
			int	health=((float)pEntity->pev->health/(float)pEntity->pev->max_health)*100.0;
			int armor=((float)pEntity->pev->armorvalue/(float)pEntity->pev->armortype)*100.0;

			sprintf(buffer,"%s Health: %d%%%% Armor: %d%%%%",STRING(pEntity->pev->netname),health,armor);
		}
		else{
			if(pEntity->pev->max_health){
				int	health=((float)pEntity->pev->health/(float)pEntity->pev->max_health)*100.0;

				if(FClassnameIs(pEntity->pev,"monster_thornbush")){
					if(m_pPlayer->IRelationship(pEntity)<0){
						sprintf(buffer,"(Friend) Thornplant Health: %d%%%%",health);
					}
					else{
						sprintf(buffer,"(Foe) Thornplant Health: %d%%%%",health);
					}
				}

				else{
					sprintf(buffer,"Health: %d%%%%",health);
				}
			}
			else
				sprintf(buffer,"Health: %d units",(int)pEntity->pev->health);
		}

		return 1;
	}

	return 0;
}

#define FISSURESPELL_SOUND_CAST "sound/spells/fissure_cast.wav"

CFireWizard::CFireWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.56;
	m_iMaxHealth=100;
	m_iMaxArmor=150;

	m_iClassNumber=FIRE_CLASS;
}
void CFireWizard::Equip(){
	GiveSpells();

	CBaseClass::Equip();
}
void CFireWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_magicmisslespell");
	m_pPlayer->GiveNamedItem("weapon_fireballspell");
	m_pPlayer->GiveNamedItem("weapon_flamelickspell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
}
void CFireWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_firesatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CFireWizard::DoSpecial(int slot){
	switch(slot){
		case(1):{
			if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<FIREWIZARD_SPECIAL_COST){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
				return;
			}

			m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=FIREWIZARD_SPECIAL_COST;

			UTIL_MakeVectors( m_pPlayer->pev->v_angle );
		
			Vector v_for=gpGlobals->v_forward;
			Vector v_temp=m_pPlayer->pev->origin;

			v_temp.z=v_temp.z+24;
			v_for=v_temp+v_for*48;

			EMIT_SOUND(ENT(m_pPlayer->pev),CHAN_WEAPON,FISSURESPELL_SOUND_CAST,1,ATTN_NORM);

			Vector v_ang=v_for-v_temp;
			v_ang=UTIL_VecToAngles(v_ang);

			CBaseEntity* fissure=CBaseEntity::Create("proj_fissure",v_for,v_ang,m_pPlayer->edict());

			StopForTime(3);
		}
	}

	return;
}


CIceWizard::CIceWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.68;
	m_iMaxHealth=90;
	m_iMaxArmor=90;

	m_iSecondMenu=0;
	m_iIsInvisible=FALSE;
	m_iIsDisguised=FALSE;
	m_iDisguisedTeam=pPlayer->pev->team;
	m_iDisguisedWizard=ICE_CLASS;

	m_iClassNumber=ICE_CLASS;
}
char * CIceWizard::GetModelName(){
	return GetWizardModel(m_iDisguisedWizard);
}
void CIceWizard::Equip(){
	GiveSpells();

	CBaseClass::Equip();
}
void CIceWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_mindmisslespell");
	m_pPlayer->GiveNamedItem("weapon_icepokespell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
	m_pPlayer->GiveNamedItem("weapon_freezerayspell");
}
void CIceWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_tcrystal",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CIceWizard::DoSpecial(int slot){
	switch(slot){
		case(1):{
			if(m_iIsInvisible) return; //cjb113:  added to remove multi mana drain from invisibility.

			if(m_pPlayer->m_pAttachedItem && m_pPlayer->m_pAttachedItem->m_iGoalResult&TFCGOAL_RESULT_RESETSPY){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Ice_DisguiseWithItem");
				return;
			}

			if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<20){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
				return;
			}

			m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=20;

			m_pPlayer->pev->rendermode=kRenderTransColor;
			m_pPlayer->pev->renderamt=255;
			m_iIsInvisible=TRUE;
			m_flNextAmmoUse=gpGlobals->time;
			break;
		}
		case(2):{
			m_pPlayer->pev->rendermode=kRenderTransAlpha;
			m_pPlayer->pev->renderamt=255;
			m_iIsInvisible=FALSE;
			break;
		}
		case(3):{
			if(m_pPlayer->m_pAttachedItem && m_pPlayer->m_pAttachedItem->m_iGoalResult&TFCGOAL_RESULT_RESETSPY){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Ice_DisguiseWithItem");
				return;
			}

			if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<20){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
				return;
			}

			m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=20;

			if(m_pPlayer->m_pLastEnemySeen!=NULL){
				m_iDisguisedTeam=m_pPlayer->m_pLastEnemySeen->pev->team;
				m_iDisguisedWizard=m_pPlayer->m_pLastEnemySeen->pev->playerclass;
				strcpy(m_szDisguisedName,STRING(m_pPlayer->m_pLastEnemySeen->pev->netname));

				switch(m_iDisguisedWizard)
				{
						case(LIFE_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_lifestaff.mdl"); break;
						case(FIRE_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_firestaff.mdl"); break;
						case(NATURE_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_stickstaff.mdl"); break;
						case(LIGHTNING_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_lightningstaff.mdl"); break;
						case(DEATH_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_scythestaff.mdl"); break;
						case(EARTH_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_quakestaff.mdl"); break;
						case(WIND_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_windstaff.mdl"); break;
						case(DRAGONWIZARD_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_dragonstaff.mdl"); break;
						case(ARCHMAGE_CLASS):
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_crookstaff.mdl"); break;
						default:
							m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_crystalstaff.mdl"); break;
				}

				m_iIsDisguised=TRUE;

				g_engfuncs.pfnSetClientKeyValue(m_pPlayer->entindex(),g_engfuncs.pfnGetInfoKeyBuffer(m_pPlayer->edict()),"model",GetModelName());

				SetTeamColor(m_iDisguisedTeam);
			}
			else{
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Ice_NoEnemySeen");
				return;
			}
		}
	}
}
void CIceWizard::Think(){
	if(m_iIsInvisible){
		float t=(m_pPlayer->pev->velocity).Length();

		m_pPlayer->pev->rendermode=kRenderTransColor;

		t=t/(CVAR_GET_FLOAT("sv_maxspeed")*m_flPlayerSpeed);

		t=t*.4;

		if(m_pPlayer->pev->button&IN_ATTACK)
			t=t+.4;

		if(t>1.0)
			t=1.0;

		t=t*255.0;

		if(m_pPlayer->pev->renderamt>t)
			m_pPlayer->pev->renderamt-=8;

		if(m_pPlayer->pev->renderamt<t)
			m_pPlayer->pev->renderamt=t;

		if(m_flNextAmmoUse<=gpGlobals->time){
			if((m_pPlayer->pev->velocity).Length() != 0.0){
				if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<2){
					m_pPlayer->pev->renderamt=255;
					m_pPlayer->pev->rendermode=kRenderTransAlpha;
					m_iIsInvisible=FALSE;
				}
				else{
					m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=2;
					m_flNextAmmoUse=gpGlobals->time+.5;
				}
			}
		}
		if(m_pPlayer->m_pAttachedItem && m_pPlayer->m_pAttachedItem->m_iGoalResult&TFCGOAL_RESULT_RESETSPY){
			ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Ice_DisguiseWithItem");
			m_pPlayer->pev->renderamt=255;
			m_pPlayer->pev->rendermode=kRenderTransAlpha;
			m_iIsInvisible = FALSE;
			return;
		}

	}
	if(m_iIsDisguised){	//neo	
		switch(m_iDisguisedWizard)
		{
			case(LIFE_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_lifestaff.mdl"); break;
			case(FIRE_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_firestaff.mdl"); break;
			case(NATURE_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_stickstaff.mdl"); break;
			case(LIGHTNING_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_lightningstaff.mdl"); break;
			case(DEATH_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_scythestaff.mdl"); break;
			case(EARTH_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_quakestaff.mdl"); break;
			case(WIND_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_windstaff.mdl"); break;
			case(DRAGONWIZARD_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_dragonstaff.mdl"); break;
			case(ARCHMAGE_CLASS):
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_crookstaff.mdl"); break;
			default:
				m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_crystalstaff.mdl"); break;
				}
	}

	if(m_iIsDisguised&&m_pPlayer->pev->button&IN_ATTACK){
		ResetDisguise();
	}

	if(m_pPlayer->pev->health<=0){
		ResetDisguise();
	}	

	CBaseClass::Think();
}
void CIceWizard::ResetDisguise(){
	SetTeamColor(m_pPlayer->pev->team);
		
	m_iDisguisedTeam=m_pPlayer->pev->team;
	m_iDisguisedWizard=ICE_CLASS;
	strcpy(m_szDisguisedName,STRING(m_pPlayer->pev->netname));
	m_pPlayer->pev->weaponmodel = MAKE_STRING("models/staves/p_crystalstaff.mdl");

	g_engfuncs.pfnSetClientKeyValue(m_pPlayer->entindex(),g_engfuncs.pfnGetInfoKeyBuffer(m_pPlayer->edict()),"model",GetModelName());
		
	m_iIsDisguised=FALSE;
}
void CIceWizard::StatusReport(char *c){
	char status[128];
	char color[10];

	switch(m_iDisguisedTeam){
		case(1):{
			strcpy(color,"Blue");
			break;
		}
		case(2):{
			strcpy(color,"Red");
			break;
		}
		case(3):{
			strcpy(color,"Yellow");
			break;
		}
		case(4):{
			strcpy(color,"Green");
			break;
		}
		default:
			strcpy(color,"None");
	}

	sprintf(status,"Team:%s Wizard:%s Invis:",color,GetWizardName(m_iDisguisedWizard));

	if(m_iIsInvisible){
		strcat(status,"Yes");
	}
	else
		strcat(status,"No ");

	CBaseClass::StatusReport(status);
	strcat(c,status);
}
void CIceWizard::Remove(){
	m_pPlayer->pev->rendermode=kRenderTransAlpha;
	m_pPlayer->pev->renderamt=255;
}


CNatureWizard::CNatureWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.68;
	m_iMaxHealth=90;
	m_iMaxArmor=90;
	m_pBush[0]=NULL;
	m_pBush[1]=NULL;

	m_pStalk=NULL;

	m_iClassNumber=NATURE_CLASS;
}
void CNatureWizard::Equip(){
	GiveSpells();

	g_engfuncs.pfnSetClientMaxspeed( ENT( m_pPlayer->pev ), PlayerSpeed());

	CBaseClass::Equip();
}
void CNatureWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_thornblastspell");
	m_pPlayer->GiveNamedItem("weapon_beanstalkspell");
	m_pPlayer->GiveNamedItem("weapon_magicmisslespell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
}
void CNatureWizard::Think(){
	if(m_pBush[0]!=NULL&&m_pBush[0]->pev!=NULL&&m_pBush[0]->pev->solid==SOLID_NOT){
		m_pBush[0]=NULL;
	}

	if(m_pBush[1]!=NULL&&m_pBush[1]->pev!=NULL&&m_pBush[1]->pev->solid==SOLID_NOT){
		m_pBush[1]=NULL;
	}

	CBaseClass::Think();
}
void CNatureWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_bursatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CNatureWizard::DoSpecial(int slot){
	switch(slot){
		case(1):{
				if(!(m_pPlayer->pev->flags & FL_ONGROUND)){
					ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#NotOnGround");
					return;
				}

				if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<130){
					ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
					return;
				}

				int bushNum=-1;

				if((m_pBush[0]!=NULL && m_pBush[0]->pev->iuser1==2) || (m_pBush[1]!=NULL && m_pBush[1]->pev->iuser1==2)){
					ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_HaveStage3");
					return;
				}
				if(m_pBush[0]==NULL)
					bushNum=0;
				else if(m_pBush[1]==NULL)
					bushNum=1;

				if(bushNum==-1){
					ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_MoreThornplants");
					return;
				}
				else{
					if(MakeThornBush(bushNum)==1){
						m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=130;
					}
				}
				break;
		}
		case(2):{
				CBaseEntity *pBush=NULL,*pOldBush=NULL;
				
				while((pBush=UTIL_FindEntityInSphere(pBush,m_pPlayer->pev->origin,NATUREWIZARD_SEARCHRADIUS))!=NULL){
					if(FClassnameIs(pBush->pev,"monster_thornbush") && m_pPlayer->IRelationship(pBush)<0){
						if(pOldBush==NULL)
							pOldBush=pBush;

						if((pBush->pev->origin-m_pPlayer->pev->origin).Length()<(pOldBush->pev->origin-m_pPlayer->pev->origin).Length())
							pOldBush=pBush;
					}
				}

				if(pOldBush){
					int magic=150;

					if(pOldBush->pev->iuser1==1){
						magic=190;

						if(((CThornbush*)pOldBush)->m_hOwner){
							CNatureWizard* wiz=(CNatureWizard*)((CBasePlayer*)(CBaseEntity*)((CThornbush*)pOldBush)->m_hOwner)->m_pClass;		//Casting fun!

							if(wiz->m_pBush[0]!=NULL && wiz->m_pBush[1]!=NULL){
								ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_2PlantsFertilize");
								return;
							}
						}
					}
	
					if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<magic){
						ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
						return;
					}

					((CThornbush*)pOldBush)->Fertilize();
					m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=magic;
				}
				else{
					ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_NotCloseEnough");
				}

				break;
		}
		case(3):{
				CBaseEntity *pBush=NULL,*pOldBush=NULL;
				
				while((pBush=UTIL_FindEntityInSphere(pBush,m_pPlayer->pev->origin,NATUREWIZARD_SEARCHRADIUS))!=NULL){
					if(FClassnameIs(pBush->pev,"monster_thornbush") && (pBush==m_pBush[0] || pBush==m_pBush[1])){
						if(pOldBush==NULL)
							pOldBush=pBush;

						if((pBush->pev->origin-m_pPlayer->pev->origin).Length()<(pOldBush->pev->origin-m_pPlayer->pev->origin).Length())
							pOldBush=pBush;
					}
				}

				if(pOldBush){
					((CThornbush*)pOldBush)->Harvest();

					m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]+=pOldBush->pev->health/pOldBush->pev->max_health*100;

					if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]>200)
						m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]=200;
				}

				break;
		}
		case(4):{
				if(m_pBush[0]!=NULL)
					m_pBush[0]->Killed(m_pPlayer->pev,GIB_ALWAYS);
				break;
		}
		case(5):{
				if(m_pBush[1]!=NULL)
					m_pBush[1]->Killed(m_pPlayer->pev,GIB_ALWAYS);
				break;
		}
		case(6):{
				RemoveAllStalks();
				break;
		}
	}
}
int CNatureWizard::MakeThornBush(int bushNum){
	Vector temp;
	Vector m_bushPos;
	TraceResult TResult; 

	UTIL_MakeVectors( m_pPlayer->pev->v_angle );
		
	Vector v_for=gpGlobals->v_forward;
	v_for.z=0;v_for.Normalize();
	m_bushPos=m_pPlayer->GetGunPosition()+v_for*80;

	//Find the ground beneath the Bush
	temp.x=m_bushPos.x;
	temp.y=m_bushPos.y;
	temp.z=m_bushPos.z;
	temp.z=temp.z-96;

	UTIL_TraceLine( m_bushPos, temp, dont_ignore_monsters, ENT(m_pPlayer->pev), &TResult );

	if(TResult.vecEndPos.z==temp.z){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#OutOfRoom");
		return 0;
	}
	if(StalkRoom(TResult.vecEndPos)==2){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#OutOfRoom");
		return 0;
	}

	m_bushPos=TResult.vecEndPos;

	m_pBush[bushNum] = (CThornbush*) CBaseEntity::Create( "monster_thornbush", m_bushPos, Vector(0,1,0), m_pPlayer->edict() );
	m_pBush[bushNum]->pev->team=m_pPlayer->pev->team;

	return 1;
}

int CNatureWizard::StalkRoom(Vector stalkPos){
	Vector mins=stalkPos;
	Vector maxs=stalkPos;
	mins.x=mins.x-30;
	mins.y=mins.y-30;
	maxs.x=maxs.x+30;
	maxs.y=maxs.y+30;
	maxs.z=maxs.z+40;

	if(!UTIL_SearchArea(mins,maxs,5))
		return 2;

	return 1;
}

void CNatureWizard::RemoveBush(CThornbush* bush){
	if(m_pBush[0]==bush){
		UTIL_Remove(m_pBush[0]);
		m_pBush[0]=NULL;
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_BushKilled");
	}
	else if(m_pBush[1]==bush){
		UTIL_Remove(m_pBush[1]);
		m_pBush[1]=NULL;
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_BushKilled");
	}
	else UTIL_Remove(bush);
}
void CNatureWizard::AddStalk(CBeanstalk* stalk){
	m_pStalk=stalk;
}
void CNatureWizard::RemoveAllStalks(){
	if(m_pStalk){
		m_pStalk->RemoveMe();
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Nature_StalkKilled");
	}

	m_pStalk=NULL;
}
void CNatureWizard::StatusReport(char *c){
	char status[128];

	int health1=0,health2=0;

	if(m_pBush[0])
		health1=100*(m_pBush[0]->pev->health/m_pBush[0]->pev->max_health);
	if(m_pBush[1])
		health2=100*(m_pBush[1]->pev->health/m_pBush[1]->pev->max_health);

	sprintf(status,"Plant1:%%%%%d Plant2:%%%%%d Beanstalk:",health1,health2);

	if(m_pStalk!=NULL)
		strcat(status,"Yes ");
	else
		strcat(status,"No ");

	CBaseClass::StatusReport(status);
	strcat(c,status);
}
void CNatureWizard::Remove(){
	if(m_pBush[0]!=NULL&&m_pBush[0]->pev!=NULL)
		UTIL_Remove(m_pBush[0]);
	else
		m_pBush[0]=NULL;

	if(m_pBush[1]!=NULL&&m_pBush[1]->pev!=NULL)
		UTIL_Remove(m_pBush[1]);
	else
		m_pBush[1]=NULL;

	RemoveAllStalks();
}
int CNatureWizard::UpdateStatusBar(CBaseEntity *pEntity,char *buffer){
	if(FClassnameIs(pEntity->pev,"monster_thornbush") && ((CThornbush*)pEntity)->m_hOwner!=NULL && ((CThornbush*)pEntity)->m_hOwner->pev==m_pPlayer->pev){
		int	health=((float)pEntity->pev->health/(float)pEntity->pev->max_health)*100.0;

		if(m_pBush[0]==pEntity)
			sprintf(buffer,"Plant #1, Health: %d%%%%",health);
		else
			sprintf(buffer,"Plant #2, Health: %d%%%%",health);
	
		return 1;
	}

	return(CBaseClass::UpdateStatusBar(pEntity,buffer));
}


CLightningWizard::CLightningWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.60;
	m_iMaxHealth=90;
	m_iMaxArmor=90;

	m_iClassNumber=LIGHTNING_CLASS;
}
void CLightningWizard::Equip(){
	GiveSpells();

	CBaseClass::Equip();
}
void CLightningWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_spotboltspell");
	m_pPlayer->GiveNamedItem("weapon_lightningboltspell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
}
void CLightningWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_lightningsatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CLightningWizard::DoSpecial(int slot){
	if(m_pPlayer->m_iFOV==0)
		m_pPlayer->m_iFOV=25;
	else if(m_pPlayer->m_iFOV==25)
		m_pPlayer->m_iFOV=15;
	else
		m_pPlayer->m_iFOV=0;
}



CDeathWizard::CDeathWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.64;
	m_iMaxHealth=100;
	m_iMaxArmor=120;

	m_iClassNumber=DEATH_CLASS;
}
void CDeathWizard::Equip(){
	GiveSpells();

	m_iMadeSoul=0;

	CBaseClass::Equip();
}
void CDeathWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_magicmisslespell");
	m_pPlayer->GiveNamedItem("weapon_skullspell");
	m_pPlayer->GiveNamedItem("weapon_deathrayspell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
}
void CDeathWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_poisonsatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CDeathWizard::DoSpecial(int slot){
	if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<DEATHWIZARD_SPECIAL_COST){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
		return;
	}

	CBaseEntity* pBody=UTIL_FindEntityGeneric("bodyque",m_pPlayer->pev->origin,100);

	if(pBody && !(pBody->pev->effects & EF_NODRAW)){
		m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=DEATHWIZARD_SPECIAL_COST;

		pBody->pev->effects |= EF_NODRAW;

		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Death_DrawEnergy");

		EMIT_SOUND(ENT(m_pPlayer->pev), CHAN_BODY, "controller/con_pain2.wav", 1, ATTN_NORM);

		m_pPlayer->pev->health=m_iMaxHealth;
		m_pPlayer->m_bitsDamageType=0;
	}
	else{
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Death_NoBody");
	}
}
void CDeathWizard::Think(){
	if(m_pPlayer->pev->health<=0 && m_iMadeSoul==0){
		m_iMadeSoul=1;

		CBaseEntity *pEnt=CBaseEntity::Create("deathsoul",m_pPlayer->pev->origin,m_pPlayer->pev->angles,m_pPlayer->edict());
	}

	CBaseClass::Think();
}

extern int gmsgStatusIcon;

CEarthWizard::CEarthWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.65;
	m_iMaxHealth=100;
	m_iMaxArmor=135;
	m_iIsBear=FALSE;

	m_iClassNumber=EARTH_CLASS;
}
char * CEarthWizard::GetModelName(){
	if(m_iIsBear)
		return("bear");
	return ModelNames[EARTH_CLASS];
}
void CEarthWizard::Equip(){
	CBaseClass::Equip();

	BecomeWizard();
}
void CEarthWizard::ArmGrenade(){
	if(m_iIsBear){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Earth_BearSatchels");
		return;
	}

	CBaseClass::ArmGrenade();
}
void CEarthWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_earthquakesatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CEarthWizard::DoSpecial(int slot){
	switch(slot){
		case(1):{
			if(m_iIsBear){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Earth_IsBear");
				return;
			}

			if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<EARTHWIZARD_SPECIAL_COST){
				ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
				return;
			}
			m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=EARTHWIZARD_SPECIAL_COST;

			m_pPlayer->pev->rendermode=kRenderTransColor;
			m_pPlayer->pev->renderamt=254; //If this is less than 255, then the Think method will gradually decrease it to 0

			break;
		}
		case(2):{
			BecomeWizard();
			break;
		}
	}
}
void CEarthWizard::BecomeBear(){
	m_iIsBear=TRUE;
	m_flNextAmmoUse=0;

	g_engfuncs.pfnSetClientKeyValue(m_pPlayer->entindex(),g_engfuncs.pfnGetInfoKeyBuffer(m_pPlayer->edict()),"model",GetModelName());
	g_engfuncs.pfnSetClientMaxspeed(m_pPlayer->edict(),BEAR_SPEED*CVAR_GET_FLOAT("sv_maxspeed"));

	MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,m_pPlayer->pev);
		WRITE_BYTE(TRUE);
		WRITE_STRING("status_bear");
		WRITE_BYTE(255);
		WRITE_BYTE(255);
		WRITE_BYTE(255);
	MESSAGE_END();

	if(!m_pPlayer->IsAlive())
		return;

	m_pPlayer->RemoveAllItems(FALSE,FALSE);

	GiveSpells();

	EMIT_SOUND(m_pPlayer->edict(),CHAN_VOICE,"player/bear.wav",1,ATTN_NORM);

	m_pPlayer->pev->health=m_pPlayer->pev->health/m_pPlayer->pev->max_health;
	m_pPlayer->pev->max_health=200;
	m_pPlayer->pev->health=m_pPlayer->pev->health*m_pPlayer->pev->max_health;

	m_pPlayer->pev->armorvalue=m_pPlayer->pev->armorvalue/m_pPlayer->pev->armortype;
	m_pPlayer->pev->armortype=200;
	m_pPlayer->pev->armorvalue=m_pPlayer->pev->armorvalue*m_pPlayer->pev->armortype;
}
void CEarthWizard::BecomeWizard(){
	m_iIsBear=FALSE;

	m_pPlayer->pev->renderamt=255;
	g_engfuncs.pfnSetClientKeyValue(m_pPlayer->entindex(),g_engfuncs.pfnGetInfoKeyBuffer(m_pPlayer->edict()),"model",GetModelName());
	g_engfuncs.pfnSetClientMaxspeed(m_pPlayer->edict(),PlayerSpeed());

	MESSAGE_BEGIN(MSG_ONE,gmsgStatusIcon,NULL,m_pPlayer->pev);
		WRITE_BYTE(FALSE);
		WRITE_STRING("status_bear");
		WRITE_BYTE(255);
		WRITE_BYTE(255);
		WRITE_BYTE(255);
	MESSAGE_END();

	if(!m_pPlayer->IsAlive())
		return;

	m_pPlayer->RemoveAllItems(FALSE,FALSE);
	
	GiveSpells();

	m_pPlayer->pev->health=m_pPlayer->pev->health/m_pPlayer->pev->max_health;
	m_pPlayer->pev->max_health=m_iMaxHealth;
	m_pPlayer->pev->health=m_pPlayer->pev->health*m_pPlayer->pev->max_health;

	m_pPlayer->pev->armorvalue=m_pPlayer->pev->armorvalue/m_pPlayer->pev->armortype;
	m_pPlayer->pev->armortype=m_iMaxArmor;
	m_pPlayer->pev->armorvalue=m_pPlayer->pev->armorvalue*m_pPlayer->pev->armortype;
}
void CEarthWizard::GiveSpells(){
	if(m_iIsBear){
		m_pPlayer->GiveNamedItem("weapon_bearbite");
	}
	else{
		m_pPlayer->GiveNamedItem("weapon_staff");
		m_pPlayer->GiveNamedItem("weapon_rollingstonespell");
		m_pPlayer->GiveNamedItem("weapon_thornblastspell");
		m_pPlayer->GiveNamedItem("weapon_birdspell");
		m_pPlayer->GiveNamedItem("weapon_shieldspell");
	}
}
void CEarthWizard::Think(){
	if(m_iIsBear && m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<5 && m_pPlayer->IsAlive()){
		BecomeWizard();
	}

	if(m_iIsBear){
		if(m_flNextAmmoUse<=gpGlobals->time){
			m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=5;

			m_flNextAmmoUse=gpGlobals->time+2.5;
		}
	}

	if(m_pPlayer->pev->renderamt<255 && !m_iIsBear)
		m_pPlayer->pev->renderamt-=5;

	if(m_pPlayer->pev->renderamt<=0 && !m_iIsBear && m_pPlayer->IsAlive())
		BecomeBear();

	if(m_pPlayer->pev->renderamt<255 && m_iIsBear){
		m_pPlayer->pev->renderamt+=5;
		if(m_pPlayer->pev->renderamt>255)
			m_pPlayer->pev->renderamt=255;
	}

	CBaseClass::Think();
}


CWindWizard::CWindWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.75;
	m_iMaxHealth=80;
	m_iMaxArmor=80;

	m_iClassNumber=WIND_CLASS;
}
void CWindWizard::Equip(){
	GiveSpells();

	g_engfuncs.pfnSetPhysicsKeyValue(m_pPlayer->edict(),"windwizard","1");

	m_flNextCloneTime=0;
	CBaseClass::Equip();
}
void CWindWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_levitationspell");
	m_pPlayer->GiveNamedItem("weapon_mindmisslespell");
	m_pPlayer->GiveNamedItem("weapon_updraftspell");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
}
void CWindWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_suctionsatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CWindWizard::DoSpecial(int slot){
	if(!(m_pPlayer->pev->flags & FL_ONGROUND)){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Wind_AirClone");
		return;
	}

	if(m_pPlayer->pev->velocity.Length()<.5*CVAR_GET_FLOAT("sv_maxspeed")){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#Wind_SlowClone");
		return;
	}

	if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<WINDWIZARD_SPECIAL_COST){
		ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
		return;
	}

	if(m_flNextCloneTime>gpGlobals->time)
		return;
	m_flNextCloneTime=gpGlobals->time+WINDWIZARD_SPECIAL_DELAY;
	m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=WINDWIZARD_SPECIAL_COST;

	Vector temp=UTIL_VecToAngles(m_pPlayer->pev->velocity);
	int x=0;
	
	if(RANDOM_FLOAT(-1,1)>0.0)
		x=30;
	else
		x=-30;
	
	m_pPlayer->pev->angles.x=0;
	m_pPlayer->pev->v_angle.x=0;

	m_pPlayer->pev->v_angle.y=m_pPlayer->pev->angles.y+x;
	m_pPlayer->pev->angles=m_pPlayer->pev->v_angle;
	m_pPlayer->pev->fixangle=TRUE;
	UTIL_MakeVectors(m_pPlayer->pev->angles);
	m_pPlayer->pev->velocity=gpGlobals->v_forward*m_pPlayer->pev->velocity.Length();
	m_pPlayer->pev->velocity.z=0;
	
	temp.y=temp.y-x;
	CBaseEntity::Create("monster_wizardclone",m_pPlayer->pev->origin,temp,m_pPlayer->edict());
}
void CWindWizard::Think(){
	CBaseClass::Think();
}
void CWindWizard::Remove(){
	g_engfuncs.pfnSetPhysicsKeyValue(m_pPlayer->edict(),"windwizard","0");
}


CArchMage::CArchMage(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.54;
	m_iMaxHealth=60;
	m_iMaxArmor=40;

	m_iClassNumber=ARCHMAGE_CLASS;
}
void CArchMage::Equip(){
	GiveSpells();

	CBaseClass::Equip();
}
void CArchMage::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_cometspell");
	m_pPlayer->GiveNamedItem("weapon_magicmisslespell");
}
void CArchMage::MakeGrenade(Vector vecSrc,Vector vecThrow){
	m_pPlayer->TakeHealth(30,DMG_GENERIC);
	m_pPlayer->pev->armorvalue+=30;
	if(m_pPlayer->pev->armorvalue>m_pPlayer->pev->armortype)
		m_pPlayer->pev->armorvalue=m_pPlayer->pev->armortype;

	EMIT_SOUND(ENT(m_pPlayer->pev), CHAN_ITEM, "items/smallmedkit1.wav", 1, ATTN_NORM);
}
void CArchMage::DoSpecial(int slot){
}
void CArchMage::Think(){
	CBaseClass::Think();
}


CDragonWizard::CDragonWizard(CBasePlayer *pPlayer):CBaseClass(pPlayer){
	m_flPlayerSpeed=.6;
	m_iMaxHealth=100;
	m_iMaxArmor=110;

	m_iClassNumber=DRAGONWIZARD_CLASS;
}
void CDragonWizard::Equip(){
	GiveSpells();

	CBaseClass::Equip();
}
void CDragonWizard::GiveSpells(){
	m_pPlayer->GiveNamedItem("weapon_staff");
	m_pPlayer->GiveNamedItem("weapon_shieldspell");
	m_pPlayer->GiveNamedItem("weapon_doublemagicmisslespell");
	m_pPlayer->GiveNamedItem("weapon_dragonbreathspell");
	m_pPlayer->GiveNamedItem("weapon_wyvernspell");
}
void CDragonWizard::MakeGrenade(Vector vecSrc,Vector vecThrow){
	CBaseEntity *pGrenade=CBaseEntity::Create("proj_toothsatchel",vecSrc,vecThrow,m_pPlayer->edict());
	pGrenade->pev->dmgtime=m_flGrenadeTime;
}
void CDragonWizard::DoSpecial(int slot){
	if(slot==1){
//		if(m_pPlayer->pev->health>DRAGONWIZARD_SPECIAL_LIFE){
//			ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#HealthTooHigh");
//			return;
//		}
		if(m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]<DRAGONWIZARD_SPECIAL_COST){
			ClientPrint(m_pPlayer->pev,HUD_PRINTCENTER,"#LowOnMagic");
			return;
		}
		m_pPlayer->m_rgAmmo[m_pPlayer->GetAmmoIndex("uranium")]-=DRAGONWIZARD_SPECIAL_COST;

		float flAmount=(m_pPlayer->pev->max_health-m_pPlayer->pev->health)/m_pPlayer->pev->max_health;

		MESSAGE_BEGIN( MSG_PAS, SVC_TEMPENTITY, m_pPlayer->pev->origin );
			WRITE_BYTE( TE_EXPLOSION );		// This makes a dynamic light and the explosion sprites/sound
			WRITE_COORD( m_pPlayer->pev->origin.x );	// Send to PAS because of the sound
			WRITE_COORD( m_pPlayer->pev->origin.y );
			WRITE_COORD( m_pPlayer->pev->origin.z );
			WRITE_SHORT( g_sModelIndexFireball );
			WRITE_BYTE( 80*flAmount ); // scale * 10
			WRITE_BYTE( 15  ); // framerate
			WRITE_BYTE( TE_EXPLFLAG_NONE );
		MESSAGE_END();

		EMIT_SOUND(m_pPlayer->edict(),CHAN_VOICE,"ambience/biggun3.wav",1,ATTN_NORM);

		m_pPlayer->TakeDamage(VARS(INDEXENT(0)),VARS(INDEXENT(0)),1000,DMG_CRUSH);

		RadiusDamage(m_pPlayer->pev->origin,m_pPlayer->pev,m_pPlayer->pev,DRAGONWIZARD_SPECIAL_STRENGTH*flAmount,DRAGONWIZARD_SPECIAL_STRENGTH*flAmount,CLASS_NONE,DMG_BURN|DMG_BLAST);
	}
}
void CDragonWizard::Think(){
	CBaseClass::Think();
}
//END