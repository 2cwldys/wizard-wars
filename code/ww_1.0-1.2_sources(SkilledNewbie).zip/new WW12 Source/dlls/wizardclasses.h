/*
	wizardclasses.h : represent character classes

	By: Alan Fischer

	Thanks to : Blake Grant for the idea and some basic code

	For the WizWars mod
*/

#include "wizardwarsdefs.h"

class CThornbush;
class CTFCGoal;
class CBeanstalk;

class ClassLimits{
public:
	ClassLimits();
	
	void SetConclaveLimits(int team,unsigned int limits){
		for(int i=0;i<MAX_CLASSES;i++){
			if((1<<ClassConclave[i])&limits)
				m_iClassLimits[team]|=1<<i;
		}
	}
	
	void SetClassLimits(int team,unsigned int limits){
		m_iClassLimits[team]=limits;
	}

	int IsValidClass(int team,unsigned int limits){
		return m_iClassLimits[team]&(1<<limits);
	}

	int GetClassLimits(int team){
		return m_iClassLimits[team];
	}

private:
	unsigned int m_iClassLimits[5];
};

class CBaseClass {
public:
	CBaseClass(CBasePlayer *pPlayer);
	static CBaseClass* GetRandomClass(CBasePlayer *pPlayer);
	static CBaseClass* GetNumberedClass(CBasePlayer *pPlayer,int number);
	static char* GetWizardName(int num);
	static char* GetWizardModel(int num);

	void StopForTime(float time);
	void SetTeamColor(int team);
	
	virtual int PlayerSpeed();
	virtual void TossGrenade();
	virtual void ArmGrenade();
	virtual char* GetModelName();
	virtual void Equip();
	virtual void Think();
	virtual void MakeGrenade(Vector vecSrc, Vector vecThrow);
	virtual void DoSpecial(int slot);
	virtual void StatusReport(char *c);
	virtual void GiveSpells();
	virtual void Remove();
	virtual int UpdateStatusBar(CBaseEntity *pEntity,char *buffer);

	CBasePlayer *m_pPlayer;
	float m_flPlayerSpeed;
	BOOL m_iGrenadeArmed;
	BOOL m_iForceGrenadeToss;
	float m_flGrenadeTime;
	int m_iMaxHealth;
	int m_iMaxArmor;

	float m_flPlayerStopTime;
	BOOL m_iPlayerStopped;

	int m_iClassNumber;
};

class CLifeWizard:public CBaseClass{
public:
	CLifeWizard(CBasePlayer *pPlayer);
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void Think();
	void GiveSpells();
	int UpdateStatusBar(CBaseEntity *pEntity,char *buffer);

	float m_flNextHealthGain;
	int m_iMadeSoul;
	int m_iSacrificeKill;
};

class CFireWizard:public CBaseClass{
public:
	CFireWizard(CBasePlayer *pPlayer);
	void Equip();
	void DoSpecial(int slot);
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void GiveSpells();
};

class CIceWizard:public CBaseClass{
public:
	CIceWizard(CBasePlayer *pPlayer);
	char* GetModelName();
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void Think();
	void ResetDisguise();
	void StatusReport(char *c);
	void GiveSpells();
	void Remove();

	int m_iSecondMenu;
	int m_iIsInvisible;
	int m_iIsDisguised;
	int m_iDisguisedWizard;
	int m_iDisguisedTeam;
	char m_szDisguisedName[128];
	float m_flNextAmmoUse;
//	EHANDLE m_hStaff;
};

class CNatureWizard:public CBaseClass{
public:
	CNatureWizard(CBasePlayer *pPlayer);
	void Equip();
	void Think();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	int MakeThornBush(int bushNum);
	int StalkRoom(Vector stalkPos);
	void AddStalk(CBeanstalk* pStalk);
	void RemoveBush(CThornbush* bush);
	void RemoveAllStalks();
	void StatusReport(char* c);
	void GiveSpells();
	void Remove();
	int UpdateStatusBar(CBaseEntity *pEntity,char *buffer);

	CThornbush *m_pBush[2];

	CBeanstalk *m_pStalk;
};

class CLightningWizard:public CBaseClass{
public:
	CLightningWizard(CBasePlayer *pPlayer);
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void GiveSpells();
};

class CDeathWizard:public CBaseClass{
public:
	CDeathWizard(CBasePlayer *pPlayer);
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void Think();
	void GiveSpells();

	int m_iMadeSoul;
};

class CEarthWizard:public CBaseClass{
public:
	CEarthWizard(CBasePlayer *pPlayer);
	char *GetModelName();
	void Equip();
	void ArmGrenade();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void BecomeBear();
	void BecomeWizard();
	void Think();
	void GiveSpells();

	BOOL m_iIsBear;
	float m_flNextAmmoUse;
};

class CWindWizard:public CBaseClass{
public:
	CWindWizard(CBasePlayer *pPlayer);
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void Think();
	void GiveSpells();
	void Remove();

	float m_flNextCloneTime;
};

class CArchMage:public CBaseClass{
public:
	CArchMage(CBasePlayer *pPlayer);
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void Think();
	void GiveSpells();
};

class CDragonWizard:public CBaseClass{
public:
	CDragonWizard(CBasePlayer *pPlayer);
	void Equip();
	void MakeGrenade(Vector vecSrc,Vector vecThrow);
	void DoSpecial(int slot);
	void Think();
	void GiveSpells();
};