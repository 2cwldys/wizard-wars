#define TFCGOAL_ACTIVATION_TOUCH			1
#define TFCGOAL_ACTIVATION_FISSURE			2
#define TFCGOAL_ACTIVATION_REVERSE_AP		4
#define TFCGOAL_ACTIVATION_MINDMISSLE		8

#define TFCITEM_ACTIVATION_GLOW				1   // Players carrying this GoalItem will glow
#define TFCITEM_ACTIVATION_SLOW				2   // Players carrying this GoalItem will move at half-speed
#define TFCITEM_ACTIVATION_DROP				4   // Players dying with this item will drop it
#define TFCITEM_ACTIVATION_RETURN_DROP		8   // Return if a player with it dies
#define TFCITEM_ACTIVATION_RETURN_GOAL		16  // Return if a player with it has it removed by a goal's activation
#define TFCITEM_ACTIVATION_RETURN_REMOVE	32  // Return if it is removed by TFCITEM_ACTIVATION_REMOVE
#define TFCITEM_ACTIVATION_REVERSE_AP		64  // Only pickup if the player _doesn't_ match AP Details
#define TFCITEM_ACTIVATION_REMOVE			128 // Remove if left untouched for 2 minutes after being dropped
#define TFCITEM_ACTIVATION_KEEP				256 // Players keep this item even when they die
#define TFCITEM_ACTIVATION_ITEMGLOWS		512	// Item glows when on the ground
#define TFCITEM_ACTIVATION_DONTREMOVERES	1024 // Don't remove results when the item is removed
#define TFCITEM_ACTIVATION_CANCARRY			4096

#define TFCGOAL_EFFECT_AP					1  // AP is affected. Default.
#define TFCGOAL_EFFECT_AP_TEAM				2  // All of the AP's team.
#define TFCGOAL_EFFECT_NOT_AP_TEAM			4  // All except AP's team.
#define TFCGOAL_EFFECT_NOT_AP				8  // All except AP.
#define TFCGOAL_EFFECT_WALL					16 // If set, walls stop the Radius effects
#define TFCGOAL_EFFECT_SAME_ENVIRONMENT		32 // If set, players in a different environment to the Goal are not affected
#define TFCGOAL_EFFECT_TIMER_CHECK_AP		64 // If set, Timer Goals check their critera for all players fitting their effects

#define TFCGOAL_RESULT_SINGLE				1
#define TFCGOAL_RESULT_ENDGAME				4
#define TFCGOAL_RESULT_RESETSPY				16
#define TFCGOAL_RESULT_RESPAWN				32
#define TFCGOAL_RESULT_DESTROYPLANTS		64
#define TFCGOAL_RESULT_ITEMGLOWS			512

#define TFCGOAL_ACTIVE						1
#define TFCGOAL_INACTIVE					2
#define TFCGOAL_REMOVED						3
#define TFCGOAL_WAITING						-1

#define TFCGOAL_HUD_YELLOW			32768
#define TFCGOAL_HUD_GREEN				65536
#define TFCGOAL_HUD_BLUE				131072
#define TFCGOAL_HUD_RED					262144
#define TFCGOAL_HUD_INVIS				524288
#define TFCGOAL_HUD_INVUN				1048576
#define TFCGOAL_HUD_SUIT				2097152
#define TFCGOAL_HUD_QUAD				4194304

#define CLASSLIMITS_LIFE	16
#define CLASSLIMITS_FIRE	32
#define CLASSLIMITS_ICE 	256
#define CLASSLIMITS_NATURE	512
#define CLASSLIMITS_LIGHTNING	2
#define CLASSLIMITS_DEATH	4
#define CLASSLIMITS_RANDOM	128
#define CLASSLIMITS_EARTH	8
#define CLASSLIMITS_WIND	1
#define CLASSLIMITS_ARCHMAGE	1024
#define CLASSLIMITS_DRACOMANCER	64

#define TFCCLASS_WHITE		1
#define TFCCLASS_RED		2
#define TFCCLASS_BLUE		3
#define TFCCLASS_GREEN		4	
#define TFCCLASS_YELLOW		5
#define TFCCLASS_BLACK		6
#define TFCCLASS_BROWN		7
#define TFCCLASS_PURPLE		8
#define TFCCLASS_ORANGE		9


class CTFCGoal : public CBaseToggle{
public:
	void GenericSpawn();
	void Spawn(void);
	void Precache(void);
	virtual void KeyValue(KeyValueData *pkvd);
	virtual void Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value);
	void StartGoal();
	void EXPORT PlaceGoal();
	void SetupRespawn();
	void EXPORT DoRespawn();
	void EXPORT GoalTouch(CBaseEntity *pEnt);
};

class CTFCItem:public CTFCGoal{
public:
	void Spawn(void);
	void Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value);
	void StartItem();
	void EXPORT PlaceItem();
	void DropFromPlayer(int method=0);
	void EXPORT ReturnItem();
	void EXPORT DropItem();
	void EXPORT RemoveItem();
	void CheckGoalReturn();
	void AttachToPlayer(CBasePlayer* pPlayer);
	void EXPORT DropThink();
	void EXPORT SpinThink();
	void EXPORT ItemTouch(CBaseEntity *pOther);
};

class CTFCTimer:public CTFCGoal{
public:
	void Spawn(void);
	void KeyValue(KeyValueData *pkvd);
	void Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value);
	void StartTimer();
	void EXPORT PlaceTimer();
	void EXPORT TimerThink();
};

EXPORT CBaseEntity *FindEntityByGoal(int goal);

class CTFCTeamcheck:public CPointEntity{
public:
	void Spawn(void);
	void KeyValue(KeyValueData *pkvd);
	void EXPORT ModifyTeamchecks();
};

class CTFCTeamset:public CPointEntity{
public:
	void Spawn(void);
	void KeyValue(KeyValueData *pkvd);
	void Use(CBaseEntity *pActivator,CBaseEntity *pCaller,USE_TYPE useType,float value);
};