/* beanstalk.h

   Header file for beanstalk.cpp

   By:  Alan Fischer
*/

class CBeanstalk : public CBaseMonster
{
public:
	void Spawn( void );
	void Precache( void );

	int		Save( CSave &save );
	int		Restore( CRestore &restore );
	static	TYPEDESCRIPTION m_SaveData[];

	void Killed(entvars_t *pevAttacker, int iGib);
	EXPORT void StalkThink();
	void RemoveMe();

	float		m_flFadeInTime;
	float		m_flNextHealthGain;

	EHANDLE		m_hOwner;
	EHANDLE		m_hNextStalk;
};