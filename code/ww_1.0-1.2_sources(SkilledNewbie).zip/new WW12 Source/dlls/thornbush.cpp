/*
	Thornbush.cpp
	By: Alan Fischer
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "thornbush.h"
#include "wizardwarsdefs.h"

// Define all constants here
#define THORNBUSH_HEALTH				200
#define THORNBUSH_HEALTHTIME			5
#define THORNBUSH_DISTANCE				810
#define THORNBUSH_MINS					-20,-20,0
#define THORNBUSH_MAXS					20,20,80

int ThornbushStats[3][3]={
	{
		13,10,200,
	},
	{
		15,11,250,
	},
	{
		20,13,300,
	},
};

extern int g_iTeams;

#define SPORE_HEALTH	20
#define SPORE_DAMAGE	100
#define SPORE_RADIUS	200

class CSporePod:public CBaseMonster{
public:
	void Spawn(){
		Precache();

		SET_MODEL(ENT(pev),"models/spore.mdl");
		UTIL_SetSize(pev,Vector(0,0,0),Vector(0,0,0));
		pev->solid=SOLID_BBOX;
		pev->movetype=MOVETYPE_FLY;
		pev->health=SPORE_HEALTH;
		pev->framerate=4;

		SetTouch(PodTouch);
		SetThink(PodThink);

		UTIL_SetOrigin(pev,pev->origin);

		ResetSequenceInfo();

		pev->dmgtime=gpGlobals->time+10;
		pev->nextthink=gpGlobals->time+.1;
	}

	void Precache(){
		PRECACHE_MODEL("models/spore.mdl");

		m_usSporeExplode=PRECACHE_EVENT(1,"events/sporepodfire.sc");
	}

	void EXPORT PodThink(){
		StudioFrameAdvance();

		if(pev->dmgtime<gpGlobals->time)
			UTIL_Remove(this);
		
		pev->nextthink=gpGlobals->time+.1;
	}

	void EXPORT PodTouch(CBaseEntity *pOther){
		if(m_hOwner)
			::RadiusDamage(pev->origin,pev,m_hOwner->pev,SPORE_DAMAGE,SPORE_RADIUS,0,DMG_POISON);
		else
			::RadiusDamage(pev->origin,pev,pev,SPORE_DAMAGE,SPORE_RADIUS,0,DMG_POISON);

		PLAYBACK_EVENT(0,edict(),m_usSporeExplode);

		UTIL_Remove(this);
	}

	unsigned short m_usSporeExplode;

	EHANDLE m_hOwner;
};
LINK_ENTITY_TO_CLASS(proj_sporepod,CSporePod);

void CThornbush::GrowUp(){
	StudioFrameAdvance();
	
	pev->effects&= ~EF_NODRAW;//Make it visible again

	if(g_iTeams==0 && CVAR_GET_FLOAT("mp_allowdmthorns")==0){
		Killed(pev,1);
		if(m_hOwner!=NULL)
			ClientPrint(m_hOwner->pev,HUD_PRINTCENTER,"#NoThornplantsInDM");
	}

	if(m_fSequenceFinished){//We're grown up!
		pev->sequence=1;

		pev->frame=0;
		ResetSequenceInfo();
		
		SetThink(WatchOut);
		SetTouch(TakeThis);
	}

	pev->nextthink = gpGlobals->time + 0.1;
}

void CThornbush::GrowDown(){
	StudioFrameAdvance();

	if(m_fSequenceFinished){
		pev->iuser1--;

		if(pev->iuser1<0)
			Killed(pev,GIB_ALWAYS);
		else{
			if(pev->iuser1==0)
				SET_MODEL(ENT(pev),"models/thornbush1.mdl");
			else
				SET_MODEL(ENT(pev),"models/thornbush2.mdl");

			pev->max_health=ThornbushStats[pev->iuser1][2];
			if(pev->health>pev->max_health)
				pev->health=pev->max_health;

			SetThink(WatchOut);
			SetTouch(TakeThis);
		}
	}

	pev->nextthink=gpGlobals->time+0.1;
}

void CThornbush::WatchOut(){
	StudioFrameAdvance();
	
	BOOL seeEnemy=FALSE;

	if(m_hEnemy!=NULL && (m_hEnemy->BodyTarget(pev->origin+pev->view_ofs)-pev->origin-pev->view_ofs).Length()>THORNBUSH_DISTANCE+50)
		m_hEnemy=NULL;

	if (m_hEnemy!=NULL && FVisible(m_hEnemy) && m_hEnemy->IsAlive() && m_hEnemy->pev->takedamage){
		Vector temp;
		
		m_vecEnemyLKP=m_hEnemy->BodyTarget(pev->origin+pev->view_ofs);
		vecToEnemy=(m_vecEnemyLKP-pev->origin-pev->view_ofs).Normalize();

		temp=UTIL_VecToAngles(vecToEnemy);
		pev->angles.y=temp.y;
		pev->angles.z=temp.z;

		//Shoot at the enemy
		if(pev->dmgtime<=gpGlobals->time){
			if(m_hOwner!=NULL)
				Shoot(pev->origin+pev->view_ofs,vecToEnemy,ThornbushStats[pev->iuser1][0],m_iDamageBits,m_hOwner->pev);
			else
				Shoot(pev->origin+pev->view_ofs,vecToEnemy,ThornbushStats[pev->iuser1][0],m_iDamageBits,pev);

			pev->dmgtime=gpGlobals->time+.2;
		}

		seeEnemy=TRUE;
	}

	else{//Find something else
		Look(THORNBUSH_DISTANCE);
		m_hEnemy=BestVisibleEnemy();
		if(m_hEnemy!=NULL && m_hEnemy->IsAlive() && m_hEnemy->pev->takedamage){
			m_fSequenceFinished=1;
			seeEnemy=TRUE;
		}

	}

	//Change sequences if needed
	if(m_fSequenceFinished){
		if ( seeEnemy ){
			pev->sequence=6;
		}
		else{
			pev->sequence=RANDOM_LONG(1,5);
		}
		pev->frame=0;

		ResetSequenceInfo();
	}

	//Gain some health
	if(m_flNextHealthGain<=gpGlobals->time&&pev->health<pev->max_health){
		int health=((float)Illumination()/255.0)*20;
		
		TakeHealth(min(health,pev->max_health),DMG_GENERIC);
		m_flNextHealthGain=gpGlobals->time+THORNBUSH_HEALTHTIME;
	}

	//Make sure we are not floating
	TraceResult tr;
	Vector vecEnd=pev->origin;
	vecEnd.z-=10;

	UTIL_TraceLine(pev->origin,vecEnd,dont_ignore_monsters,dont_ignore_glass,edict(),&tr);
	
	if(tr.flFraction==1.0){//We're floating
		if(m_hOwner!=NULL)
			Killed(m_hOwner->pev,TRUE);
		else
			Killed(pev,TRUE);
	}

	pev->nextthink = gpGlobals->time + 0.1;
}

extern int gmsgDeathMsg;

void CThornbush::Killed(entvars_t *pevAttacker, int iGib){
	if(IRelationship(Instance(pevAttacker))>0 && FBitSet(pevAttacker->flags,FL_CLIENT)){
		pevAttacker->frags++;
	
		MESSAGE_BEGIN(MSG_ALL,gmsgDeathMsg);
			WRITE_BYTE(ENTINDEX(ENT(pevAttacker)));
			WRITE_BYTE(-1);
			WRITE_STRING("thornbush");
		MESSAGE_END();
	}
	else if(IRelationship(Instance(pevAttacker))<0 && m_hOwner!=NULL && pevAttacker!=m_hOwner->pev && FBitSet(pevAttacker->flags,FL_CLIENT)){
		pevAttacker->frags--;
		ClientPrint(pevAttacker,HUD_PRINTCENTER,"#GoodThornplant");
	}
	
	MESSAGE_BEGIN( MSG_PVS, SVC_TEMPENTITY, pev->origin );
		WRITE_BYTE( TE_BREAKMODEL);
		WRITE_COORD( pev->origin.x );
		WRITE_COORD( pev->origin.y );
		WRITE_COORD( pev->origin.z );
		WRITE_COORD( pev->size.x);
		WRITE_COORD( pev->size.y);
		WRITE_COORD( pev->size.z);
		WRITE_COORD( 0 ); 
		WRITE_COORD( 0 );
		WRITE_COORD( 20 );
		WRITE_BYTE( 10 );
		WRITE_SHORT(m_iChunks);//model id#
		WRITE_BYTE( 8 );//# of chunks
		WRITE_BYTE( 50 );//Lifetime
		WRITE_BYTE( 0 );
	MESSAGE_END();
	
	if(m_hOwner!=NULL && ((CBasePlayer*)(CBaseEntity*)m_hOwner)->m_pClass && m_hOwner->pev->playerclass==NATURE_CLASS)
		((CNatureWizard*)((CBasePlayer*)(CBaseEntity*)m_hOwner)->m_pClass)->RemoveBush(this);
	else{
		CBaseEntity::Killed(pevAttacker,iGib);
	}
}

void CThornbush :: Spawn( void )
{
	Precache( );

	SET_MODEL(ENT(pev), "models/thornbush1.mdl");

	pev->sequence=0; //Start small
	pev->frame = 0;
	pev->effects=EF_NODRAW;//HACK:  Make it invisible until it passes the 1st frame
	pev->classname=MAKE_STRING("monster_thornbush");

	pev->movetype = MOVETYPE_NONE;
	pev->solid = SOLID_BBOX;
	pev->flags |= FL_MONSTER;
	pev->takedamage = DAMAGE_YES;
	pev->max_health = THORNBUSH_HEALTH;
	pev->health = pev->max_health;
	pev->view_ofs=Vector(0,0,50);

	m_flNextHealthGain=0;
	m_flFieldOfView=-1;
	m_iDamageBits=DMG_GENERIC;
	m_hEnemy=NULL;

	UTIL_SetSize(pev,Vector(THORNBUSH_MINS),Vector(THORNBUSH_MAXS));

	//Make it solid
	if(pev->owner){
		m_hOwner=(CBasePlayer*)CBaseEntity::Instance(pev->owner);
		pev->owner=NULL;

		pev->skin=m_hOwner->pev->team;
	}

	UTIL_SetOrigin( pev, pev->origin );

	SetThink(GrowUp);
	SetTouch(NULL);

	ResetSequenceInfo();

	pev->nextthink=gpGlobals->time+.3;
}

void CThornbush ::TakeThis(CBaseEntity *pOther){
	if(IRelationship(pOther)>=0)
		if(m_hOwner!=NULL)
			pOther->TakeDamage(pev,m_hOwner->pev,ThornbushStats[pev->iuser1][1],0);
		else
			pOther->TakeDamage(pev,pev,ThornbushStats[pev->iuser1][1],0);
}

void CThornbush :: Precache( void ){
	PRECACHE_MODEL("models/thornbush1.mdl");
	PRECACHE_MODEL("models/thornbush2.mdl");
	PRECACHE_MODEL("models/thornbush3.mdl");
	PRECACHE_MODEL("sprites/xspark3.spr");
	m_iChunks=PRECACHE_MODEL("models/tpgibs.mdl");
	m_usThornbushUpgrade=PRECACHE_EVENT(1,"events/thornbushupgrade.sc");

	PRECACHE_SOUND("zombie/claw_strike3.wav");

	UTIL_PrecacheOther("proj_sporepod");
}

void CThornbush::Fertilize(){
	int b=0;

	if(pev->sequence==0)
		return;
	
	if(pev->iuser1==0){
		pev->iuser1=1;
		SET_MODEL(ENT(pev),"models/thornbush2.mdl");
		b=TRUE;
	}
	else if(pev->iuser1==1){
		pev->iuser1=2;
		SET_MODEL(ENT(pev),"models/thornbush3.mdl");
		b=TRUE;
	}

	if(b){
		UTIL_SetSize(pev,Vector(THORNBUSH_MINS),Vector(THORNBUSH_MAXS));
		pev->sequence=0;
		pev->frame=0;
		pev->effects&=EF_NODRAW;
		SetThink(GrowUp);
		SetTouch(NULL);
		ResetSequenceInfo();
		pev->nextthink=gpGlobals->time+.3;
	}

	PLAYBACK_EVENT(0,edict(),m_usThornbushUpgrade);

	pev->max_health=ThornbushStats[pev->iuser1][2];
	pev->health=pev->max_health;
}

void CThornbush::Harvest(){
	pev->sequence=7;
	ResetSequenceInfo();
	SetThink(GrowDown);
	pev->nextthink=gpGlobals->time+.1;
}

void CThornbush::Shoot( Vector vecSrc, Vector vecDirShooting, int iDamage, int iDamageBits, entvars_t* pevAttacker){
	TraceResult tr;

	ClearMultiDamage();

	Vector vecEnd;
	vecEnd = Vector(vecSrc + vecDirShooting * 4096);

	UTIL_TraceLine(vecSrc, vecEnd, dont_ignore_monsters, ENT(pev), &tr);

	CBaseEntity *pEntity = CBaseEntity::Instance(tr.pHit);

	if(pEntity){
		if(pev->impulse)
			iDamage*=1.2;
		
		pEntity->TraceAttack(pevAttacker, iDamage, vecDirShooting, &tr, DMG_BULLET|iDamageBits);
		EMIT_SOUND_DYN(ENT(pEntity->pev),CHAN_VOICE,"zombie/claw_strike3.wav",1,ATTN_NORM,0,150);

		if(pev->impulse==2)
			pEntity->pev->punchangle=Vector(RANDOM_FLOAT(-20,20),RANDOM_FLOAT(-20,20),RANDOM_FLOAT(-20,20));
		if(pev->impulse==4)
			pEntity->pev->velocity=pEntity->pev->velocity+Vector(RANDOM_FLOAT(-60,60),RANDOM_FLOAT(-60,60),RANDOM_FLOAT(0,60));
	}

	ApplyMultiDamage(pev, pevAttacker);

	UTIL_BubbleTrail(vecSrc,tr.vecEndPos,1);

	if(m_flSporeTime<gpGlobals->time && pev->iuser1==2){
		CSporePod *pPod=(CSporePod*)CBaseEntity::Create("proj_sporepod",vecSrc,pev->angles,edict());
		pPod->m_hOwner=m_hOwner;
		pPod->pev->team=pev->team;
		pPod->pev->velocity=vecDirShooting*800;
		m_flSporeTime=gpGlobals->time+1;
	}
}

int CThornbush::TakeDamage( entvars_t* pevInflictor, entvars_t* pevAttacker, float flDamage, int bitsDamageType ){
	if(IRelationship(Instance(pevAttacker))>0)
		m_hEnemy=Instance(pevAttacker);

	if(FClassnameIs(pevInflictor,"proj_sporepod"))
		return 0;

	if(IRelationship(Instance(pevAttacker))<0){
		return CBaseMonster::TakeDamage(pevInflictor,pevAttacker,flDamage/10,bitsDamageType);
	}
	else{
		return CBaseMonster::TakeDamage(pevInflictor,pevAttacker,flDamage,bitsDamageType);
	}
}

int CThornbush::IRelationship(CBaseEntity *pTarget){
	if ((pTarget->pev->team != 0 && (pTarget->pev->team != pev->team)) ||
		(pTarget->pev->team == 0) && (pTarget->pev->owner != pev->owner))
	{
		if(FClassnameIs(pTarget->pev,"monster_giantplant"))
			return R_HT;

		else if(pTarget->IsPlayer())
			return R_NM;
	}

	if(pTarget && ENT(pTarget->pev)==pev->owner)
		return(R_AL);

	if(pTarget->pev->owner == pev->owner)
		return R_AL;

	if(pTarget->IsPlayer() && pTarget->pev->playerclass==ICE_CLASS){
		CBasePlayer* pl=((CBasePlayer*)pTarget);
		CIceWizard* bw=((CIceWizard*)pl->m_pClass);

		if(bw->m_iIsInvisible==TRUE && pTarget->pev->renderamt<20)
			return R_NO;

		if(pev->team!=0 && bw->m_iDisguisedTeam==pev->team)
			return R_NO;
	}
	if(!pTarget->IsPlayer())
		return R_AL;

	return(CBaseMonster::IRelationship(pTarget));
}

void CThornbush::Enchant(int playerclass){
	if(playerclass==FIRE_CLASS){
		pev->renderfx=kRenderFxGlowShell;
		pev->rendercolor.x=255;
		pev->rendercolor.y=0;
		pev->rendercolor.z=0;
		pev->impulse=1;
		m_iDamageBits=DMG_BURN|DMG_SLOWBURN;
	}
	if(playerclass==ICE_CLASS){
		pev->renderfx=kRenderFxGlowShell;
		pev->rendercolor.x=0;
		pev->rendercolor.y=0;
		pev->rendercolor.z=255;
		pev->impulse=2;
		m_iDamageBits=DMG_FREEZE;
	}
	if(playerclass==LIGHTNING_CLASS){
		pev->renderfx=kRenderFxGlowShell;
		pev->rendercolor.x=255;
		pev->rendercolor.y=255;
		pev->rendercolor.z=0;
		pev->impulse=3;
		m_iDamageBits=DMG_SHOCK;
	}
	if(playerclass==WIND_CLASS){
		pev->renderfx=kRenderFxGlowShell;
		pev->rendercolor.x=128;
		pev->rendercolor.y=0;
		pev->rendercolor.z=255;
		pev->impulse=4;
	}
}
LINK_ENTITY_TO_CLASS( monster_thornbush, CThornbush );