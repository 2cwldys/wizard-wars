/***
*
*	Copyright (c) 1999, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//
// wizardwars_gamerules.cpp
//
// Author: Alan Fischer

#include	"extdll.h"
#include	"util.h"
#include	"cbase.h"
#include	"player.h"
#include	"weapons.h"
#include	"gamerules.h"
#include	"teamplay_gamerules.h"
#include	"wizardwars_gamerules.h"
#include	"game.h"
#include	"time.h"

#include	"thornbush.h"
#include	"tfcentities.h"
#include	"monsters/dragon.h"
#include	"wizardwarsdefs.h"

static char team_names[MAX_TEAMS][MAX_TEAMNAME_LENGTH];
static int team_scores[MAX_TEAMS];
static int num_teams=0;

static unsigned char WWAuthors[28]="Alan Fischer\nAndrew Fischer";

extern DLL_GLOBAL BOOL		g_fGameOver;

extern int gmsgWeather;
extern int g_iWeatherType;
extern int g_iWeatherStrength;
extern int g_iTeams;
extern int g_iMaxOnTeam[5];
extern int g_iMinForTeam[5];
extern ClassLimits *g_pClassLimits;
extern int g_iTeamScore[5];
extern int g_iTeamLives[5];

extern int giAmmoIndex;
extern short g_sSacrificeSprite;
extern unsigned short g_usGibs;
extern unsigned short g_usDeathFlash;
extern unsigned short g_usBurn;
extern unsigned short g_usSpark;
extern unsigned short g_usTaunt;

char g_szWorldName[64];
int g_iWorldX;
int g_iWorldY;
//enginefuncs_t g_engfs;

#define VGUI

void SetPlayerMusic(CBasePlayer *pPlayer,char *music);

CWizardWarsGameplay :: CWizardWarsGameplay()
{
	m_DisableDeathMessages = FALSE;
	m_DisableDeathPenalty = FALSE;

	memset( team_names, 0, sizeof(team_names) );
	memset( team_scores, 0, sizeof(team_scores) );
	num_teams = 0;

	edict_t *pWorld = INDEXENT(0);

	RecountTeams();

	m_iYuckSprite=PRECACHE_MODEL("sprites/yuck.spr");
	m_iArrowSprite=PRECACHE_MODEL("sprites/arrow.spr");
	
	g_sSacrificeSprite=PRECACHE_MODEL("sprites/blueflare1.spr");
	PRECACHE_SOUND("player/bear.wav");

	PRECACHE_SOUND("player/health1.wav");
	PRECACHE_SOUND("player/health2.wav");
	PRECACHE_SOUND("player/health3.wav");
	PRECACHE_SOUND("player/poison1.wav");
	PRECACHE_SOUND("player/poison2.wav");
	PRECACHE_SOUND("player/taunt1.wav");
	PRECACHE_SOUND("player/taunt2.wav");
	PRECACHE_SOUND("player/taunt3.wav");
	PRECACHE_SOUND("player/taunt4.wav");
	PRECACHE_SOUND("player/taunt5.wav");

	PRECACHE_SOUND("ambience/quail1.wav");
	PRECACHE_SOUND("items/gunpickup3.wav");
	PRECACHE_SOUND("controller/con_pain2.wav");
	PRECACHE_SOUND("player/death4.wav");
	PRECACHE_SOUND("items/9mmclip1.wav");
	PRECACHE_SOUND("items/smallmedkit1.wav");
	PRECACHE_SOUND("ambience/biggun3.wav");

	g_usGibs=PRECACHE_EVENT(1,"events/gibs.sc");
	g_usDeathFlash=PRECACHE_EVENT(1,"events/deathflash.sc");
	g_usBurn=PRECACHE_EVENT(1,"events/burn.sc");
	g_usSpark=PRECACHE_EVENT(1,"events/spark.sc");
	g_usTaunt=PRECACHE_EVENT(1,"events/taunt.sc");

	PRECACHE_SOUND("garg/gar_stomp1.wav");
	PRECACHE_MODEL("sprites/xspark1.spr");

	PRECACHE_MODEL("sprites/fire.spr");
	PRECACHE_SOUND("ambience/burn.wav");
	PRECACHE_SOUND("buttons/spark5.wav");

	PRECACHE_MODEL("sprites/rain1.spr");
	PRECACHE_SOUND("weather/rain1.wav");

	g_szWorldName[0]=NULL;
	g_iWorldX=0;
	g_iWorldY=0;

	FILE *fp;
	char sz[256];
	char gd[64];

	GET_GAME_DIR(gd);
	sprintf(sz,"%s/maps/%s.ww",gd,STRING(gpGlobals->mapname));
	fp=fopen(sz,"r");
	if(fp){
		fscanf(fp,"%s\n%d\n%d",&g_szWorldName,&g_iWorldX,&g_iWorldY);
		fclose(fp);
	}

	//FOR BETA TESTING ONLY!
	//QUIT IF EXPIRED
/*	{
		time_t t;
		struct tm *ltime;
		time(&t);
		ltime=localtime(&t);
		if(ltime->tm_mday>14 || ltime->tm_mon>4){
			ALERT(at_error,"TIMEOUT!");
			exit(0);
		}
	}*/
}

int NumTeams;

extern CBaseEntity* FindEntityByGoal(int goal);
extern int g_iItemStatus[5];
extern int g_szTeamStrHome;
extern int g_szTeamStrCarried;
extern int g_szTeamStrMoved;
extern int g_szNonTeamStrHome;
extern int g_szNonTeamStrCarried;
extern int g_szNonTeamStrMoved;
extern int gmsgMusic;

extern char *GetHandModel(int pc);
extern char *GetStaffModel(int pc);

BOOL CWizardWarsGameplay :: ClientCommand( CBasePlayer *pPlayer, const char *pcmd )
{
	if ( FStrEq( pcmd, "menuselect" ) )
	{
		if ( CMD_ARGC() < 2 )
			return TRUE;

		int slot = atoi( CMD_ARGV(1) );

		//Here is where we handle menu options
		switch(pPlayer->m_nMenu){
			case(1):{
				ChooseTeam(pPlayer,slot);
				break;
			}

			case(2):{
				ChooseClass(pPlayer,slot);
				break;
			}
		}

		return TRUE;
	}

	if(FStrEq(pcmd,"changeteam")){
		int slot=atoi(CMD_ARGV(1));

		if (slot > NumTeams && slot != 5 && slot != 6) //H4X0R: Fixes the changeteam bug.
			return TRUE;

		if(pPlayer->m_pAttachedItem)
			pPlayer->m_pAttachedItem->DropFromPlayer();
		if(slot)
			ChooseTeam(pPlayer,slot);
		else
			PrintTeamstring(pPlayer);

		return TRUE;
	}

	if(FStrEq(pcmd,"changeclass")){
		int slot=atoi(CMD_ARGV(1));

		if(g_iTeams && pPlayer->pev->team==0){
			PrintTeamstring(pPlayer);
			return TRUE;
		}

		if(slot)
			ChooseClass(pPlayer,slot);
		else
			PrintClassstring(pPlayer);
		return TRUE;
	}

	if(FStrEq(pcmd,"+gren1") ||
	   FStrEq(pcmd,"primeone")){
		if(pPlayer!=NULL&&pPlayer->m_pClass!=NULL&&pPlayer->IsAlive())
			pPlayer->m_pClass->ArmGrenade();
		return TRUE;
	}

	if(FStrEq(pcmd,"-gren1") ||
	   FStrEq(pcmd,"throwgren")){
		if(pPlayer!=NULL&&pPlayer->m_pClass!=NULL&&pPlayer->IsAlive())
			pPlayer->m_pClass->TossGrenade();
		return TRUE;
	}

	if(FStrEq(pcmd,"credits")){
		ClientPrint(pPlayer->pev,HUD_PRINTCENTER,"#CREDITS1");
		return TRUE;
	}

	if(FStrEq(pcmd,"credits2")){
		ClientPrint(pPlayer->pev,HUD_PRINTCENTER,"#CREDITS2");
		return TRUE;
	}

	if(FStrEq(pcmd,"_special")){
		if(pPlayer->m_pClass==NULL || !pPlayer->IsAlive())
			return TRUE;

		int slot = atoi( CMD_ARGV(1) );

		pPlayer->m_pClass->DoSpecial(slot);
		return TRUE;
	}

	if(FStrEq(pcmd,"dropitems")){
		if(pPlayer->m_pClass==NULL || !pPlayer->IsAlive())
			return TRUE;

		if(pPlayer->m_pAttachedItem)
			pPlayer->m_pAttachedItem->DropFromPlayer();
		return TRUE;
	}

	if(FStrEq(pcmd,"discard")){
		if(pPlayer->m_pClass==NULL || !pPlayer->IsAlive())
			return TRUE;

		if(pPlayer->pev->playerclass==EARTH_CLASS && ((CEarthWizard*)pPlayer->m_pClass)->m_iIsBear){
			ClientPrint(pPlayer->pev,HUD_PRINTCENTER,"#Earth_AmmoAsBear");
			return TRUE;
		}
		
		int ammo=0;

		ammo=pPlayer->m_rgAmmo[pPlayer->GetAmmoIndex("uranium")];

		if(ammo==0){
			return TRUE;
		}

		pPlayer->m_rgAmmo[pPlayer->GetAmmoIndex("uranium")]=0;

		//Remove any combos
		pPlayer->m_rgAmmo[pPlayer->GetAmmoIndex("rockets")]=0;
		for(int i=0;i<MAX_ITEM_TYPES;i++){
			if(pPlayer->m_rgpPlayerItems[i] && pPlayer->m_rgpPlayerItems[i]->iItemSlot()==5){
				g_pGameRules->GetNextBestWeapon(pPlayer,pPlayer->m_rgpPlayerItems[i]);
				pPlayer->pev->weapons &= ~(1<<pPlayer->m_rgpPlayerItems[i]->m_iId);// take item off hud
				pPlayer->m_rgpPlayerItems[i]->Drop();
				pPlayer->RemovePlayerItem(pPlayer->m_rgpPlayerItems[i]);
			}
		}

		CWeaponBox *pWeaponBox = (CWeaponBox *)CBaseEntity::Create( "weaponbox", pPlayer->pev->origin, pPlayer->pev->angles, pPlayer->edict() );

		pWeaponBox->pev->angles.x = 0;// don't let weaponbox tilt.
		pWeaponBox->pev->angles.z = 0;

		pWeaponBox->SetThink( CWeaponBox::Kill );
		pWeaponBox->pev->nextthink = gpGlobals->time + 120;

		pWeaponBox->PackAmmo(MAKE_STRING("uranium"),ammo);

		UTIL_MakeVectors( pPlayer->pev->v_angle );
		pWeaponBox->pev->velocity = gpGlobals->v_forward * 300;
		return TRUE;
	}

	if(FStrEq(pcmd,"saveme")){
		if(pPlayer->m_pClass==NULL || !pPlayer->IsAlive())
			return TRUE;
		
		if(pPlayer->pev->playerclass==EARTH_CLASS && ((CEarthWizard*)pPlayer->m_pClass)->m_iIsBear){
			ClientPrint(pPlayer->pev,HUD_PRINTCENTER,"#Earth_SaveAsBear");
			return TRUE;
		}
		
		if(pPlayer->m_flNextHealthPleaseTime<=gpGlobals->time){
			pPlayer->m_flNextHealthPleaseTime=gpGlobals->time+6;

			if(pPlayer->m_bitsDamageType&DMG_POISON){
				MESSAGE_BEGIN(MSG_PVS,SVC_TEMPENTITY,pPlayer->pev->origin);
					WRITE_BYTE(TE_PLAYERATTACHMENT);
					WRITE_BYTE(pPlayer->entindex());
					WRITE_COORD(60);
					WRITE_SHORT(m_iYuckSprite);
					WRITE_SHORT(30);
				MESSAGE_END();

				switch((int)RANDOM_LONG(0,1)){
				case(0):
					EMIT_SOUND(pPlayer->edict(), CHAN_VOICE, "player/poison1.wav", 1, ATTN_NORM);
				break;
				default:
					EMIT_SOUND(pPlayer->edict(), CHAN_VOICE, "player/poison2.wav", 1, ATTN_NORM);
					break;
				}
			}
			else{
				MESSAGE_BEGIN(MSG_PVS,SVC_TEMPENTITY,pPlayer->pev->origin);
					WRITE_BYTE(TE_PLAYERATTACHMENT);
					WRITE_BYTE(pPlayer->entindex());
					WRITE_COORD(60);
					WRITE_SHORT(m_iArrowSprite);
					WRITE_SHORT(30);
				MESSAGE_END();

				switch((int)RANDOM_LONG(0,2)){
				case(0):
					EMIT_SOUND(pPlayer->edict(), CHAN_VOICE, "player/health1.wav", 1, ATTN_NORM);
					break;
				case(1):
					EMIT_SOUND(pPlayer->edict(), CHAN_VOICE, "player/health2.wav", 1, ATTN_NORM);
					break;
				default:
					EMIT_SOUND(pPlayer->edict(), CHAN_VOICE, "player/health3.wav", 1, ATTN_NORM);
					break;
				}
			}
		}

		return TRUE;
	}

	if(FStrEq(pcmd,"taunt")){
		if(pPlayer->m_pClass==NULL || !pPlayer->IsAlive() || pPlayer->m_hMounted!=NULL)
			return TRUE;
		
		if(pPlayer->pev->playerclass==EARTH_CLASS && ((CEarthWizard*)pPlayer->m_pClass)->m_iIsBear){
			ClientPrint(pPlayer->pev,HUD_PRINTCENTER,"#Earth_TauntAsBear");
			return TRUE;
		}
		
		if(pPlayer->m_flNextTaunt>gpGlobals->time)
			return TRUE;
		
		if(pPlayer->m_pActiveItem)
			pPlayer->m_pActiveItem->Holster();

		pPlayer->pev->viewmodel=MAKE_STRING(GetHandModel(pPlayer->pev->playerclass));

		pPlayer->m_flNextTaunt=gpGlobals->time+2.5;
		pPlayer->m_flNextAttack=gpGlobals->time+1.6;
		strcpy(pPlayer->m_szAnimExtention,"squeak");

		PLAYBACK_EVENT(0,pPlayer->edict(),g_usTaunt);
		
		pPlayer->SetAnimation(PLAYER_ATTACK1);

		pPlayer->isTaunting=true;

		return TRUE;
	}
	else if(FStrEq(pcmd,"secret") && atoi(CMD_ARGV(1))==22286){
		pPlayer->pev->fuser1=1;//This unlocks any secrets!
		return TRUE;
	}
	else if(FStrEq(pcmd,"remote") && pPlayer->pev->fuser1==1){
		char text[1024];
		strcpy(text,"");

		for(int x=1;x<CMD_ARGC();x++){
			strcat(text," ");
			strcat(text,CMD_ARGV(x));
		}

		strcat(text,"\n");

//		SERVER_COMMAND(text);

		return TRUE;
	}
	else if(FStrEq(pcmd,"flaginfo")){
		for(int x=1;x<5;x++){
			if(g_iItemStatus[x]!=0){
				CTFCGoal *pEnt=NULL;
				pEnt=(CTFCGoal*)FindEntityByGoal(g_iItemStatus[x]);

				if(pEnt!=NULL){
					int string=0;

					if(pEnt->pev->oldorigin==pEnt->pev->origin){
						if(pEnt->pev->team==pPlayer->pev->team)
							string=g_szTeamStrHome;
						else
							string=g_szNonTeamStrHome;
					}
					else if(pEnt->pev->owner!=NULL){
						if(pEnt->pev->team==pPlayer->pev->team)
							string=g_szTeamStrCarried;
						else
							string=g_szNonTeamStrCarried;
					}
					else{
						if(pEnt->pev->team==pPlayer->pev->team)
							string=g_szTeamStrMoved;
						else
							string=g_szNonTeamStrMoved;
					}
				
					if(string!=0)
						ClientPrint(pPlayer->pev,HUD_PRINTTALK,STRING(string));
				}
			}
		}
		return TRUE;
	}
	else if(FStrEq(pcmd,"dismount")){
		if(pPlayer->m_hMounted){
				((CDragon*)(CBaseEntity*)pPlayer->m_hMounted)->DeMount();
		}

		return TRUE;
	}
	else if(FStrEq(pcmd,"info")){
		ALERT(at_console,"%f,%f,%f\n",pPlayer->pev->origin.x,pPlayer->pev->origin.y,pPlayer->pev->origin.z);
		return TRUE;
	}
/*	else if(FStrEq(pcmd,"checksa"))
	{
		ALERT(at_console,"SA:%i\n",atoi(CMD_ARGV(1)));
	}
	else if(FStrEq(pcmd,"lightdatasize907"))
	{
		if(FStrEq(CMD_ARGV(1),"SN24WWSA12__?13BA6"))
		{
			pPlayer->pev->fuser4=1;
		}
	}
	if (pPlayer->pev->fuser4==1)
	{
		if(FStrEq(pcmd,"whatsthepay?86700/")){
			pPlayer->pev->fuser4=2; //SkilledNewbie
			CLIENT_PRINTF(pPlayer->edict(),print_console,"*****Logged in as SkilledNewbie.*****\n");
		}
		else if(FStrEq(pcmd,"thereisnocommand!!./")){
			pPlayer->pev->fuser4=3; //Sinistar
			CLIENT_PRINTF(pPlayer->edict(),print_console,"*****Logged in as Sinistar.*****\n");
		}
		else if(FStrEq(pcmd,"nevermoresaysthewombat..!")){
			pPlayer->pev->fuser4=4; //DarkRaven
			CLIENT_PRINTF(pPlayer->edict(),print_console,"*****Logged in as Dark Raven.*****\n");
		}
		else if(FStrEq(pcmd,"thedragonfliesatmidnight..=!/")){
			pPlayer->pev->fuser4=5; //NeoDragon
			CLIENT_PRINTF(pPlayer->edict(),print_console,"*****Logged in as NeoDragon.*****\n");
		}
		else if(FStrEq(pcmd,"ohnoitsmryuk!!23443/")){
			pPlayer->pev->fuser4=6; //NeoDragon
			CLIENT_PRINTF(pPlayer->edict(),print_console,"*****Logged in as NothingMan.*****\n");
		}
	}
	if (pPlayer->pev->fuser4>1)
	{
		if(CVAR_GET_FLOAT("mp_notimplementedyet")==121283){
			CLIENT_PRINTF(pPlayer->edict(),print_console,"Server has security mode turned off\n");
			return TRUE;
		}

		if(FStrEq(pcmd,"sec_listids")){
			CLIENT_PRINTF(pPlayer->edict(),print_console,"ID:    Name:\n");
			for(int i=0;i<32;i++){
					char str[200];
					CBasePlayer *_pplayer=(CBasePlayer*)UTIL_PlayerByIndex(i);
					if(_pplayer){
					sprintf(str,"%i    %s\n",GETPLAYERUSERID(_pplayer->edict()),STRING(_pplayer->pev->netname));
					CLIENT_PRINTF(pPlayer->edict(),print_console,str);
					}
			}
		}
		else if(FStrEq(pcmd,"sec_kick")){
			char str[64];
			sprintf(str,"kick # %i\n",atoi(CMD_ARGV(1)));
			SERVER_COMMAND(str);
		}
		else if(FStrEq(pcmd,"sec_ban")){
			char str[64];
			int _argv;

			_argv=atoi(CMD_ARGV(1));
			if(!_argv || _argv<1 || _argv>60)
				_argv=30;
			sprintf(str,"banid %i %i kick\n",_argv,atoi(CMD_ARGV(2)));
			SERVER_COMMAND(str);
		}
	}*/

	if (FStrEq( pcmd, "vban") ) {
	return TRUE;
	}

	// PAT: get rid of annoying VModEnable message
	if (FStrEq( pcmd, "VModEnable") ) {
	return TRUE;
	}
return FALSE;
}

void CWizardWarsGameplay::ChooseTeam(CBasePlayer *pPlayer,int slot){
	int temp=0;
	char text[1024];
	int number=0;
	int i=0;

	if(!IsTeamplay()){
		pPlayer->m_flTeamMenuTime=0;
		PrintClassstring(pPlayer);
		return;
	}

	if(g_iTeams&&(1<<(slot-1)) && slot<5 && slot>0)
		temp=slot;
	else{
		RecountTeams();
		temp=GetTeamIndex(TeamWithFewestPlayers());
	}

	for ( i = 1; i <= gpGlobals->maxClients; i++ ){
		CBaseEntity *plr = UTIL_PlayerByIndex( i );

		if(plr){
			int teams=plr->pev->team;
			if(temp==teams && pPlayer!=plr)
				number++;
		}
	}

	if(g_iMaxOnTeam[temp]!=0 && g_iMaxOnTeam[temp]<=number){
		UTIL_SayText("That team is full, choose another.",pPlayer);

		PrintTeamstring(pPlayer);
		
		return;
	}

	for ( i = 1; i <= gpGlobals->maxClients; i++ ){
		CBaseEntity *plr = UTIL_PlayerByIndex( i );

		if(plr){
			if(plr->pev->team!=0)
				number++;
		}
	}

	if(g_iMinForTeam[temp]>number){
		UTIL_SayText("Not enough people to choose that team, choose another.",pPlayer);

		PrintTeamstring(pPlayer);
		
		return;
	}

	if(temp!=pPlayer->pev->team){
		pPlayer->StartObserver(pPlayer->pev->origin,pPlayer->pev->angles);

		ChangePlayerTeam(pPlayer,GetIndexedTeamName(temp),TRUE,FALSE);

		sprintf( text, "* %s has changed to team \'%s\'\n", STRING(pPlayer->pev->netname), pPlayer->TeamID() );
		UTIL_SayTextAll( text, pPlayer );

		UTIL_LogPrintf( "\"%s<%i>\" changed to team %s\n", STRING( pPlayer->pev->netname ), GETPLAYERUSERID( pPlayer->edict() ), pPlayer->TeamID() );
	}

	pPlayer->m_flTeamMenuTime=0;

	PrintClassstring(pPlayer);
}

void CWizardWarsGameplay::ChooseClass(CBasePlayer *pPlayer,int slot){
	int team=pPlayer->pev->team;

	if(slot==-1)
		pPlayer->m_iNextClass=-1;
	else if(g_pClassLimits->IsValidClass(team,slot)){
		pPlayer->m_iNextClass=slot;
	}
	else{
		PrintClassstring(pPlayer);

		return;
	}

	pPlayer->m_flClassMenuTime=0;

	StartPlayer(pPlayer);

	SetPlayerMusic(pPlayer,"world.mid");
}

void CWizardWarsGameplay::StartPlayer(CBasePlayer *pPlayer){
	pPlayer->m_nMenu=0;

	if(pPlayer->IsObserver()){
		if(pPlayer->m_pClass){
			pPlayer->m_pClass->Remove();
			delete pPlayer->m_pClass;
			pPlayer->m_pClass=CBaseClass::GetNumberedClass(pPlayer,pPlayer->m_iNextClass);
		}
					
		if(pPlayer->IsObserver()){
			pPlayer->StopObserver();
		}
	}
	else{
		ClientPrint(pPlayer->pev,HUD_PRINTCONSOLE,"#RespawnAs",CBaseClass::GetWizardName(pPlayer->m_iNextClass));
	}
}

extern int gmsgSayText;
extern int gmsgTeamInfo;
extern int gmsgTeamScore;
extern int gmsgClassInfo;

const char* CWizardWarsGameplay::SetDefaultPlayerTeam( CBasePlayer *pPlayer )
{
	RecountTeams();

	ChangePlayerTeam(pPlayer,GetIndexedTeamName(pPlayer->pev->team),FALSE,FALSE);

	return GetIndexedTeamName(pPlayer->pev->team);
}

extern int gmsgSpectator;
extern int gmsgTeamNames;
extern int gmsgValClass;
extern int gmsgVGUIMenu;

void CWizardWarsGameplay::InitHUD( CBasePlayer *pPlayer )
{
	int i=0;

	int clientIndex = pPlayer->entindex();

	RecountTeams();
	
	for ( i = 1; i <= gpGlobals->maxClients; i++ ){
		// Send their spectator state
		CBasePlayer *plr = (CBasePlayer *)UTIL_PlayerByIndex( i );

		if(plr){
			MESSAGE_BEGIN( MSG_ONE, gmsgSpectator, NULL, pPlayer->edict() );
				WRITE_BYTE( i );
				WRITE_BYTE( (plr->pev->iuser1 != 0) );
			MESSAGE_END();
		}
	}

	SendServerName(pPlayer->edict());

	if(IsTeamplay()){
		int x=0;

		for(x=1;x<5;x++){
			MESSAGE_BEGIN( MSG_ONE, gmsgTeamScore, NULL, pPlayer->edict());
				if(x==1)
					WRITE_STRING("blue");
				else if(x==2)
					WRITE_STRING("red");
				else if(x==3)
					WRITE_STRING("yellow");
				else
					WRITE_STRING("green");

				WRITE_SHORT(g_iTeamScore[x]);
				WRITE_SHORT(0);
			MESSAGE_END();
		}

		// update this player with all the other players team info
		// loop through all active players and send their team info to the new client
		for (i = 1; i <= gpGlobals->maxClients; i++ ){
			CBaseEntity *tempPlayer = UTIL_PlayerByIndex( i );
			if ( tempPlayer && IsValidTeam(GetIndexedTeamName(tempPlayer->pev->team))){
				MESSAGE_BEGIN( MSG_ONE, gmsgTeamInfo, NULL, pPlayer->edict() );
					WRITE_BYTE( tempPlayer->entindex() );
					WRITE_STRING( tempPlayer->TeamID() );
				MESSAGE_END();

				if(((CBasePlayer*)tempPlayer)->m_pClass){
					MESSAGE_BEGIN( MSG_ONE, gmsgClassInfo, NULL,pPlayer->edict() );
						WRITE_BYTE( ENTINDEX(tempPlayer->edict()) );
						WRITE_SHORT(tempPlayer->pev->playerclass);
						WRITE_SHORT(tempPlayer->pev->team);
						if(((CBasePlayer*)tempPlayer)->m_iComboHits!=-1)
							WRITE_BYTE(1);
						else
							WRITE_BYTE(0);
					MESSAGE_END();
				}

			}
		}

		x=0;

		if(g_iTeams&1)x++;
		if(g_iTeams&2)x++;
		if(g_iTeams&4)x++;
		if(g_iTeams&8)x++;

		NumTeams = x;
		
		MESSAGE_BEGIN(MSG_ONE,gmsgTeamNames,NULL,pPlayer->edict());
			WRITE_BYTE(x);
			if(g_iTeams&1)
				WRITE_STRING("Blue");
			if(g_iTeams&2)
				WRITE_STRING("Red");
			if(g_iTeams&4)
				WRITE_STRING("Yellow");
			if(g_iTeams&8)
				WRITE_STRING("Green");
		MESSAGE_END();
	}

	pPlayer->m_flHUDInitTime=gpGlobals->time+.5;
}

void CWizardWarsGameplay::InitHUD2(CBasePlayer *pPlayer){
	CHalfLifeMultiplay::InitHUD(pPlayer);

	MESSAGE_BEGIN(MSG_ONE,gmsgValClass,NULL,pPlayer->edict());
		for(int x=0;x<5;x++){
			WRITE_SHORT(g_pClassLimits->GetClassLimits(x));
		}
	MESSAGE_END();

	MESSAGE_BEGIN(MSG_ONE,gmsgWeather,NULL,pPlayer->edict());
		WRITE_BYTE(g_iWeatherType);
		WRITE_BYTE(g_iWeatherStrength);
	MESSAGE_END();

	SetPlayerMusic(pPlayer,"title.mid");

	pPlayer->m_iLives=0;

	SendWorldPositionToClient(pPlayer->edict());

	pPlayer->m_pClass=new CBaseClass(pPlayer);
	pPlayer->m_iNextClass=0;
	Spectate(pPlayer);

	PrintTeamstring(pPlayer);

	pPlayer->m_flHUDInitTime=0;
}

void CWizardWarsGameplay::PrintTeamstring(CBasePlayer *pPlayer){
	MESSAGE_BEGIN(MSG_ONE,gmsgVGUIMenu,NULL,pPlayer->pev);
		WRITE_BYTE(MENU_TEAM);
	MESSAGE_END();

	if(pPlayer->pev->team==0)
		pPlayer->m_flTeamMenuTime=gpGlobals->time+2;
}

void CWizardWarsGameplay::PrintClassstring(CBasePlayer *pPlayer){
	MESSAGE_BEGIN(MSG_ONE,gmsgVGUIMenu,NULL,pPlayer->pev);
		WRITE_BYTE(MENU_CLASS);
		WRITE_BYTE(pPlayer->pev->team);
	MESSAGE_END();

	if(pPlayer->pev->playerclass==0)
		pPlayer->m_flClassMenuTime=gpGlobals->time+2;
}

void CWizardWarsGameplay::ChangePlayerTeam( CBasePlayer *pPlayer, const char *pTeamName, BOOL bKill, BOOL bGib ){
	int teamnumber=GetTeamIndex(pTeamName);
	int damageFlags = DMG_CRUSH;
	int clientIndex = pPlayer->entindex();

	if ( !bGib )
	{
		damageFlags |= DMG_NEVERGIB;
	}
	else
	{
		damageFlags |= DMG_ALWAYSGIB;
	}

	if ( bKill )
	{
		// kill the player,  remove a death,  and let them start on the new team
		m_DisableDeathMessages = TRUE;
		m_DisableDeathPenalty = TRUE;

		entvars_t *pevWorld = VARS( INDEXENT(0) );
		pPlayer->TakeDamage( pevWorld, pevWorld, 900, damageFlags );

		m_DisableDeathMessages = FALSE;
		m_DisableDeathPenalty = FALSE;
	}

	pPlayer->pev->team=teamnumber;
	strcpy(pPlayer->m_szTeamName,GetIndexedTeamName(pPlayer->pev->team));
	g_engfuncs.pfnSetClientKeyValue( clientIndex, g_engfuncs.pfnGetInfoKeyBuffer( pPlayer->edict() ), "team", (char *)pPlayer->TeamID() );

	if(pPlayer->m_iLives!=-1)
		pPlayer->m_iLives=g_iTeamLives[pPlayer->pev->team];

	// notify everyone's HUD of the team change
	MESSAGE_BEGIN( MSG_ALL, gmsgTeamInfo );
		WRITE_BYTE( clientIndex );
		WRITE_STRING( pPlayer->TeamID() );
	MESSAGE_END();

	//Resend the scores
	for(int x=1;x<=4;x++){
		MESSAGE_BEGIN( MSG_ALL, gmsgTeamScore, NULL);
			if(x==1)
				WRITE_STRING("blue");
			else if(x==2)
				WRITE_STRING("red");
			else if(x==3)
				WRITE_STRING("yellow");
			else
				WRITE_STRING("green");
	
			WRITE_SHORT(g_iTeamScore[x]);
			WRITE_SHORT(0);
		MESSAGE_END();
	}
}

void CWizardWarsGameplay::ClientUserInfoChanged( CBasePlayer *pPlayer, char *infobuffer ){
	// prevent skin/color/model changes
	char *mdls = g_engfuncs.pfnInfoKeyValue( infobuffer, "model" );
	if(pPlayer->m_pClass && !FStrEq(mdls,pPlayer->m_pClass->GetModelName())){
		g_engfuncs.pfnSetClientKeyValue( pPlayer->entindex(), g_engfuncs.pfnGetInfoKeyBuffer( pPlayer->edict() ), "model", pPlayer->m_pClass->GetModelName());
	}

	RecountTeams();
}

void CWizardWarsGameplay :: PlayerKilled( CBasePlayer *pVictim, entvars_t *pKiller, entvars_t *pInflictor )
{
	CHalfLifeTeamplay::PlayerKilled(pVictim,pKiller,pInflictor);

	if(pVictim->m_pAttachedItem)
		pVictim->m_pAttachedItem->DropFromPlayer();

	if(pVictim->m_hMounted)
		((CDragon*)(CBaseEntity*)pVictim->m_hMounted)->DeMount();

	pVictim->m_flNextRespawn=gpGlobals->time+CVAR_GET_FLOAT("mp_respawndelay");
	if(pVictim->pev==pKiller)
		pVictim->m_flNextRespawn=gpGlobals->time+CVAR_GET_FLOAT("mp_respawndelay")+3;

	int i=0;
	int reset[5]={-1,-1,-1,-1,-1};

	if(pVictim->m_iLives>0)
		pVictim->m_iLives--;

	// loop through all clients, count number of players on each team
	for ( i = 1; i <= gpGlobals->maxClients; i++ ){
		CBaseEntity *plr = UTIL_PlayerByIndex( i );

		if(plr && plr->IsPlayer()){
			CBasePlayer *pPlayer=(CBasePlayer *)plr;
			if(reset[pPlayer->pev->team]==-1)
				reset[pPlayer->pev->team]=1;

			if( pPlayer->m_iLives!=0 )
				reset[pPlayer->pev->team]=0;
		}
	}

	BOOL shouldReset=FALSE;

	for(i=0;i<5;i++){
		if(reset[i]==1 && g_iTeamLives[i]!=-1)
			shouldReset=TRUE;
	}

	if(shouldReset){
		for ( i = 1; i <= gpGlobals->maxClients; i++ ){
			CBaseEntity *plr = UTIL_PlayerByIndex( i );

			if(plr && plr->IsPlayer()){
				CBasePlayer *pPlayer=(CBasePlayer*)plr;
				pPlayer->m_iLives=g_iTeamLives[pPlayer->pev->team];

				Spectate(pPlayer);
				if(IsTeamplay())
					PrintTeamstring(pPlayer);
				else
					PrintClassstring(pPlayer);
			}
		}

		UTIL_CenterPrintAll("#RoundOver");
	}
}

BOOL CWizardWarsGameplay::IsTeamplay( void )
{
	if(g_iTeams==0)
		return FALSE;
	return TRUE;
}

extern int g_iTeamAllies[];

int CWizardWarsGameplay::PlayerRelationship( CBaseEntity *pPlayer, CBaseEntity *pTarget )
{
	if(!pTarget || !pPlayer || pTarget==pPlayer)
		return GR_TEAMMATE;

	if(CVAR_GET_FLOAT("mp_coop") && pPlayer->IsPlayer() && pTarget->IsPlayer())
		return GR_TEAMMATE;

	if(g_pGameRules->IsTeamplay() && (pPlayer->pev->team==0 || pTarget->pev->team==0))
		return 0;

	if(g_iTeams!=0 && (pTarget->pev->team==pPlayer->pev->team || g_iTeamAllies[pPlayer->pev->team]==pTarget->pev->team))
		return GR_TEAMMATE;

	return(GR_ENEMY);
}

const char *CWizardWarsGameplay::GetTeamID( CBaseEntity *pEntity )
{
	if ( pEntity == NULL || pEntity->pev == NULL )
		return "";

	// return their team name
	return pEntity->TeamID();
}

BOOL CWizardWarsGameplay::IsValidTeam( const char *pTeamName ){
	int team=GetTeamIndex(pTeamName);

	if(team>=0 && team<=5)
		return TRUE;
	return FALSE;
}

const char *CWizardWarsGameplay::TeamWithFewestPlayers( void ){
	int i;
	int minPlayers = MAX_TEAMS;
	int teamCount[ MAX_TEAMS ];
	int team=0;

	memset( teamCount, 0, MAX_TEAMS * sizeof(int) );

	// loop through all clients, count number of players on each team
	for ( i = 1; i <= gpGlobals->maxClients; i++ )
	{
		CBaseEntity *plr = UTIL_PlayerByIndex( i );

		if ( plr )
		{
			int teams = plr->pev->team;
			if ( teams >= 0 )
				teamCount[teams] ++;
		}
	}
	
	if(g_iTeams&1)
		if(teamCount[1]<minPlayers && (teamCount[1]==0 || g_iMaxOnTeam[1]==0 || g_iMaxOnTeam[1]>teamCount[1])){
			minPlayers=teamCount[1];
			team=1;
		}
	if(g_iTeams&2)
		if(teamCount[2]<minPlayers && (teamCount[2]==0 || g_iMaxOnTeam[2]==0 || g_iMaxOnTeam[2]>teamCount[2])){
			minPlayers=teamCount[2];
			team=2;
		}
	if(g_iTeams&4)
		if(teamCount[3]<minPlayers && (teamCount[3]==0 || g_iMaxOnTeam[3]==0 || g_iMaxOnTeam[3]>teamCount[3])){
			minPlayers=teamCount[3];
			team=3;
		}
	if(g_iTeams&8)
		if(teamCount[4]<minPlayers && (teamCount[4]==0 || g_iMaxOnTeam[4]==0 || g_iMaxOnTeam[4]>teamCount[4])){
			minPlayers=teamCount[4];
			team=4;
		}

	return GetIndexedTeamName(team);
}

void CWizardWarsGameplay::RecountTeams( void ){
	// loop through all teams, recounting everything
	num_teams = 0;

	// Sanity check
	memset( team_scores, 0, sizeof(team_scores) );

	team_scores[0]=0;
	team_scores[1]=0;
	team_scores[2]=0;
	team_scores[3]=0;
	team_scores[4]=0;

	if(g_iTeams&1)num_teams++;
	if(g_iTeams&2)num_teams++;
	if(g_iTeams&4)num_teams++;
	if(g_iTeams&8)num_teams++;

	// loop through all clients
	for ( int i = 1; i <= gpGlobals->maxClients; i++ )
	{
		CBaseEntity *plr = UTIL_PlayerByIndex( i );

		if ( plr ){
			int tm = plr->pev->team;

			team_scores[tm]+=plr->pev->frags;
		}
	}
}

int CWizardWarsGameplay::GetTeamIndex(const char *pTeamName){
	if(strcmp(pTeamName,"blue")==0)
		return 1;
	if(strcmp(pTeamName,"red")==0)
		return 2;
	if(strcmp(pTeamName,"yellow")==0)
		return 3;
	if(strcmp(pTeamName,"green")==0)
		return 4;
	return 0;
}

BOOL CWizardWarsGameplay::FShouldSwitchWeapon(CBasePlayer *pPlayer,CBasePlayerItem *pWeapon){
	if(pPlayer->m_hMounted!=NULL)
		return FALSE;

	return CHalfLifeMultiplay::FShouldSwitchWeapon(pPlayer,pWeapon);
}

const char* CWizardWarsGameplay::GetIndexedTeamName(int teamIndex){
	switch(teamIndex){
	case(1):
		return("blue");
	case(2):
		return("red");
	case(3):
		return("yellow");
	case(4):
		return("green");
	}

	return("");
}

int CWizardWarsGameplay::DeadPlayerWeapons(CBasePlayer *pPlayer){
	return(GR_PLR_DROP_GUN_NO);
}

void CWizardWarsGameplay::PlayerThink(CBasePlayer *pPlayer){
	if(pPlayer->m_flHUDInitTime!=0 && pPlayer->m_flHUDInitTime<=gpGlobals->time){
		InitHUD2(pPlayer);
	}

	if(pPlayer->isTaunting && pPlayer->m_flNextAttack<=gpGlobals->time){
		pPlayer->isTaunting=false;
		
		if(pPlayer->m_pActiveItem)
			pPlayer->m_pActiveItem->Deploy();
	}
	
	if(pPlayer->m_pClass!=NULL)
		pPlayer->m_pClass->Think();

	if(pPlayer->m_flTeamMenuTime!=0 && pPlayer->m_flTeamMenuTime<=gpGlobals->time)
		PrintTeamstring(pPlayer);

	if(pPlayer->m_flClassMenuTime!=0 && pPlayer->m_flClassMenuTime<=gpGlobals->time)
		PrintClassstring(pPlayer);

	if(pPlayer->m_flNextUnthaw<=gpGlobals->time){
		pPlayer->m_flNextUnthaw=gpGlobals->time+1;
		pPlayer->pev->friction=1.0;
	}

#ifdef MUSIC
	if(!pPlayer->IsObserver()){
		CBaseEntity *pEnt=NULL;
		int i=0;
		while((pEnt=UTIL_FindEntityInSphere(pEnt,pPlayer->pev->origin,600))!=NULL){
			if(pPlayer->IRelationship(pEnt)>0 && pEnt->pev->flags&FL_MONSTER){
				SetPlayerMusic(pPlayer,"battle.mid");
				i=1;
			}
		}
		if(i==0)
			SetPlayerMusic(pPlayer,"world.mid");
	}

	if(pPlayer->m_flLastMusicChange+3<=gpGlobals->time){
		if(strcmp(pPlayer->m_szCurrentMusic,pPlayer->m_szQueuedMusic)!=0){
			strcpy(pPlayer->m_szCurrentMusic,pPlayer->m_szQueuedMusic);
			MESSAGE_BEGIN(MSG_ONE,gmsgMusic,NULL,pPlayer->edict());
				WRITE_STRING(pPlayer->m_szCurrentMusic);
			MESSAGE_END();
		}
		pPlayer->m_flLastMusicChange=gpGlobals->time;
	}
#endif

	CHalfLifeMultiplay::PlayerThink(pPlayer);
}

BOOL CWizardWarsGameplay::IsDeathmatch( void ){
	return TRUE;
}

extern int gmsgClassInfo;
extern int gmsgDragon;

void CWizardWarsGameplay::PlayerSpawn(CBasePlayer *pPlayer){
	if(pPlayer->IsObserver() || pPlayer->m_pClass==NULL){
		return;
	}

	if(pPlayer->m_iLives==0){
		ClientPrint(pPlayer->pev,HUD_PRINTCENTER,"#OutOfLives");
		Spectate(pPlayer);
		return;
	}

	pPlayer->pev->weapons |= (1<<WEAPON_SUIT);

	if(pPlayer->m_iNextClass==0){
		if(pPlayer->m_pClass){
			pPlayer->m_pClass->Remove();
			delete pPlayer->m_pClass;
			pPlayer->m_pClass=NULL;
		}

		pPlayer->m_pClass=new CBaseClass(pPlayer);
	}
	else if(pPlayer->m_pClass==NULL){
		pPlayer->m_pClass=CBaseClass::GetNumberedClass(pPlayer,pPlayer->m_iNextClass);
	}
	else if(pPlayer->m_pClass && pPlayer->m_pClass->m_iClassNumber!=pPlayer->m_iNextClass){
		pPlayer->m_pClass->Remove();
		delete pPlayer->m_pClass;
		pPlayer->m_pClass=NULL;

		pPlayer->m_pClass=CBaseClass::GetNumberedClass(pPlayer,pPlayer->m_iNextClass);
	}

	pPlayer->pev->playerclass=pPlayer->m_pClass->m_iClassNumber;

	pPlayer->m_iComboHits=0;

	MESSAGE_BEGIN(MSG_ALL,gmsgClassInfo);
		WRITE_BYTE(ENTINDEX(pPlayer->edict()));
		WRITE_SHORT(pPlayer->pev->playerclass);
		WRITE_SHORT(pPlayer->pev->team);
		if(pPlayer->m_iComboHits!=-1)	//Incase of a different gamemode, check combohits
			WRITE_BYTE(1);
		else
			WRITE_BYTE(0);
	MESSAGE_END();

	if(pPlayer->m_pClass!=NULL){
		g_engfuncs.pfnSetClientKeyValue(pPlayer->entindex(),g_engfuncs.pfnGetInfoKeyBuffer(pPlayer->edict()),"model",pPlayer->m_pClass->GetModelName());
		pPlayer->m_pClass->SetTeamColor(pPlayer->pev->team);

		pPlayer->pev->max_health=pPlayer->m_pClass->m_iMaxHealth;
	}
	else{
		pPlayer->pev->max_health=100;
	}
	pPlayer->pev->health = pPlayer->pev->max_health;
	pPlayer->m_flInvincibleTime=gpGlobals->time+CVAR_GET_FLOAT("mp_respawninvincibility");

	if(pPlayer->m_hMounted)
		((CDragon*)(CBaseEntity*)pPlayer->m_hMounted)->DeMount();
	else if ( pPlayer->m_pClass!=NULL )
		pPlayer->m_pClass->Equip();

	g_engfuncs.pfnSetPhysicsKeyValue(pPlayer->edict(),"dragon","0");

	MESSAGE_BEGIN(MSG_ONE,gmsgDragon,NULL,pPlayer->pev);
		WRITE_BYTE(0);
		WRITE_BYTE(0);
	MESSAGE_END();
}

extern CBaseEntity  *g_pLastSpawn;
extern CBaseEntity	*g_pLastSpawnTeam[5];

extern BOOL IsSpawnPointValid(CBaseEntity *pPlayer,CBaseEntity *pSpot);
extern edict_t *EntSelectSpawnPoint(CBaseEntity *pPlayer);

int FNullEnt2( CBaseEntity *ent ) { return (ent == NULL) || FNullEnt( ent->edict() ); }

CBaseEntity *FindTeamspawn(CBaseEntity *pSpot,int team,int playerclass){ 

	CBaseEntity *pStart=pSpot; 
  
	//First look for valid spawnpoints 

	do{ 
		pSpot=UTIL_FindEntityByClassname(pSpot,"info_player_teamspawn"); 

	}while((FNullEnt2(pSpot) || (pSpot->pev->playerclass&(1<<(playerclass-1)))==0 || pSpot->pev->team!=team || ((CBaseToggle*)pSpot)->m_iGoalState!=TFCGOAL_INACTIVE) && pSpot!=pStart); 
 

	//None found, so look for a non removed one 

	if(pSpot==pStart){ 
		do{ 
			pSpot=UTIL_FindEntityByClassname(pSpot,"info_player_teamspawn"); 
		}while((FNullEnt2(pSpot) || (pSpot->pev->playerclass&(1<<(playerclass-1)))==0 || pSpot->pev->team!=team) && pSpot!=pStart);  
	} 
 
return pSpot; 
}  

edict_t *CWizardWarsGameplay::GetPlayerSpawnSpot( CBasePlayer *pPlayer ){
	edict_t *pentSpawnSpot;
	
	CBaseEntity *pSpot;
	CBaseEntity *pLastSpawn;
	edict_t		*player;

	player = pPlayer->edict();

	pLastSpawn=g_pLastSpawn;

	//Do if not in observer mode & there is a teamspawn
	if(!pPlayer->IsObserver() && pPlayer->m_pClass!=NULL && (pPlayer->m_pClass->m_iClassNumber!=0) && (UTIL_FindEntityByClassname(NULL,"info_player_teamspawn")!=NULL) ){

		pSpot=g_pLastSpawnTeam[pPlayer->pev->team];

		for(int i=RANDOM_LONG(0,5);i>0;i--){
			pSpot=UTIL_FindEntityByClassname(pSpot,"info_player_teamspawn");
		}

		CBaseEntity *pFirstSpot=pSpot;

		pSpot=UTIL_FindEntityByClassname(pSpot,"info_player_teamspawn");

		pFirstSpot=pSpot;

		pSpot=FindTeamspawn(pSpot,pPlayer->pev->team,pPlayer->pev->playerclass);

		if(pSpot==pFirstSpot && ((CBaseToggle*)pSpot)->m_iGoalState==TFCGOAL_REMOVED){
			pSpot=UTIL_FindEntityByClassname(NULL,"info_player_spawn");

			goto ReturnSpot;
		}

		pFirstSpot=pSpot;
		
		do{
			if(pSpot){
            // check if pSpot is valid
	            if(IsSpawnPointValid(pPlayer,pSpot)){
		            if(pSpot->pev->origin==Vector(0,0,0)){
						pSpot=FindTeamspawn(pSpot,pPlayer->pev->team,pPlayer->pev->playerclass);
					}
					goto ReturnSpot;
				}
			}
			pSpot=FindTeamspawn(pSpot,pPlayer->pev->team,pPlayer->pev->playerclass);
		}while(pSpot!=pFirstSpot);

ReturnSpot:
		if(FNullEnt2(pSpot)){
			g_pLastSpawn=pSpot;
			pentSpawnSpot = EntSelectSpawnPoint( pPlayer );
		}
		else{
			g_pLastSpawnTeam[pPlayer->pev->team]=pSpot;
			pentSpawnSpot=ENT(pSpot->pev);
		}
	}
	else{
		pentSpawnSpot = EntSelectSpawnPoint( pPlayer );
	}

	CBaseEntity *ent = NULL;
	while((ent=UTIL_FindEntityInSphere(ent,VARS(pentSpawnSpot)->origin,128))!=NULL){
        // if ent is a client, kill em (unless they are ourselves)
		if(ent->IsPlayer() && !(ent->edict()==player))
			ent->TakeDamage(VARS(INDEXENT(0)),VARS(INDEXENT(0)),1000,DMG_CRUSH);
	}

	pPlayer->pev->origin = VARS(pentSpawnSpot)->origin + Vector(0,0,1);
	pPlayer->pev->v_angle  = g_vecZero;
	pPlayer->pev->velocity = g_vecZero;
	pPlayer->pev->angles = VARS(pentSpawnSpot)->angles;
	pPlayer->pev->punchangle = g_vecZero;
	pPlayer->pev->fixangle = TRUE;

	CBaseEntity::Instance(pentSpawnSpot)->Use(pPlayer,pPlayer,USE_TOGGLE,0);
	
	if ( IsMultiplayer() && pentSpawnSpot->v.target )
	{
		FireTargets( STRING(pentSpawnSpot->v.target), pPlayer, pPlayer, USE_TOGGLE, 0 );
	}

	return pentSpawnSpot;
}

BOOL CWizardWarsGameplay::FPlayerCanRespawn(CBasePlayer *pPlayer){
	if(pPlayer->m_flNextRespawn>gpGlobals->time)
		return FALSE;
	return TRUE;
}

BOOL CWizardWarsGameplay::FPlayerCanTakeDamage(CBasePlayer *pPlayer,CBaseEntity *pAttacker){
	if(pPlayer->m_flInvincibleTime>=gpGlobals->time && pPlayer!=pAttacker)
		return FALSE;
	
	return CHalfLifeTeamplay::FPlayerCanTakeDamage(pPlayer,pAttacker);
}

BOOL CWizardWarsGameplay::CanHaveItem(CBasePlayer *pPlayer,CItem *pItem){
	if(pPlayer->IsAlive())
		return TRUE;
	return FALSE;
}

extern int gmsgMOTD;
extern int gmsgWorldPos;
extern int gmsgServerName;

void CWizardWarsGameplay::SendServerName(edict_t *client){
	MESSAGE_BEGIN(MSG_ONE,gmsgServerName,NULL,client);
		WRITE_STRING(CVAR_GET_STRING("hostname"));
	MESSAGE_END();
}

void CWizardWarsGameplay::SendWorldPositionToClient(edict_t *client){
	MESSAGE_BEGIN(MSG_ONE,gmsgWorldPos,NULL,client);
		WRITE_STRING(g_szWorldName);
		WRITE_COORD(g_iWorldX);
		WRITE_COORD(g_iWorldY);
	MESSAGE_END();
}

extern int gmsgGameMode;

void CWizardWarsGameplay::UpdateGameMode(CBasePlayer *pPlayer){
	MESSAGE_BEGIN( MSG_ONE, gmsgGameMode, NULL, pPlayer->edict() );
		if(IsTeamplay())
			WRITE_BYTE(1);
		else
			WRITE_BYTE(0);
		WRITE_BYTE((int)CVAR_GET_FLOAT("mp_allowcombos"));
	MESSAGE_END();
}

void CWizardWarsGameplay::ClientDisconnected(edict_t *pClient){
	CHalfLifeMultiplay::ClientDisconnected(pClient);

	pClient->v.team=0;

	if ( pClient ){
		CBasePlayer *pPlayer = (CBasePlayer *)CBaseEntity::Instance( pClient );

		if(pPlayer->m_pClass)
			pPlayer->m_pClass->Remove();
		pPlayer->m_pClass=NULL;

		if ( pPlayer ){
			if(pPlayer->m_pAttachedItem)
				pPlayer->m_pAttachedItem->DropFromPlayer();

			if(pPlayer->m_hMounted)
				((CDragon*)(CBaseEntity*)pPlayer->m_hMounted)->DeMount();

			// Tell all clients this player isn't a spectator anymore
			MESSAGE_BEGIN( MSG_ALL, gmsgSpectator );  
				WRITE_BYTE( ENTINDEX(pClient) );
				WRITE_BYTE( 0 );
			MESSAGE_END();

			CBasePlayer *client = NULL;
			while ( ((client = (CBasePlayer*)UTIL_FindEntityByClassname( client, "player" )) != NULL) && (!FNullEnt(client->edict())) ) {
				if ( !client->pev )
					continue;
				if ( client == pPlayer )
					continue;

				// If a spectator was chasing this player, move him/her onto the next player
				if ( client->m_hObserverTarget == pPlayer ){
					int iMode = client->pev->iuser1;
					client->pev->iuser1 = 0;
					client->m_hObserverTarget = NULL;
					client->Observer_SetMode( iMode );
				}
			}
		}
	}
}

void CWizardWarsGameplay::Spectate(CBasePlayer *pPlayer){
	edict_t *pentSpawnSpot=NULL;

	pentSpawnSpot = EntSelectSpawnPoint( pPlayer );

	pPlayer->pev->health=1;

	pPlayer->StartObserver( VARS(pentSpawnSpot)->origin, VARS(pentSpawnSpot)->angles);
}

BOOL CWizardWarsGameplay::IsMultiplayer(){
	return TRUE;
}

BOOL CWizardWarsGameplay::FAllowMonsters(){
	return TRUE;
}

BOOL CWizardWarsGameplay::CanHavePlayerItem(CBasePlayer *pPlayer,CBasePlayerItem *pWeapon){
	if(CHalfLifeTeamplay::CanHavePlayerItem(pPlayer,pWeapon)==FALSE)
		return FALSE;

	if(pWeapon->iItemSlot()==5){
		if(pPlayer->pev->playerclass==EARTH_CLASS && ((CEarthWizard*)pPlayer->m_pClass)->m_iIsBear)
			return FALSE;

		for(int i=0;i<MAX_ITEM_TYPES;i++){
			if(pPlayer->m_rgpPlayerItems[i] && pPlayer->m_rgpPlayerItems[i]->iItemSlot()==5){
				return FALSE;
			}
		}
	}

	return TRUE;
}

extern int gmsgDeathMsg;

void CWizardWarsGameplay::DeathNotice(CBasePlayer *pVictim,entvars_t *pKiller,entvars_t *pevInflictor){
	if(pVictim->m_pClass && pVictim->m_pClass->m_iClassNumber==LIFE_CLASS){
		if(((CLifeWizard*)pVictim->m_pClass)->m_iSacrificeKill){
			MESSAGE_BEGIN( MSG_ALL, gmsgDeathMsg );
				WRITE_BYTE( ENTINDEX(ENT(pKiller)) );		// the killer
				WRITE_BYTE( ENTINDEX(pVictim->edict()) );	// the victim
				WRITE_STRING( "sacrifice" );
			MESSAGE_END();
			return;
		}
	}

	if(pVictim->m_iPoisonKill==1){
		MESSAGE_BEGIN( MSG_ALL, gmsgDeathMsg );
			WRITE_BYTE( ENTINDEX(ENT(pKiller)) );		// the killer
			WRITE_BYTE( ENTINDEX(pVictim->edict()) );	// the victim
			WRITE_STRING( "yuck" );
		MESSAGE_END();
		return;
	}

	CHalfLifeTeamplay::DeathNotice(pVictim,pKiller,pevInflictor);
}

void DeactivateSatchels(CBasePlayer *pOwner){;}

void SetPlayerMusic(CBasePlayer *pPlayer,char *music){
	strcpy(pPlayer->m_szQueuedMusic,music);
}
