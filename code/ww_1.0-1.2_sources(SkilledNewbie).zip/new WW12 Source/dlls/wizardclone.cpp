/*
	wizardclone.cpp
	By: Alan Fischer 
	Parts from: Valve Software and Id Software

	For the WizWars mod.
*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "monsters.h"
#include "weapons.h"
#include "nodes.h"
#include "player.h"
#include "tfcentities.h"

#define WIZARDCLONE_HEALTH		100
#define WIZARDCLONE_LIFE		5

class CWizardClone:public CBaseMonster{
public:
	void Spawn();
	void Precache();
	void EXPORT WizardCloneThink();
	void EXPORT WizardCloneTouch(CBaseEntity *pOther);
	void Killed(entvars_t *pevAttacker,int iGib);
	int IRelationship(CBaseEntity *pTarget);
	int TakeDamage(entvars_t *pevInflictor,entvars_t *pevAttacker,float flDamage,int bitsDamageType);

	float m_flVelocity;
	float m_flDie;
	Vector m_vecCoord;

	EHANDLE		m_hItem;
};

void CWizardClone::Precache(){
}

void CWizardClone::Spawn(){
	Precache();

	entvars_t *pevOwner;
	
	if(pev->owner)
		pevOwner=VARS(pev->owner);
	else
		pevOwner=pev;

	pev->model			=pevOwner->model;
	pev->modelindex		=pevOwner->modelindex;
	pev->frame			=pevOwner->frame;
	pev->colormap		=pevOwner->colormap;
	pev->velocity		=pevOwner->velocity;
	pev->flags			=0;
	pev->deadflag		=pevOwner->deadflag;
	pev->renderfx		=kRenderFxDeadPlayer;
	pev->renderamt		=ENTINDEX(ENT(pevOwner));
	pev->effects		=pevOwner->effects | EF_NOINTERP;
	pev->sequence		=3;
	pev->animtime		=pevOwner->animtime;
	pev->mins			=pevOwner->mins;
	pev->maxs			=pevOwner->maxs;
	pev->velocity		=pevOwner->velocity;

	pev->solid			=SOLID_BBOX;
	pev->movetype		=MOVETYPE_BOUNCE;
	pev->health			=WIZARDCLONE_HEALTH;
	pev->max_health		=WIZARDCLONE_HEALTH;
	pev->takedamage		=DAMAGE_YES;

	m_vecCoord=g_vecZero;
	m_flFieldOfView=0;
	m_hEnemy=NULL;
	m_flVelocity=pev->velocity.Length();

	UTIL_MakeVectors(pev->angles);
	pev->velocity=gpGlobals->v_forward*m_flVelocity;

	SetBlending(0,-pevOwner->v_angle.x);

	SetThink(WizardCloneThink);
	SetTouch(WizardCloneTouch);

	UTIL_SetSize(pev, Vector( -18, -18, -30), Vector(18, 18, 30));
	UTIL_SetOrigin( pev, pev->origin );

	m_flDie=gpGlobals->time+WIZARDCLONE_LIFE;
	pev->nextthink=gpGlobals->time+.1;

	m_bloodColor=DONT_BLEED;

	if(pevOwner && Instance(pevOwner)->IsPlayer()){
		CBasePlayer *pPlayer=(CBasePlayer*)Instance(pevOwner);

		if(pPlayer->m_pAttachedItem!=NULL){
			m_hItem=Create("info_tfgoal",pev->origin,pev->angles,edict());
			m_hItem->pev->aiment=edict();
			m_hItem->pev->movetype=MOVETYPE_FOLLOW;
			SET_MODEL(m_hItem->edict(),STRING(pPlayer->m_pAttachedItem->pev->model));
			m_hItem->pev->sequence=pPlayer->m_pAttachedItem->pev->sequence;
			m_hItem->pev->framerate=pPlayer->m_pAttachedItem->pev->framerate;
		}
	}

	ResetSequenceInfo();
}

void CWizardClone::WizardCloneThink(){
	StudioFrameAdvance();

	Vector temp;

	if(pev->velocity.z>0)
		pev->velocity.z=0;

	if(m_vecCoord==pev->origin){
		Killed(pev,0);
	}

	temp=pev->velocity;
	pev->velocity=temp.Normalize()*m_flVelocity;
	
	if (gpGlobals->time >= m_flDie){
		Killed( pev, 0 );
		return;
	}

	temp=UTIL_VecToAngles(pev->velocity);
	pev->angles.y=temp.y;
	
	m_vecCoord=pev->origin;
	pev->nextthink=gpGlobals->time+.1;
}

void CWizardClone::WizardCloneTouch(CBaseEntity *pOther){
	pev->velocity.z=0;
}

void CWizardClone::Killed(entvars_t *pevAttacker,int iGib){
	if(m_hItem!=NULL)
		UTIL_Remove(m_hItem);
	
	CBaseEntity::Killed(pevAttacker,iGib);
}

int CWizardClone::TakeDamage(entvars_t *pevInflictor,entvars_t *pevAttacker,float flDamage,int bitsDamageType){
	return CBaseMonster::TakeDamage(pevInflictor,pevAttacker,flDamage,bitsDamageType);
}

int CWizardClone::IRelationship(CBaseEntity *pTarget){
	return(CBaseMonster::IRelationship(pTarget));
}

LINK_ENTITY_TO_CLASS( monster_wizardclone, CWizardClone);