class CThornbush : public CBaseMonster{
public:
	void Spawn( void );
	void Precache( void );

	void EXPORT TakeThis(CBaseEntity *pOther);
	void EXPORT WatchOut();
	void EXPORT GrowUp();
	void EXPORT GrowDown();
	void Fertilize();
	void Harvest();
	void Killed(entvars_t *pevAttacker, int iGib);
	void Shoot( Vector vecSrc, Vector vecDirShooting, int iDamage, int iDamageBits, entvars_t* pevAttacker);
	int IRelationship(CBaseEntity *pTarget);
	int TakeDamage( entvars_t* pevInflictor, entvars_t* pevAttacker, float flDamage, int bitsDamageType );
	int Classify(){return CLASS_PLAYER_ALLY;}
	void Enchant(int playerclass);

	EHANDLE m_hOwner;

	float		m_flNextHealthGain;

	int m_iMissleDamage;
	int m_iDamageBits;
	int m_iChunks;
	int m_flSporeTime;

	unsigned short m_usThornbushUpgrade;

	Vector		vecToEnemy;
};