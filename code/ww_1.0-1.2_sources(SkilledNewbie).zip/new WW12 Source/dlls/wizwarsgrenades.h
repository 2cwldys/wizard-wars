/* wizwarsgrenades.h

  The grenade header file

  By: Alan Fischer
*/

class CTCrystal : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();

private:
	unsigned short m_usTCrystalFire;
};

class CLightningSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();

	int m_iExplosionCount;

private:
	unsigned short m_usLightningSatchelFire;
};

class CPoisonSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();

private:
	unsigned short m_usPoisonSatchelFire;
	EHANDLE m_hSprite;
};

class CHealHurtSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void EXPORT StopSound();
	void RadiusDamageAndHeal( Vector vecSrc, entvars_t *pevInflictor, entvars_t *pevAttacker, float flDamage, float flRadius, int iClassIgnore, int bitsDamageType );
	void Spawn();
};

class CFireSpiral:public CGrenade{
public:
	void Precache();
	void Spawn();
	void EXPORT MoveThink();

	float m_maxFrame;
	float m_flIgniteTime;
	float m_flThetaOffset;
};

class CFireSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();

private:
	unsigned short m_usFireSatchelFire;
	EHANDLE m_hSprite;
};

class CCockleBur:public CBaseMonster{
public:
	void Precache();
	void Spawn();
	void EXPORT MoveThink();
	void EXPORT GrabTouch(CBaseEntity *pEnt);
	int IRelationship(CBaseEntity *pEnt);

	float m_flLife;
	EHANDLE m_hOwner;
	Vector m_vOffset;
};

class CBurSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();

private:
	unsigned short m_usBurSatchelFire;
};

class CEarthquakeSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void MakeEarthquake();
	void Spawn();

	int m_iCounter;

private:
	unsigned short m_usEarthquakeSatchelFire;
};

class CSuctionSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();
	int IRelationship(CBaseEntity *pEnt);

private:
	unsigned short m_usSuctionSatchelFire;
};

class CToothSatchel : public CGrenade{
public:
	void Precache();
	void EXPORT GrenadeThink();
	void EXPORT GrenadeAction();
	void Spawn();
	int IRelationship(CBaseEntity *pEnt);

	int m_iExplosionCount;

private:
	unsigned short m_usToothSatchelFire;
};

static short m_sPoisonModelIndex;
static short m_sSpiralModelIndex;
static short m_sHealHurtModelIndex;
static short m_sTCrystalModelIndex;
static short m_sBurModelIndex;
static short m_sSucModelIndex;