/* wizardwarsdefs.h */

#ifndef WIZARDWARSDEFS_H
#define WIZARDWARSDEFS_H

#define MENU_TEAM			2
#define MENU_CLASS			3
#define MENU_MAPBRIEFING	4

#define LIFE_CLASS			1
#define FIRE_CLASS			2
#define ICE_CLASS			3
#define NATURE_CLASS		4
#define LIGHTNING_CLASS		5
#define DEATH_CLASS			6
#define EARTH_CLASS			7
#define WIND_CLASS			8
#define ARCHMAGE_CLASS		9
#define DRAGONWIZARD_CLASS	10

#define MAX_CONCLAVES	8
#define MAX_CLASSES		12

static char ConclaveNames[MAX_CONCLAVES][32]={
	"No Conclave",
	"Elementalists",
	"Naturalists",
	"Creationists",
	"Abolishers",
	"Systemics",
	"Nihilists",
	"Arcanists",
};

static char ClassNames[MAX_CLASSES][32]={
	"No class",
	"Healer",
	"Pyromancer",
	"Aquamancer",
	"Nature",
	"Electromancer",
	"Necromancer",
	"Geomancer",
	"Aeromancer",
	"Archmage",
	"Dracomancer",
	"No class",
};

static char ModelNames[MAX_CLASSES][32]={
	"gordon",
	"LifeWizard",
	"FireWizard",
	"IceWizard",
	"NatureWizard",
	"LightningWizard",
	"DeathWizard",
	"EarthWizard",
	"WindWizard",
	"ArchMage",
	"DragonWizard",
	"gordon",
};

static unsigned char ClassConclave[MAX_CLASSES]={
	0,
	3,
	1,
	1,
	2,
	1,
	4,
	2,
	1,
	5,
	4,
	0,
};

enum FPANIMS{
	FPANIMS_SHIELDIDLE,
	FPANIMS_SHIELDFIRE,
	FPANIMS_MMIDLE,
	FPANIMS_MMFIRE,

	FPANIMS_LITBOLTIDLE,
	FPANIMS_LITBOLTFIRE,
	FPANIMS_SPOTBOLTIDLE,
	FPANIMS_SPOTBOLTSTART,
	FPANIMS_SPOTBOLTCHARGE,
	FPANIMS_SPOTBOLTFULL,
	FPANIMS_SPOTBOLTFIRE,

	FPANIMS_RAYIDLE,
	FPANIMS_RAYFIRE,
	FPANIMS_RAYEND,
	
	FPANIMS_SKULLIDLE,
	FPANIMS_SKULLFIRE,
	
	FPANIMS_FORCEIDLE,
	FPANIMS_FORCEFIRE,

	FPANIMS_FLAMELICKIDLE,
	FPANIMS_FLAMELICKFIRE,
	FPANIMS_FIREBALLIDLE,
	FPANIMS_FIREBALLFIRE,

	FPANIMS_ICEPOKEIDLE,
	FPANIMS_ICEPOKEFIRE,

	FPANIMS_THORNBLASTIDLE,
	FPANIMS_THORNBLASTFIRE,

	FPANIMS_BEANSTALKIDLE,

	FPANIMS_ROLLINGSTONEIDLE,
	FPANIMS_ROLLINGSTONEFIRE,
	FPANIMS_BIRDIDLE,
	FPANIMS_BIRDFIRE,

	FPANIMS_LEVITATIONIDLE,

	FPANIMS_DRAGONBREATHIDLE,
	FPANIMS_DRAGONBREATHFIRE,
	FPANIMS_WYVERNIDLE,
	FPANIMS_WYVERNFIRE,

	FPANIMS_TAUNT,

	NUM_FPANIMS
};

enum TPANIMS{
	TPANIMS_RAY,
	TPANIMS_ONEHANDED,
	TPANIMS_TWOHANDED,
	NUM_TPANIMS
};

static float FirstPersonAnims[NUM_FPANIMS]={
	7,
	8,
	9,
	10,

	9,
	10,
	11,
	12,
	13,
	14,
	15,

	11,
	12,
	13,

	14,
	15,

	14,
	15,

	11,
	12,
	13,
	14,

	14,
	15,

	11,
	12,

	13,

	9,
	10,
	13,
	14,

	13,

	11,
	12,
	13,
	14,

	0,
};

static float FirstPersonAnimTimes[NUM_FPANIMS]={
	60/14,
	30/14,
	30/14,
	60/60,

	30/14,
	60/60,
	30/14,
	30/14,
	30/1,
	30/14,
	30/14,

	60/14,
	60/14,
	60/19,

	60/14,
	60/29,

	60/14,
	60/29,

	60/14,
	30/14,
	60/14,
	30/14,

	60/14,
	60/14,

	60/14,
	30/14,

	60/14,

	60/14,
	30/14,
	60/14,
	30/14,

	60/14,
	30/14,
	60/14,
	30/14,

	60/14,

	60/14,
};

static char ThirdPersonAnims[NUM_TPANIMS][20]={
	"hive",
	"hive",
	"onehanded",
};

#endif