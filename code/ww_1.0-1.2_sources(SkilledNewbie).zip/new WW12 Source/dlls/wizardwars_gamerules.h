/***
*
*	Copyright (c) 1999, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//
// wizardwars_gamerules.h
//

#define MAX_TEAMNAME_LENGTH	16
#define MAX_TEAMS			32

#define TEAMPLAY_TEAMLISTLENGTH		MAX_TEAMS*MAX_TEAMNAME_LENGTH

class CHalfLifeTeamplay;

class CWizardWarsGameplay : public CHalfLifeTeamplay
{
public:
	CWizardWarsGameplay();

	virtual BOOL ClientCommand( CBasePlayer *pPlayer, const char *pcmd );
	virtual void ClientUserInfoChanged( CBasePlayer *pPlayer, char *infobuffer );
	virtual BOOL IsTeamplay( void );
	virtual int PlayerRelationship( CBaseEntity *pPlayer, CBaseEntity *pTarget );
	virtual const char *GetTeamID( CBaseEntity *pEntity );
	virtual void InitHUD( CBasePlayer *pl );
	virtual const char *GetGameDescription( void ) { return "Wizard Wars"; }  // this is the game name that gets seen in the server browser
	virtual void PlayerKilled( CBasePlayer *pVictim, entvars_t *pKiller, entvars_t *pInflictor );
	virtual int GetTeamIndex( const char *pTeamName );
	virtual BOOL IsValidTeam(const char *pTeamName);
	const char *SetDefaultPlayerTeam( CBasePlayer *pPlayer );
	virtual void ChangePlayerTeam( CBasePlayer *pPlayer, const char *pTeamName, BOOL bKill, BOOL bGib );
	virtual const char* GetIndexedTeamName(int teamIndex);
	
	virtual void PrintTeamstring(CBasePlayer *pPlayer);
	virtual void PrintClassstring(CBasePlayer *pPlayer);
	virtual void PlayerThink(CBasePlayer *pPlayer);
	virtual BOOL IsDeathmatch();
	virtual void PlayerSpawn(CBasePlayer *pPlayer);
	virtual edict_t *GetPlayerSpawnSpot( CBasePlayer *pPlayer );
	virtual BOOL FPlayerCanRespawn(CBasePlayer *pPlayer);
	virtual int DeadPlayerWeapons(CBasePlayer *pPlayer);
	virtual BOOL CanHaveItem(CBasePlayer *pPlayer,CItem *pItem);
	virtual void StartPlayer(CBasePlayer *pPlayer);
	virtual void SendWorldPositionToClient(edict_t *client);
	virtual void SendServerName(edict_t *client);
	virtual void UpdateGameMode(CBasePlayer *pPlayer);
	virtual void ClientDisconnected(edict_t *pClient);
	virtual void Spectate(CBasePlayer *pPlayer);
	virtual BOOL IsMultiplayer();
	virtual BOOL FAllowMonsters();
	virtual BOOL FPlayerCanTakeDamage(CBasePlayer *pPlayer,CBaseEntity *pAttacker);
	virtual BOOL CanHavePlayerItem(CBasePlayer *pPlayer,CBasePlayerItem *pWeapon);
	virtual void ChooseTeam(CBasePlayer *pPlayer,int slot);
	virtual void ChooseClass(CBasePlayer *pPlayer,int slot);
	virtual BOOL FShouldSwitchWeapon(CBasePlayer *pPlayer,CBasePlayerItem *pWeapon);
	void InitHUD2(CBasePlayer *pPlayer);
	virtual void DeathNotice(CBasePlayer *pVictim,entvars_t *pKiller,entvars_t *pevInflictor);

private:
	void RecountTeams( void );
	const char *TeamWithFewestPlayers( void );

	BOOL m_DisableDeathMessages;
	BOOL m_DisableDeathPenalty;

	int m_iYuckSprite;
	int m_iArrowSprite;
};

extern DLL_GLOBAL short	g_sSacrificeSprite;

void DeactivateSatchels(CBasePlayer *pOwner);
