/* wizwars_effects.cpp : By  Alan Fischer */

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "player.h"
#include "saverestore.h"
#include "gamerules.h"

class CMusic:public CBaseEntity{
public:
	void Spawn();
	void KeyValue(KeyValueData *pkvd);
	void EXPORT PlayMusic(CBaseEntity *pOther);

	char m_szMusic[64];
};

LINK_ENTITY_TO_CLASS(func_music,CMusic);

void CMusic::KeyValue(KeyValueData *pkvd){
	if(FStrEq(pkvd->szKeyName,"music")){
		strcpy(pkvd->szValue,m_szMusic);
		pkvd->fHandled=TRUE;
	}
	else{
		CBaseEntity::KeyValue(pkvd);
	}
}

void CMusic::Spawn(){
	pev->solid=SOLID_TRIGGER;
	SET_MODEL(ENT(pev),STRING(pev->model));
	pev->movetype=MOVETYPE_NONE;
	SetTouch(PlayMusic);
}

extern int gmsgMusic;

void CMusic::PlayMusic(CBaseEntity *pOther){
	CBasePlayer *pPlayer;
	
	if(!pOther->IsPlayer())
		return;

	pPlayer=(CBasePlayer*)pOther;

	if(FStrEq(pPlayer->m_szCurrentMusic,m_szMusic))
		return;

	MESSAGE_BEGIN(MSG_ONE,gmsgMusic,NULL,pPlayer->pev);
		WRITE_STRING(m_szMusic);
	MESSAGE_END();
}
