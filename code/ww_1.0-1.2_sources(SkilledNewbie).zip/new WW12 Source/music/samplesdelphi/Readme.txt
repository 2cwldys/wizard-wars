Some notes about the examples :
----------------------------------
  There are some slight differences between Delphi4 and 5.
In Delphi4 replace all  :
  key:=Buf.Event.KeyEvent.wVirtualKeyCode; 
with
  key:=Buf.Event.KeyEvent.wVirtualScanCode;
-----------------------------------
 Also the managing of the input and output (console that is) is done in  a rather strange way. Don't be confused by all the Windows Raw Api because it's only a replacement of readkey and writeln (combined with gotoxy ...).
----------------------------------
 
 Any questions and comments are welcomed
mailto: d_bocevski@yahoo.com or d_bocevski@hotpop.com.

p.s. Note that not all of the examples are finished. I could use some help with the callback functions which are used in stream2 and record examples. 
 