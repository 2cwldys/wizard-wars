//===============================================================================================
// SIMPLEST.EXE
// Copyright (c), Firelight Multimedia, 1999,2000.
//
// This is the simplest way to play a song through FMOD.  It is basically Init, Load, Play!
//===============================================================================================

#include <stdio.h>
#include <stdlib.h>
#ifndef PLATFORM_LINUX
  #include <conio.h>
#else
  #include "wincompat.h"
#endif
#include "../../api/fmod.h"
#include "../../api/fmod_errors.h"	// optional

/*
[
	[DESCRIPTION]

	[PARAMETERS]
 
	[RETURN_VALUE]

	[REMARKS]

	[SEE_ALSO]
]
*/
int main()
{
	FMUSIC_MODULE *mod;

	if (FSOUND_GetVersion() < FMOD_VERSION)
	{
		printf("Error : You are using the wrong DLL version!  You should be using FMOD %.02f\n", FMOD_VERSION);
		exit(1);
	}

	FSOUND_SetBufferSize(100);

	// ==========================================================================================
	// INITIALIZE
	// ==========================================================================================
	if (!FSOUND_Init(44100, 32, 0))
	{
		printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
		exit(1);
	}

	// ==========================================================================================
	// LOAD SONG
	// ==========================================================================================
	mod = FMUSIC_LoadSong("../../media/invtro94.s3m");
	if (!mod)
	{
		printf("%s\n", FMOD_ErrorString(FSOUND_GetError()));
		exit(1);
	}

	// ==========================================================================================
	// PLAY SONG
	// ==========================================================================================
	FMUSIC_PlaySong(mod);

	printf("Press any key to quit\n");
	printf("=========================================================================\n");
	printf("Playing %s...\n", FMUSIC_GetName(mod));
	do
	{
		printf("order = %d, row = %d channels playing = %d cpu usage = %.02f%%     \r", FMUSIC_GetOrder(mod), FMUSIC_GetRow(mod), FSOUND_GetChannelsPlaying(), FSOUND_GetCPUUsage());
	} while (!_kbhit());

	getch();

	printf("\n");

	FMUSIC_FreeSong(mod);
	FSOUND_Close();
    return 0;
}
