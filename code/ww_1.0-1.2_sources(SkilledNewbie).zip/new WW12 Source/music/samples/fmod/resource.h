//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by fmod.rc
//
#define IDS_APPNAME                     1
#define IDS_NOVIDEODRIVERFOUND          2
#define IDD_DIALOG1                     102
#define IDR_MENU1                       103
#define IDD_INTERFACE                   104
#define IDI_ICON1                       105
#define IDD_DSENUMBOX                   109
#define IDD_CDINTERFACE                 111
#define IDR_MODULE1                     113
#define IDC_RADIO1                      1000
#define IDC_DRIVERNAME                  1001
#define IDC_RADIO2                      1001
#define IDC_FULLSCREEN                  1002
#define IDC_RADIO3                      1002
#define IDC_ZBUFFER                     1003
#define IDC_RADIO4                      1003
#define IDC_PERSCORRECT                 1004
#define IDC_VIDEOMODE                   1005
#define IDC_RADIO5                      1005
#define IDC_TRIPLEBUFFER                1006
#define IDC_SONGLIST                    1006
#define IDC_BILINEARFILTER              1007
#define IDC_BUTTON1                     1007
#define IDC_LOAD                        1007
#define IDC_ZBUFFER2                    1008
#define IDC_BUTTON2                     1008
#define IDC_DELETE                      1008
#define IDC_DEVICES                     1009
#define IDC_DSENUM_COMBO                1010
#define IDC_PROGRESS1                   1010
#define IDC_DSENUM_COMBO2               1011
#define IDC_BUTTON3                     1011
#define IDC_PLAY                        1011
#define IDC_BUTTON4                     1012
#define IDC_DSENUM_COMBO3               1012
#define IDC_STOP                        1012
#define IDC_CHECK1                      1013
#define IDC_PLAYLIST                    1013
#define IDC_CHECK2                      1014
#define IDC_ECHO                        1014
#define IDC_CHECK3                      1015
#define IDC_LOWPASS                     1015
#define IDC_CHECK4                      1016
#define IDC_FLANGE                      1016
#define IDC_CDLOOPCHECK                 1016
#define IDC_CHECK5                      1017
#define IDC_CHECK6                      1018
#define IDC_RESONANCE                   1018
#define IDC_BUTTON5                     1019
#define IDC_DEBUG                       1019
#define IDC_CDPLAY                      1019
#define IDC_BUTTON6                     1020
#define IDC_EXIT                        1020
#define IDC_BUTTON7                     1021
#define IDC_ABOUT                       1021
#define IDC_BUTTON8                     1022
#define IDC_ORDER_DEC                   1022
#define IDC_BUTTON9                     1023
#define IDC_ORDER_INC                   1023
#define IDC_BUTTON10                    1024
#define IDC_CDSTOP                      1024
#define IDC_BUTTON11                    1025
#define IDC_CDPAUSE                     1025
#define IDC_CHECK7                      1026
#define IDC_BASSBOOST                   1026
#define IDC_NR                          1026
#define IDC_REVERB                      1026
#define IDC_CHECK8                      1027
#define IDC_PREVERB                     1027
#define IDC_CHECK9                      1028
#define IDC_CDBACK                      1028
#define IDC_CONFIG                      1029
#define IDC_SLIDER1                     1030
#define IDC_CDFORWARD                   1032
#define IDC_CDEJECT                     1033
#define IDC_RADIOCONTINUOUS             1039
#define IDC_RADIORANDOM                 1040
#define IDC_RADIOLOOPED                 1042
#define IDC_CDMAXIMIZE                  1043
#define IDC_CDMINIMIZE                  1044
#define IDC_SLIDER2                     1045
#define IDC_CDVOLUME                    1047
#define MENU_ABOUT                      40001
#define MENU_OPEN                       40002
#define MENU_EXIT                       40003
#define MENU_PLAYSOUND                  40004
#define MENU_STOPSOUND                  40005
#define MENU_ADDCHANNELS                40006
#define MENU_REMOVECHANNELS             40007
#define MENU_INFO                       40009
#define MENU_STEPTHROUGH                40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
