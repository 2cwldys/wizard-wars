=========================
  ww_2fort Spec Sheet
=========================
---General Information---
Title 				2 Fortresses for Wizard Wars
Filename			ww_2fort.bsp
Author				Rikers
Other lvls by author		cs_phoenix, Overlord, xD Deathmatch, Guardian
Email address 			Rikers3@excite.com
Home page			---------------------
Additional Credits to   	Everyone in the Wizard Wars community that inspired me to make this 
                                map.

---Play Information------
Map Description			Classic 2fort style map.
Map Objective			Capture the Grail
Scoring Information		10 points to capping person, 10 team points for capping team.
Number of Teams			2
Recommended # of Players:	4+

---Map Information-------
New Textures            	Yes (Made by Rikers)
New Sounds			None

---Construction----------
Base				2fort (From the Team Fortress games)
Editor(s) used          	WorldCraft, Adobe Photoshop 5.0, Q2BeaVeR
Compile Machine			Athlon 600MHz
Compile time			00:01:06:00 (1 Hour and 6 Minutes)

---Additional Info-------
This map is based on the classic level 2 Fortresses that has been used
in every Team Fortress game (TF, Q3F, TFC/TF 1.5).

---Copyright-Permissions--------------------------------------------
Authors MAY use this level as a base to build additional levels. 

You MUST NOT distribute this level UNLESS you INCLUDE THIS FILE WITH
NO MODIFICATIONS!!!. If you don't co-operate, then DON'T DISTRIBUTE
IT IN ANY FORM!!.

This BSP may be distributed ONLY with the Wizard Wars Modification for
Half-Life. You are NOT authorized to put this BSP on any CD or distribute it in
any way without my permission.
