=========================
Wiard Wars Map Spec Sheet
=========================
---General Information---
Title 				ww_chasm
Filename			ww_chasm.bsp
Author				Alan Fischer
Other lvls by author		ravine, ww_golem
Email address 			siralanf@mnic.net
Home page			http://www.planethalflife.com/wizardwars
Additional Credits to   	Zouave for wwwad.wad

---Play Information------
Map Description			Secure the Command points.  As you do, the weather changes.
Map Objective			Command Points
Scoring Information		2 points per Command Point
Number of Teams			4
Recommended # of Players:	8+

---Map Information-------
New Textures            	None
New Sounds			None

---Construction----------
Base				None
Editor(s) used          	WorldCraft
Compile Machine			Athlon 600MHz
Compile time			About 2hrs

---Additional Info-------
None

---Copyright-Permissions--------------------------------------------
Authors may use the entities in this level as a base to build additional levels.

You MUST NOT distribute this level UNLESS you INCLUDE THIS FILE WITH
NO MODIFICATIONS!!!. If you don't co-operate, then DON'T DISTRIBUTE
IT IN ANY FORM!!.