=========================
Wiard Wars Map Spec Sheet
=========================
---General Information---
Title 				ww_golem
Filename			ww_golem.bsp
Author				Alan Fischer
Other lvls by author		ravine, ww_chasm
Email address 			siralanf@mnic.net
Home page			http://www.planethalflife.com/wizardwars
Additional Credits to   	Zouave for wwwad.wad

---Play Information------
Map Description			Control the Golem and destroy the other teams castle
Map Objective			The golem
Scoring Information		10 points per Round
Number of Teams			2
Recommended # of Players:	6+

---Map Information-------
New Textures            	None
New Sounds			None

---Construction----------
Base				None
Editor(s) used          	WorldCraft
Compile Machine			Athlon 600MHz
Compile time			About 2hrs

---Additional Info-------
None

---Copyright-Permissions--------------------------------------------
Authors may use the entities in this level as a base to build additional levels.

You MUST NOT distribute this level UNLESS you INCLUDE THIS FILE WITH
NO MODIFICATIONS!!!. If you don't co-operate, then DON'T DISTRIBUTE
IT IN ANY FORM!!.