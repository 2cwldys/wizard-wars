================================================================================
* LEVEL INFORMATION *
--------------------------------------------------------------------------------
TITLE                   : Project Varrock(WW)
RELEASE                 : Final
FILENAME                : ww_varrock.bsp
AUTHOR                  : David "Rammstein" Vela
DATE                    : October 27, 2001
GAME                    : Half-Life: Wizard Wars
EMAIL ADDRESS           : rig_rammstein@hotmail.com
HOMEPAGE URL            : http://www.shortyellowbus.org/
================================================================================


================================================================================
* LEVEL DESCRIPTION *
--------------------------------------------------------------------------------
GAMEPLAY:		: Wizard Wars - Combo Chaos(Deathmatch)
MAX PLAYERS:		: 30
SUGGESTED PLAYER LOAD   : 10-20
 
NEW TEXTURES            : Yes(included)
NEW SOUNDS              : No
NEW MODELS              : No
================================================================================

 
================================================================================
* CONSTRUCTION *
--------------------------------------------------------------------------------
MAP BASE                : hullu6dm_varrock.bsp
PREFABS USED            : None
EDITOR(S) USED          : Worldcraft 3.3
OTHER UTILITIES USED    : Zoners Tools

COMPILE MACHINE         : visit http://rcs.valve-erc.com/ for details

COMPILE TIME            : ~60 mins

COMPILED USING          : R.C.S.(Remote Compiling System)
================================================================================


================================================================================
* OTHER LEVELS BY THE AUTHOR *
--------------------------------------------------------------------------------
Counterstrike
  awp_field.bsp  - The Field
================================================================================


================================================================================
* SPECIAL INSTRUCTIONS / ADDITIONAL INFORMATION *
--------------------------------------------------------------------------------
Extract the .bsp and .txt file with the mapname to your \wizwars\maps\
directory.
================================================================================

 
================================================================================
* CREDITS *
--------------------------------------------------------------------------------
Valve Software          : For the greatest game ever made; Half-Life. 
Sinistar		: Overall inspiration. Nagging me to get the map done :)
User Err0r		: Testing, ideas, overall help.
================================================================================


================================================================================
* COPYRIGHT / PERMISSIONS *
--------------------------------------------------------------------------------
Authors MAY NOT use this level as a base to build additional levels.
 
You MUST NOT distribute this level UNLESS you INCLUDE THIS FILE WITH
NO MODIFICATIONS!!!. If you don't co-operate, then DON'T DISTRIBUTE
IT IN ANY FORM!!.
 
This LEVEL may be distributed ONLY over the Internet and/or BBS systems.
You are NOT authorized to put this LEVEL on any CD or distribute it in
any way without my permission. I would, however, be honored if you did - 
if you would only email me first!
================================================================================